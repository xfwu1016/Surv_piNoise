"""Run the locked rho x Brier-weight grid using unchanged corrected-v1 modules.

The --limit option is a recoverable full-budget preflight; its output remains
explicitly partial until all 600 predeclared cells have completed.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import csv
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
FIELDS = ['dataset', 'backbone', 'seed', 'rho', 'gamma_brier', 'method', 'cindex', 'ibs']


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def json_default(value):
    if hasattr(value, 'tolist'):
        return value.tolist()
    raise TypeError(type(value).__name__)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, allow_nan=False,
                              default=json_default) + '\n', encoding='utf-8')
    temp.replace(path)


def token(value):
    return format(float(value), '.8g').replace('.', 'p')


def key(cell):
    return (f"{cell['dataset']}__{cell['backbone']}__{cell['seed']}"
            f"__rho_{token(cell['rho'])}__gamma_{token(cell['gamma_brier'])}")


def jobs(protocol):
    cells = [dict(dataset=dataset, backbone=protocol['backbone'], seed=seed,
                  rho=rho, gamma_brier=gamma)
             for dataset in protocol['datasets']
             for rho in protocol['rho_values']
             for gamma in protocol['gamma_brier_values']
             for seed in protocol['seeds']]
    # A full-budget reference-point fit is the first preflight, before the grid.
    ref = protocol['reference_point']
    cells.sort(key=lambda c: (not (c['rho'] == ref['rho'] and
                                  c['gamma_brier'] == ref['gamma_brier']),
                             protocol['datasets'].index(c['dataset']),
                             c['rho'], c['gamma_brier'], c['seed']))
    return cells


def worker(cell, protocol, output, fingerprint):
    import numpy as np
    import torch
    from survpinoise.data import load_dataset, split_dataset
    from survpinoise.simulation import make_reliability
    from survpinoise.training import run_methods

    torch.set_num_threads(1)
    directory = Path(output) / 'cells' / key(cell)
    receipt = directory / 'manifest.json'
    if receipt.exists():
        old = json.loads(receipt.read_text(encoding='utf-8'))
        if old.get('fingerprint') != fingerprint:
            raise ValueError('Existing cell fingerprint differs')
        if old.get('status') == 'completed':
            if any(sha(directory / name) != value
                   for name, value in old['files'].items()):
                raise ValueError('Cell checksum mismatch')
            return old['rows'], True
    directory.mkdir(parents=True, exist_ok=True)
    write_json(receipt, dict(status='running', fingerprint=fingerprint, cell=cell))
    started = time.perf_counter()
    try:
        dataset = (make_reliability(cell['seed'],
                                   shift=cell['dataset'].endswith('shift'))
                   if cell['dataset'].startswith('reliability')
                   else load_dataset(cell['dataset']))
        split = split_dataset(dataset, cell['seed'])
        config = protocol['training'].copy()
        config.update(rho=cell['rho'], gamma_brier=cell['gamma_brier'])
        rows, artifacts, metadata = run_methods(
            split, cell['backbone'], cell['seed'], config, [protocol['method']])
        data = artifacts[protocol['method']]
        for row in rows:
            row.update(cell)
        np.savez_compressed(
            directory / 'predictions.npz',
            test_risk=np.asarray(data['test_risk'], dtype=np.float32),
            pred_survival=np.asarray(data['pred_survival'], dtype=np.float32),
            brier_curve=np.asarray(data['brier_curve'], dtype=float),
            test_time=np.asarray(metadata['test_time']),
            test_event=np.asarray(metadata['test_event']),
            grid=np.asarray(metadata['time_grid']))
        torch.save({'predictor': data['predictor_state'],
                    'generator': data['generator_state']}, directory / 'models.pt')
        write_json(directory / 'split_and_preprocessing.json', metadata)
        write_json(directory / 'diagnostics.json', {
            'training': data['diagnostics'],
            'evaluation': data['evaluation_diagnostics']})
        write_json(directory / 'metrics.json', rows)
        files = {p.name: sha(p) for p in directory.iterdir()
                 if p.is_file() and p.name != 'manifest.json'}
        write_json(receipt, dict(
            status='completed', fingerprint=fingerprint, cell=cell,
            elapsed_seconds=time.perf_counter() - started, rows=rows,
            files=files, source_metadata=dataset.metadata,
            n=len(dataset.time), events=int(dataset.event.sum()),
            encoded_features=len(split.feature_names)))
        return rows, False
    except Exception as error:
        write_json(receipt, dict(status='failed', fingerprint=fingerprint,
                                cell=cell, error=str(error),
                                traceback=traceback.format_exc()))
        raise


def summarize(rows, output):
    import numpy as np
    ordered = sorted(rows, key=lambda r: (r['dataset'], r['rho'],
                                         r['gamma_brier'], r['seed']))
    path = Path(output) / 'results_raw.csv'
    temp = path.with_suffix('.csv.tmp')
    with temp.open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(ordered)
    temp.replace(path)
    groups = {}
    for row in ordered:
        group = (row['dataset'], row['rho'], row['gamma_brier'])
        groups.setdefault(group, []).append(row)
    summary = []
    for (dataset, rho, gamma), values in groups.items():
        result = dict(dataset=dataset, rho=rho, gamma_brier=gamma,
                      n=len(values))
        for metric in ['cindex', 'ibs']:
            data = np.asarray([r[metric] for r in values])
            result[metric + '_mean'] = float(data.mean())
            result[metric + '_sd'] = (float(data.std(ddof=1))
                                     if len(values) > 1 else None)
        summary.append(result)
    write_json(Path(output) / 'summary.json', summary)


def consistency_checks(rows, reference_dir, output):
    import numpy as np
    with (reference_dir / 'results_raw.csv').open(encoding='utf-8') as handle:
        reference = list(csv.DictReader(handle))
    diffs = []
    for row in rows:
        if row['rho'] != 1.8 or row['gamma_brier'] != 1.0:
            continue
        suite = 'clinical' if row['dataset'] == 'gbsg2' else 'reliability'
        baseline = [r for r in reference if
                    r['suite'] == suite and r['dataset'] == row['dataset'] and
                    r['backbone'] == row['backbone'] and
                    int(r['seed']) == row['seed'] and
                    r['method'] == 'Surv-piNoise']
        if len(baseline) != 1:
            raise ValueError('Missing or ambiguous corrected-v1 reference')
        diffs.append(dict(dataset=row['dataset'], seed=row['seed'],
                          **{m: row[m] - float(baseline[0][m])
                             for m in ['cindex', 'ibs']}))
    zero = {}
    for row in rows:
        if row['rho'] == 0:
            zero.setdefault((row['dataset'], row['seed']), []).append(row)
    spreads = [dict(dataset=k[0], seed=k[1], gamma_count=len(values),
                    **{m: float(np.ptp([r[m] for r in values]))
                       for m in ['cindex', 'ibs']})
               for k, values in zero.items()]
    max_ref = max((abs(v[m]) for v in diffs for m in ['cindex', 'ibs']), default=0.)
    max_zero = max((v[m] for v in spreads for m in ['cindex', 'ibs']), default=0.)
    report = dict(reference_points=len(diffs), reference_differences=diffs,
                  max_reference_absolute_difference=max_ref,
                  zero_rho_groups=len(spreads), zero_rho_spreads=spreads,
                  max_zero_rho_metric_spread=max_zero,
                  checks_pass=max_ref <= 1e-12 and max_zero <= 1e-12)
    write_json(Path(output) / 'consistency_checks.json', report)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config', type=Path, default=ROOT / 'configs/sensitivity_protocol.json')
    parser.add_argument('--output', type=Path, default=ROOT / 'results/sensitivity_v1')
    parser.add_argument('--workers', type=int, default=6)
    parser.add_argument('--limit', type=int, default=0,
                        help='Run only the first N full-budget cells; partial, resumable output')
    parser.add_argument('--reference-dir', type=Path, default=ROOT / 'results/corrected_v1')
    args = parser.parse_args()
    import numpy, pandas, scipy, torch
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    protocol = json.loads(args.config.read_text(encoding='utf-8'))
    base = json.loads((ROOT / protocol['base_protocol']).read_text(encoding='utf-8'))
    if protocol['training'] != base['training']:
        parser.error('Sensitivity training must match the frozen base protocol')
    sources = {f'survpinoise/{name}.py': sha(ROOT / 'survpinoise' / (name + '.py'))
               for name in ['data', 'losses', 'metrics', 'simulation', 'training',
                            'diagnostics', 'censoring_design']}
    sources.update({'runner': sha(Path(__file__)),
                    'base_protocol': sha(ROOT / protocol['base_protocol']),
                    'censoring_scales': sha(ROOT / 'configs/censoring_scales.json'),
                    'gbsg2_data': sha(ROOT / 'data/raw/gbsg2.arff')})
    environment = dict(python=sys.version, platform=platform.platform(),
                       torch=torch.__version__, numpy=numpy.__version__,
                       pandas=pandas.__version__, scipy=scipy.__version__,
                       threads_per_worker=1, logical_cpus=os.cpu_count())
    plan = jobs(protocol)
    keys = [key(c) for c in plan]
    fingerprint = hashlib.sha256(json.dumps(dict(protocol=protocol, sources=sources,
                                                 environment=environment, plan_keys=keys),
                                           sort_keys=True).encode()).hexdigest()
    receipt = output / 'run.json'
    started = datetime.now(timezone.utc).isoformat()
    if receipt.exists():
        old = json.loads(receipt.read_text(encoding='utf-8'))
        if old.get('fingerprint') != fingerprint:
            parser.error('Output fingerprint differs; use a new output directory')
        started = old['started_utc']
    state = dict(status='running', started_utc=started, fingerprint=fingerprint,
                 protocol=protocol, sources=sources, environment=environment,
                 plan_keys=keys, planned_cells=len(plan), planned_metric_rows=len(plan),
                 partial_limit=args.limit, workers=args.workers)
    write_json(receipt, state)
    selected = plan[:args.limit] if args.limit else plan
    rows, failures = [], []
    print(f'START selected={len(selected)} planned={len(plan)} workers={args.workers} fingerprint={fingerprint}', flush=True)
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
        pending = {pool.submit(worker, c, protocol, str(output), fingerprint): c for c in selected}
        for done, future in enumerate(concurrent.futures.as_completed(pending), 1):
            cell = pending[future]
            try:
                values, resumed = future.result()
                rows.extend(values)
                print(f"DONE {done}/{len(selected)} {key(cell)} {'resumed' if resumed else 'trained'}", flush=True)
            except Exception as error:
                failures.append(dict(cell=cell, error=str(error)))
                print(f'FAILED {key(cell)} {error}', flush=True)
            if done % 10 == 0 or done == len(selected):
                summarize(rows, output)
                state.update(completed_cells=len(rows), failed_cells=len(failures))
                write_json(receipt, state)
    checks = consistency_checks(rows, args.reference_dir.resolve(), output)
    complete = len(rows) == len(plan) and not failures
    status = ('completed' if complete and checks['checks_pass'] else
              'completed_with_failures' if failures else
              'consistency_failed' if not checks['checks_pass'] else 'partial')
    state.update(status=status, completed_cells=len(rows), failed_cells=len(failures),
                 metric_rows=len(rows), completed_utc=datetime.now(timezone.utc).isoformat())
    write_json(output / 'failures.json', failures)
    write_json(receipt, state)
    print(json.dumps(dict(status=status, rows=len(rows), failures=len(failures),
                          max_reference_difference=checks['max_reference_absolute_difference'],
                          max_zero_rho_spread=checks['max_zero_rho_metric_spread'])), flush=True)
    return int(bool(failures) or not checks['checks_pass'])


if __name__ == '__main__':
    raise SystemExit(main())
