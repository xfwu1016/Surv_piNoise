"""Plot the complete, separately recorded rho-by-Brier-weight experiment.

The script refuses partial/duplicate grids.  Each plotted cell is a mean over
the same ten split/initialization seeds, not an interpolated surface.  The
3-D view is accompanied by a labelled 2-D view and a machine-readable table.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import itertools
import json
import math
import platform
import statistics
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATASETS = ("gbsg2", "reliability_nominal", "reliability_shift")
LABELS = {
    "gbsg2": "GBSG2",
    "reliability_nominal": "Reliability: nominal",
    "reliability_shift": "Reliability: sensor shift",
}
RHOS = (0.0, 0.2, 0.8, 1.8, 3.6)
GAMMAS = (0.0, 0.1, 1.0, 10.0)
SEEDS = tuple(range(100, 110))
METRICS = ("cindex", "ibs")
METRIC_LABELS = {"cindex": "C-index (higher is better)",
                 "ibs": "IBS (lower is better)"}
T95_DF9 = 2.2621571627409915


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def read_complete_grid(path: Path) -> list[dict]:
    """Require the prespecified 3 datasets x 5 x 4 x 10 complete grid."""
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        required = {"dataset", "backbone", "seed", "rho", "gamma_brier",
                    "method", "cindex", "ibs"}
        if not required <= set(reader.fieldnames or []):
            raise ValueError(f"Missing CSV columns: {sorted(required - set(reader.fieldnames or []))}")
        rows = list(reader)
    seen: dict[tuple, dict] = {}
    for row in rows:
        row["seed"] = int(row["seed"])
        for field in ("rho", "gamma_brier", "cindex", "ibs"):
            row[field] = float(row[field])
            if not math.isfinite(row[field]):
                raise ValueError(f"Nonfinite {field}: {row}")
        if row["backbone"] != "DeepSurv" or row["method"] != "Surv-piNoise":
            raise ValueError("Only the prespecified DeepSurv / Surv-piNoise grid is supported")
        if not 0 <= row["cindex"] <= 1 or not 0 <= row["ibs"] <= 1:
            raise ValueError("C-index and IBS must lie in [0, 1]")
        key = row["dataset"], row["rho"], row["gamma_brier"], row["seed"]
        if key in seen:
            raise ValueError(f"Duplicate cell: {key}")
        seen[key] = row
    expected = set(itertools.product(DATASETS, RHOS, GAMMAS, SEEDS))
    if set(seen) != expected:
        missing = sorted(expected - set(seen))
        unexpected = sorted(set(seen) - expected)
        raise ValueError(f"Grid incomplete: n={len(seen)}, missing={missing[:10]}, unexpected={unexpected[:10]}")
    receipt_path = path.parent / "run.json"
    if not receipt_path.exists():
        raise ValueError("Missing run.json receipt; training provenance is required")
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    if receipt.get("status") != "completed":
        raise ValueError(f"Training run is not completed: {receipt.get('status')}")
    if receipt.get("failed_cells", 0) != 0:
        raise ValueError("Training receipt reports failed cells")
    return [seen[key] for key in sorted(seen)]


def summarize(rows: list[dict], destination: Path) -> tuple[list[dict], dict]:
    indexed = {(r["dataset"], r["rho"], r["gamma_brier"], r["seed"]): r for r in rows}
    summary = []
    matrices: dict[tuple, list[list[float]]] = {}
    for dataset, metric in itertools.product(DATASETS, METRICS):
        for statistic in ("mean", "sd", "ci95_lower", "ci95_upper"):
            matrices[dataset, metric, statistic] = [[0.0] * len(RHOS) for _ in GAMMAS]
        for gi, gamma in enumerate(GAMMAS):
            for ri, rho in enumerate(RHOS):
                values = [indexed[dataset, rho, gamma, s][metric] for s in SEEDS]
                mean = statistics.mean(values)
                sd = statistics.stdev(values)
                half = T95_DF9 * sd / math.sqrt(len(values))
                differences = [indexed[dataset, rho, gamma, s][metric]
                               - indexed[dataset, 1.8, 1.0, s][metric] for s in SEEDS]
                delta = statistics.mean(differences)
                delta_sd = statistics.stdev(differences)
                delta_half = T95_DF9 * delta_sd / math.sqrt(len(differences))
                result = {"dataset": dataset, "backbone": "DeepSurv", "rho": rho,
                          "gamma_brier": gamma, "metric": metric, "n": len(values),
                          "mean": mean, "sd": sd, "ci95_lower": mean - half,
                          "ci95_upper": mean + half,
                          "paired_difference_from_default": delta,
                          "paired_difference_ci95_lower": delta - delta_half,
                          "paired_difference_ci95_upper": delta + delta_half}
                summary.append(result)
                for statistic in ("mean", "sd", "ci95_lower", "ci95_upper"):
                    matrices[dataset, metric, statistic][gi][ri] = result[statistic]
    with destination.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(summary[0]))
        writer.writeheader()
        writer.writerows(summary)
    return summary, matrices


def figure_style():
    return {
        "font.family": "DejaVu Sans", "font.size": 8,
        "axes.titlesize": 8.5, "axes.labelsize": 8,
        "xtick.labelsize": 7.5, "ytick.labelsize": 7.5,
        "pdf.fonttype": 42, "ps.fonttype": 42,
        "savefig.facecolor": "white", "figure.facecolor": "white",
        "axes.edgecolor": "#555555", "axes.linewidth": 0.6,
        "text.color": "#222222", "axes.labelcolor": "#222222",
    }


def save_figure(fig, output: Path, stem: str, dpi: int, files: list[dict]):
    from PIL import Image
    for suffix in ("pdf", "png"):
        path = output / f"{stem}.{suffix}"
        fig.savefig(path, dpi=dpi, bbox_inches=None, facecolor="white", transparent=False)
        if suffix == "png":
            # Force an opaque RGB file without changing any visual pixel.
            with Image.open(path) as im:
                rgb = im.convert("RGB")
                rgb.save(path, dpi=(dpi, dpi))
            with Image.open(path) as im:
                metadata = {"pixel_width": im.width, "pixel_height": im.height,
                            "mode": im.mode, "dpi": list(im.info.get("dpi", ())) }
        else:
            metadata = {"vector": True}
        files.append({"file": path.name, "bytes": path.stat().st_size,
                      "sha256": sha(path), **metadata})


def draw_figures(matrices: dict, output: Path, width_mm: float, height_mm: float, dpi: int) -> tuple[list[dict], dict]:
    import numpy as np
    import matplotlib as mpl
    mpl.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import Normalize
    from matplotlib.patches import Rectangle
    from matplotlib.ticker import MaxNLocator

    files: list[dict] = []
    cmaps = {"cindex": mpl.colormaps["viridis"], "ibs": mpl.colormaps["viridis_r"]}
    limits = {}
    for metric in METRICS:
        values = np.concatenate([np.asarray(matrices[d, metric, "mean"]).ravel() for d in DATASETS])
        low, high = float(values.min()), float(values.max())
        margin = max((high - low) * 0.04, 0.001)
        limits[metric] = (max(0.0, low - margin), min(1.0, high + margin))
    norms = {metric: Normalize(*limits[metric]) for metric in METRICS}
    ibs_top = min(1.0, math.ceil(max(float(np.max(matrices[d, "ibs", "mean"]))
                                  for d in DATASETS) * 1.12 * 20) / 20)
    with plt.rc_context(figure_style()):
        # Fixed page dimensions keep final-size QA meaningful. Three rows give
        # every prespecified condition equal space, rather than selecting a
        # favorable dataset for the main display.
        fig = plt.figure(figsize=(width_mm / 25.4, height_mm / 25.4))
        grid = fig.add_gridspec(3, 2, left=0.015, right=0.965, bottom=0.105,
                               top=0.97, hspace=0.35, wspace=0.07)
        x, y = np.meshgrid(np.arange(len(RHOS)), np.arange(len(GAMMAS)))
        x, y = x.ravel(), y.ravel()
        for row, dataset in enumerate(DATASETS):
            for col, metric in enumerate(METRICS):
                ax = fig.add_subplot(grid[row, col], projection="3d")
                ax.computed_zorder = False
                values = np.asarray(matrices[dataset, metric, "mean"]).ravel()
                ax.bar3d(x - 0.31, y - 0.31, np.zeros_like(values),
                         0.62, 0.62, values, color=cmaps[metric](norms[metric](values)),
                         shade=False, edgecolor="#555555", linewidth=0.24,
                         zsort="average")
                ax.set_proj_type("ortho")
                ax.view_init(elev=28, azim=-55)
                ax.set_box_aspect((1.15, 1.0, 0.95))
                ax.set_xticks(range(len(RHOS)), [f"{v:g}" for v in RHOS])
                ax.set_yticks(range(len(GAMMAS)), [f"{v:g}" for v in GAMMAS])
                ax.tick_params(axis="x", pad=-1, labelsize=6.6)
                ax.tick_params(axis="y", pad=-1, labelsize=7)
                ax.tick_params(axis="z", pad=0, labelsize=7)
                for label in ax.get_xticklabels():
                    label.set_rotation(-12)
                    label.set_horizontalalignment("right")
                ax.set_xlabel(r"$\rho$", labelpad=-2)
                ax.set_ylabel(r"$\gamma_B$", labelpad=-2)
                ax.set_zlabel("C-index" if metric == "cindex" else "IBS", labelpad=0, fontsize=7.5)
                ax.set_zlim(0, 1 if metric == "cindex" else ibs_top)
                default_height = float(matrices[dataset, metric, "mean"][2][3])
                ax.scatter([3], [2], [default_height], marker="D", s=15,
                           facecolor="black", edgecolor="white", linewidth=0.4,
                           depthshade=False, zorder=20)
                ax.zaxis.set_major_locator(MaxNLocator(4))
                for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
                    axis.pane.set_facecolor((0.97, 0.97, 0.97, 1.0))
                    axis._axinfo["grid"].update(color="#dddddd", linewidth=0.45)
                letter = "abcdef"[row * 2 + col]
                ax.set_title(f"({letter}) {LABELS[dataset]}", pad=3, fontsize=8.0)
        for col, metric in enumerate(METRICS):
            cax = fig.add_axes((0.10 + col * 0.49, 0.048, 0.33, 0.012))
            cb = fig.colorbar(mpl.cm.ScalarMappable(norm=norms[metric], cmap=cmaps[metric]),
                              cax=cax, orientation="horizontal")
            cb.ax.tick_params(labelsize=7, length=2, pad=1)
            cb.locator = MaxNLocator(4)
            cb.update_ticks()
            cb.set_label(METRIC_LABELS[metric], labelpad=2, fontsize=7.2)
        save_figure(fig, output, "sensitivity_3d", dpi, files)
        plt.close(fig)

        # A 2-D alternative retains every grid cell without perspective or
        # hidden back bars. The annotated SD conveys between-repeat spread.
        fig, axes = plt.subplots(3, 2, figsize=(width_mm / 25.4, (height_mm - 8) / 25.4))
        fig.subplots_adjust(left=0.115, right=0.97, bottom=0.13, top=0.95,
                            hspace=0.52, wspace=0.25)
        for row, dataset in enumerate(DATASETS):
            for col, metric in enumerate(METRICS):
                ax = axes[row, col]
                values = np.asarray(matrices[dataset, metric, "mean"])
                spread = np.asarray(matrices[dataset, metric, "sd"])
                ax.imshow(values, origin="lower", interpolation="nearest", aspect="auto",
                          cmap=cmaps[metric], norm=norms[metric])
                ax.set_xticks(range(len(RHOS)), [f"{v:g}" for v in RHOS])
                ax.set_yticks(range(len(GAMMAS)), [f"{v:g}" for v in GAMMAS])
                ax.set_xlabel(r"$\rho$", labelpad=1)
                ax.set_ylabel(r"$\gamma_B$", labelpad=1)
                ax.tick_params(length=0, pad=3)
                ax.set_xticks(np.arange(-0.5, len(RHOS)), minor=True)
                ax.set_yticks(np.arange(-0.5, len(GAMMAS)), minor=True)
                ax.grid(which="minor", color="white", linewidth=0.6)
                ax.tick_params(which="minor", bottom=False, left=False)
                ax.add_patch(Rectangle((2.5, 1.5), 1, 1, fill=False,
                                       edgecolor="black", linewidth=1.2))
                for yi, xi in itertools.product(range(len(GAMMAS)), range(len(RHOS))):
                    rgb = cmaps[metric](norms[metric](values[yi, xi]))[:3]
                    # Contrast assessed against actual rendered cell colors.
                    linear = [v / 12.92 if v <= .04045 else ((v + .055) / 1.055) ** 2.4 for v in rgb]
                    luminance = .2126 * linear[0] + .7152 * linear[1] + .0722 * linear[2]
                    foreground = "black" if (luminance + .05) / .05 >= 4.5 else "white"
                    text = f"{values[yi, xi]:.3f}\n({spread[yi, xi]:.3f})"
                    ax.text(xi, yi, text, ha="center", va="center", fontsize=6.7,
                            linespacing=1.12, color=foreground)
                letter = "abcdef"[row * 2 + col]
                ax.set_title(f"({letter}) {LABELS[dataset]}", fontsize=8, pad=5)
        for col, metric in enumerate(METRICS):
            cax = fig.add_axes((0.15 + col * .46, .062, .30, .012))
            cb = fig.colorbar(mpl.cm.ScalarMappable(norm=norms[metric], cmap=cmaps[metric]),
                              cax=cax, orientation="horizontal")
            cb.ax.tick_params(labelsize=7, length=2, pad=1)
            cb.locator = MaxNLocator(4)
            cb.update_ticks()
            cb.set_label(METRIC_LABELS[metric], labelpad=2, fontsize=7.2)
        save_figure(fig, output, "sensitivity_heatmap", dpi, files)
        plt.close(fig)
    return files, {"mean_color_limits": {k: list(v) for k, v in limits.items()},
                   "bar_z_limits": {"cindex": [0, 1], "ibs": [0, ibs_top]}}


def conclusions(summary: list[dict], rows: list[dict]) -> dict:
    """Provide values for evidence-led prose, without significance selection."""
    result = {}
    for dataset in DATASETS:
        report = {}
        for metric in METRICS:
            cells = [r for r in summary if r["dataset"] == dataset and r["metric"] == metric]
            default = next(r for r in cells if r["rho"] == 1.8 and r["gamma_brier"] == 1)
            zero = next(r for r in cells if r["rho"] == 0 and r["gamma_brier"] == 1)
            nonzero = [r for r in cells if r["rho"] > 0]
            report[metric] = {
                "all_cell_mean_min": min(r["mean"] for r in cells),
                "all_cell_mean_max": max(r["mean"] for r in cells),
                "nonzero_rho_mean_min": min(r["mean"] for r in nonzero),
                "nonzero_rho_mean_max": max(r["mean"] for r in nonzero),
                "default": default,
                "zero_rho": zero,
                "count_nonzero_cells_better_mean_than_zero": sum(
                    r["mean"] > zero["mean"] if metric == "cindex" else r["mean"] < zero["mean"]
                    for r in nonzero),
                "count_nonzero_cells": len(nonzero),
            }
        result[dataset] = report
    invariant = {}
    for dataset in DATASETS:
        for metric in METRICS:
            invariant[dataset + ":" + metric] = max(
                max(r[metric] for r in rows if r["dataset"] == dataset and r["rho"] == 0 and r["seed"] == s)
                - min(r[metric] for r in rows if r["dataset"] == dataset and r["rho"] == 0 and r["seed"] == s)
                for s in SEEDS)
    return {"dataset_reports": result, "zero_rho_max_gamma_dependence": invariant,
            "scope": "Exploratory fixed-grid sensitivity on the same ten paired seeds; the default is unchanged. No test-selected optimum, multiplicity-adjusted inference or general robustness claim."}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "results/sensitivity_v1/results_raw.csv")
    parser.add_argument("--output", type=Path, default=ROOT / "results/sensitivity_v1/figures")
    parser.add_argument("--width-mm", type=float, default=130.0)
    parser.add_argument("--height-mm", type=float, default=180.0)
    parser.add_argument("--dpi", type=int, default=600)
    args = parser.parse_args()
    if not 120 <= args.width_mm <= 190 or not 160 <= args.height_mm <= 240 or args.dpi < 300:
        parser.error("Use a width of 120-190 mm, a height of 160-240 mm and at least 300 dpi")
    rows = read_complete_grid(args.input)
    args.output.mkdir(parents=True, exist_ok=True)
    summary_path = args.output / "sensitivity_summary.csv"
    summary, matrices = summarize(rows, summary_path)
    report_path = args.output / "sensitivity_findings.json"
    write_json(report_path, conclusions(summary, rows))
    files, scales = draw_figures(matrices, args.output, args.width_mm, args.height_mm, args.dpi)
    caption = (
        "Joint sensitivity to perturbation budget and validation Brier weight. "
        "Rows show GBSG2, synthetic reliability without sensor shift, and synthetic reliability with sensor shift; "
        "columns show Uno's C-index (higher is better) and integrated Brier score (IBS; lower is better). "
        "The grid crosses rho in {0, 0.2, 0.8, 1.8, 3.6} with gamma_B in {0, 0.1, 1, 10}. "
        "Each height and color represent the mean over ten paired split/initialization seeds (100-109) using DeepSurv. "
        "Parameter positions are equally spaced grid categories; neither horizontal axis is logarithmic. "
        "Bar axes begin at zero. Each metric uses a common color scale and common vertical limits across all three datasets; "
        "the two metrics have separate scales. Black diamonds in the 3-D view and black cell outlines in the 2-D view mark the original default. "
        "No interpolation or smoothing is applied. "
        "All other settings follow the reference experiment, and the original default (rho=1.8, gamma_B=1) is unchanged. "
        "The accompanying two-dimensional view labels each cell with its mean and sample SD in parentheses. "
        "Unadjusted 95% t intervals across repeated seeds and paired differences from the default are supplied in the source table. "
        "These intervals summarize repeat variability and do not establish population-level uncertainty or simultaneous significance."
    )
    (args.output / "sensitivity_caption.txt").write_text(caption + "\n", encoding="utf-8")
    import numpy
    import matplotlib
    manifest = {
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "input": str(args.input.resolve()), "input_sha256": sha(args.input),
        "run_receipt_sha256": sha(args.input.parent / "run.json"),
        "script_sha256": sha(Path(__file__)),
        "software": {"python": sys.version, "numpy": numpy.__version__,
                     "matplotlib": matplotlib.__version__, "platform": platform.platform()},
        "datasets": list(DATASETS), "seeds": list(SEEDS),
        "rho_grid": list(RHOS), "gamma_brier_grid": list(GAMMAS),
        "input_rows": len(rows), "summary_rows": len(summary),
        "transformations": ["Arithmetic mean and sample SD across ten seed repetitions at each measured grid point",
                            "Unadjusted t95% intervals with df=9; paired differences use identical seeds",
                            "No smoothing, interpolation, exclusions, winsorization, or metric renormalization"],
        "axis_semantics": "rho and gamma_B are categorical grid positions with true numeric tick labels; 3-D bars have a zero baseline",
        "uncertainty": "Seed/split repeat variability; same seeds reused across parameter settings; not simultaneous inference",
        "destination": {"journal": "Information Sciences", "phase": "submission",
                        "width_mm": args.width_mm, "3d_height_mm": args.height_mm, "2d_height_mm": args.height_mm - 8,
                        "format_compliance": "Provisional figure choices; not a certification of journal requirements"},
        **scales,
        "summary_sha256": sha(summary_path), "findings_sha256": sha(report_path),
        "files": files,
        "alt_text": "Six panels compare measured parameter-grid means for DeepSurv in GBSG2 and nominal/shifted synthetic reliability. A companion annotated heatmap and CSV expose all values and between-seed spread without 3-D occlusion.",
        "caption": caption,
    }
    write_json(args.output / "sensitivity_figure_manifest.json", manifest)
    print(json.dumps({"rows": len(rows), "figures": [v["file"] for v in files],
                      "output": str(args.output.resolve())}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
