"""Execute every predeclared cell; preserve all outcomes and selection records."""
from __future__ import annotations
import argparse
import concurrent.futures
import csv
import hashlib
import json
import os
import platform
import sys
import time
import traceback
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def json_default(value):
    if hasattr(value,'tolist'):return value.tolist()
    raise TypeError(type(value).__name__)


def write_json(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2,allow_nan=False,default=json_default)+'\n',encoding='utf-8');temp.replace(path)


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def jobs(protocol,suite='all',smoke=False):
    cells=[]
    if suite in ('all','simulation'):
        for scenario in protocol['simulation_scenarios']:
            for censor in protocol['censoring_levels']:
                seeds=protocol['seeds']+(protocol['simulation_central_extra_seeds']if censor==.4 else [])
                for backbone in protocol['backbones']:
                    for seed in seeds:
                        cells.append({'suite':'simulation','dataset':scenario,'censoring':censor,'backbone':backbone,'seed':seed,'methods':protocol['methods']})
    if suite in ('all','clinical'):
        for name in protocol['clinical_datasets']:
            for backbone in protocol['backbones']:
                for seed in protocol['seeds']:
                    cells.append({'suite':'clinical','dataset':name,'censoring':None,'backbone':backbone,'seed':seed,'methods':protocol['methods']})
    if suite in ('all','reliability'):
        for name in ['reliability_nominal','reliability_shift']:
            for seed in protocol['seeds']:
                cells.append({'suite':'reliability','dataset':name,'censoring':.38,'backbone':'DeepSurv','seed':seed,'methods':protocol['reliability_methods']})
    if suite in ('all','ablation'):
        for name in protocol['ablation_datasets']:
            for seed in protocol['seeds']:
                cells.append({'suite':'ablation','dataset':name,'censoring':.38 if name.startswith('reliability')else None,'backbone':'DeepSurv','seed':seed,'methods':protocol['ablation_methods']})
    if smoke:
        return [{'suite':'smoke','dataset':'S3','censoring':.4,'backbone':'DeepSurv','seed':999,'methods':protocol['methods']},
                {'suite':'smoke','dataset':'reliability_shift','censoring':.38,'backbone':'DeepSurv','seed':999,'methods':protocol['ablation_methods']}]
    return cells


def key(cell):
    censor='observed' if cell['censoring']is None else f"{cell['censoring']:.2f}"
    return f"{cell['suite']}__{cell['dataset']}__{censor}__{cell['backbone']}__{cell['seed']}"


def worker(cell,protocol,output,fingerprint,smoke):
    import numpy as np
    import torch
    from survpinoise.data import load_dataset,split_dataset
    from survpinoise.simulation import make_simulation,make_reliability
    from survpinoise.training import run_methods
    from survpinoise.diagnostics import true_survival,oracle_survival_error,normalized_riskset_entropy
    torch.set_num_threads(1)
    directory=Path(output)/'cells'/key(cell)
    receipt=directory/'manifest.json'
    if receipt.exists():
        previous=json.loads(receipt.read_text())
        if previous.get('fingerprint')!=fingerprint:raise ValueError('Existing cell fingerprint differs')
        if previous.get('status')=='completed':
            if any(sha(directory/name)!=value for name,value in previous['files'].items()):raise ValueError('Cell checksum mismatch')
            return previous['rows'],True
    directory.mkdir(parents=True,exist_ok=True)
    started=time.perf_counter()
    write_json(receipt,{'status':'running','fingerprint':fingerprint,'cell':cell})
    try:
        if cell['dataset'].startswith('S'):
            dataset=make_simulation(cell['dataset'],cell['seed'],cell['censoring'],smoke=smoke)
        elif cell['dataset'].startswith('reliability'):
            dataset=make_reliability(cell['seed'],shift=cell['dataset'].endswith('shift'),smoke=smoke)
        else:dataset=load_dataset(cell['dataset'])
        split=split_dataset(dataset,cell['seed'])
        cfg=protocol['training'].copy()
        if smoke:cfg.update(warm_epochs=2,adapt_epochs=2,refit_epochs=3,fixed_radii=[.2])
        rows,artifacts,metadata=run_methods(split,cell['backbone'],cell['seed'],cfg,cell['methods'])
        truth=(true_survival(dataset.x.iloc[split.test.indices].to_numpy(),np.asarray(metadata['time_grid']),cell['dataset']) if cell['dataset'].startswith('S') else None)
        for row in rows:
            row.update({field:cell[field]for field in ['suite','dataset','censoring','backbone']})
            data=artifacts[row['method']]
            row['riskset_entropy']=normalized_riskset_entropy(split.test.time,split.test.event,np.asarray(data['test_risk']))
            row['oracle_ise']=(oracle_survival_error(np.asarray(data['pred_survival']),truth,np.asarray(metadata['time_grid'])) if truth is not None else None)
        predictions={};weights={};diagnostics={}
        for index,(method,data)in enumerate(artifacts.items()):
            predictions[f'method_{index}_risk']=np.asarray(data['test_risk'],dtype=np.float32)
            predictions[f'method_{index}_survival']=np.asarray(data['pred_survival'],dtype=np.float32)
            predictions[f'method_{index}_brier_curve']=np.asarray(data['brier_curve'],dtype=float)
            weights[method]={'predictor':data['predictor_state'],'generator':data['generator_state']}
            diagnostics[method]={'method_index':index,'training':data['diagnostics'],'evaluation':data['evaluation_diagnostics']}
        predictions['test_time']=np.asarray(metadata['test_time']);predictions['test_event']=np.asarray(metadata['test_event']);predictions['grid']=np.asarray(metadata['time_grid'])
        np.savez_compressed(directory/'predictions.npz',**predictions)
        torch.save(weights,directory/'models.pt')
        write_json(directory/'split_and_preprocessing.json',metadata)
        write_json(directory/'diagnostics.json',diagnostics)
        write_json(directory/'metrics.json',rows)
        files={p.name:sha(p)for p in directory.iterdir()if p.is_file()and p.name!='manifest.json'}
        write_json(receipt,{'status':'completed','fingerprint':fingerprint,'cell':cell,'elapsed_seconds':time.perf_counter()-started,'rows':rows,'files':files,'source_metadata':dataset.metadata,'n':len(dataset.time),'events':int(dataset.event.sum()),'encoded_features':len(split.feature_names)})
        return rows,False
    except Exception as error:
        write_json(receipt,{'status':'failed','fingerprint':fingerprint,'cell':cell,'error':str(error),'traceback':traceback.format_exc()})
        raise


def summarize(rows,output):
    from survpinoise.metrics import paired_summary
    groups={}
    for row in rows:
        group=tuple(row.get(k)for k in ['suite','dataset','censoring','backbone'])
        groups.setdefault(group,[]).append(row)
    reports=[]
    for group,values in sorted(groups.items(),key=lambda item:str(item[0])):
        baseline='Clean' if any(row['method']=='Clean'for row in values)else 'Surv-piNoise'
        report=paired_summary(values,baseline=baseline)
        report.update(dict(zip(['suite','dataset','censoring','backbone'],group)));reports.append(report)
    write_json(Path(output)/'summary.json',reports)
    fields=['suite','dataset','censoring','backbone','seed','method','cindex','ibs','oracle_ise','riskset_entropy']
    path=Path(output)/'results_raw.csv';temp=path.with_suffix('.csv.tmp')
    with temp.open('w',newline='',encoding='utf-8')as handle:
        writer=csv.DictWriter(handle,fieldnames=fields);writer.writeheader();writer.writerows(sorted(rows,key=lambda r:str([r[k]for k in fields[:6]])))
    temp.replace(path)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config',type=Path,default=ROOT/'configs/protocol.json')
    parser.add_argument('--output',type=Path,default=ROOT/'results/corrected_v1')
    parser.add_argument('--suite',choices=['all','simulation','clinical','reliability','ablation'],default='all')
    parser.add_argument('--workers',type=int,default=6)
    parser.add_argument('--smoke',action='store_true')
    args=parser.parse_args()
    import torch,numpy,pandas
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=True)
    protocol=json.loads(args.config.read_text())
    modules=['data.py','losses.py','metrics.py','simulation.py','training.py','diagnostics.py','censoring_design.py']
    sources={name:sha(ROOT/'survpinoise'/name)for name in modules}
    sources['runner']=sha(Path(__file__))
    sources['censoring_scales']=sha(ROOT/'configs/censoring_scales.json')
    environment={'python':sys.version,'platform':platform.platform(),'torch':torch.__version__,'numpy':numpy.__version__,'pandas':pandas.__version__,'threads_per_worker':1,'logical_cpus':os.cpu_count()}
    plan=jobs(protocol,args.suite,args.smoke)
    plan_keys=[key(cell)for cell in plan]
    fingerprint=hashlib.sha256(json.dumps({'protocol':protocol,'sources':sources,'environment':environment,'smoke':args.smoke,'suite':args.suite,'plan_keys':plan_keys},sort_keys=True).encode()).hexdigest()
    receipt=output/'run.json'
    started=datetime.now(timezone.utc).isoformat()
    if receipt.exists():
        old=json.loads(receipt.read_text())
        if old.get('fingerprint')!=fingerprint:parser.error('Output fingerprint differs; select a NEW output directory')
        started=old['started_utc']
    write_json(receipt,{'started_utc':started,'fingerprint':fingerprint,'protocol':protocol,'sources':sources,'environment':environment,'requested_suite':args.suite,'plan_keys':plan_keys,'planned_cells':len(plan),'planned_metric_rows':sum(len(c['methods'])for c in plan),'status':'running','smoke':args.smoke})
    rows=[];failures=[];done=0
    print(f"START cells={len(plan)} methods={sum(len(c['methods'])for c in plan)} workers={args.workers} fingerprint={fingerprint}",flush=True)
    with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers)as pool:
        pending={pool.submit(worker,cell,protocol,str(output),fingerprint,args.smoke):cell for cell in plan}
        for future in concurrent.futures.as_completed(pending):
            cell=pending[future];done+=1
            try:
                values,resumed=future.result();rows.extend(values)
                print(f"DONE {done}/{len(plan)} {key(cell)} {'resumed'if resumed else 'trained'}",flush=True)
            except Exception as error:
                failures.append({'cell':cell,'error':str(error)});print(f"FAILED {key(cell)} {error}",flush=True)
            if done%10==0 or done==len(plan):summarize(rows,output)
    write_json(output/'failures.json',failures)
    state=json.loads(receipt.read_text());state.update(status='completed'if not failures else 'completed_with_failures',completed_cells=len(plan)-len(failures),failed_cells=len(failures),metric_rows=len(rows),completed_utc=datetime.now(timezone.utc).isoformat());write_json(receipt,state)
    print(json.dumps({'status':state['status'],'cells':state['completed_cells'],'rows':len(rows),'failures':len(failures)}),flush=True)
    return int(bool(failures))


if __name__=='__main__':raise SystemExit(main())
