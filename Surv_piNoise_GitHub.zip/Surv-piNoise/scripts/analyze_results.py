"""Analyze the COMPLETE locked rerun, retaining favorable and unfavorable cells.

Usage (after the formal run and figure-authoring review):
    python scripts/analyze_results.py --input results/corrected_v1

Writes analysis/*.csv and findings.json, tables/*.tex, and six PDF/PNG figure
pairs under --output (defaults to --input). No training or evaluation is run.
All primary estimates come from results_raw.csv; cell artifacts and runner
summary.json are independently cross-checked. Intervals pair the same seeds
WITHIN a condition and never average over different datasets or backbones.
Full-vs-Clean/Gaussian/Joint comparisons additionally receive a separate Holm
adjustment within each primary endpoint x comparator family. Displayed 95%
intervals remain unadjusted and exploratory. Clinical seed intervals describe
resplitting of fixed datasets, not patient-population uncertainty.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import run_experiments as runner

CONDITION = ("suite", "dataset", "censoring", "backbone")
PRIMARY = ("cindex", "ibs")
FULL = "Surv-piNoise"
FULL_COMPARATORS = ("Clean", "Fixed Gaussian", "Joint generator")
METRIC_LABEL = {"cindex": "C-index", "ibs": "IBS", "oracle_ise": "Oracle survival ISE", "riskset_entropy": "Normalized risk-set entropy"}
COLORS = {"Fixed Gaussian": "#0072B2", "Joint generator": "#D55E00", FULL: "#009E73", "Fixed sphere": "#CC79A7",
          "No outcome": "#0072B2", "No MMD": "#D55E00", "No stability": "#009E73", "Fixed variance": "#CC79A7",
          "Nonzero mean": "#8B6508", "Cox-only outer": "#202020"}
MARKERS = {"Fixed Gaussian": "o", "Joint generator": "s", FULL: "D", "Fixed sphere": "^", "No outcome": "o",
           "No MMD": "s", "No stability": "D", "Fixed variance": "^", "Nonzero mean": "v", "Cox-only outer": "X"}
DATASET_LABELS = {"support": "SUPPORT", "metabric": "METABRIC", "flchain": "FLCHAIN", "gbsg2": "GBSG2",
                  "reliability_nominal": "Nominal", "reliability_shift": "Shift"}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def jsonable(value):
    if isinstance(value, dict):
        return {str(k): jsonable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list, np.ndarray)):
        return [jsonable(v) for v in value]
    if isinstance(value, (np.integer, np.bool_)):
        return value.item()
    if isinstance(value, (float, np.floating)):
        return float(value) if math.isfinite(value) else None
    return value


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(jsonable(value), indent=2, allow_nan=False) + "\n", encoding="utf-8")


def censor_value(value):
    if value is None or pd.isna(value) or str(value).strip().lower() in ("", "none", "nan"):
        return None
    return round(float(value), 12)


def condition_key(row):
    return (str(row["suite"]), str(row["dataset"]), censor_value(row.get("censoring")), str(row["backbone"]))


def condition_dict(key):
    return dict(zip(CONDITION, key))


def row_key(row):
    return condition_key(row) + (int(row["seed"]), str(row["method"]))


def metric_stats(values):
    from scipy.stats import t
    values = np.asarray(values, dtype=float)
    if len(values) < 2 or not np.isfinite(values).all():
        raise ValueError("At least two finite paired-seed observations are required.")
    mean, sd = float(values.mean()), float(values.std(ddof=1))
    se = sd / math.sqrt(len(values))
    half = float(t.ppf(.975, len(values) - 1)) * se
    return {"n": len(values), "mean": mean, "sd": sd, "se": se, "ci_low": mean - half, "ci_high": mean + half,
            "minimum": float(values.min()), "maximum": float(values.max())}


def load_complete_run(directory, oracle_field, entropy_field):
    """Fail closed on missing/extra rows, partial runs or inconsistent receipts."""
    directory = directory.resolve()
    required = ("run.json", "summary.json", "results_raw.csv", "failures.json")
    for filename in required:
        if not (directory / filename).is_file():
            raise ValueError(f"Missing required result file: {directory / filename}")
    run = json.loads((directory / "run.json").read_text(encoding="utf-8"))
    if run.get("status") != "completed" or run.get("smoke") or run.get("failed_cells", 0):
        raise ValueError("Analysis requires a completed, non-smoke, failure-free formal run.")
    if json.loads((directory / "failures.json").read_text(encoding="utf-8")):
        raise ValueError("failures.json is not empty.")
    protocol = run["protocol"]
    plan = runner.jobs(protocol)
    expected = {condition_key(cell) + (int(cell["seed"]), method) for cell in plan for method in cell["methods"]}
    if len(expected) != sum(len(cell["methods"]) for cell in plan):
        raise ValueError("Locked protocol contains duplicate metric rows.")
    if run.get("planned_cells") != len(plan) or run.get("completed_cells") != len(plan) or run.get("metric_rows") != len(expected):
        raise ValueError("run.json planned/completed counts do not match its own protocol.")
    frame = pd.read_csv(directory / "results_raw.csv", keep_default_na=False)
    if not set(CONDITION + ("seed", "method") + PRIMARY).issubset(frame.columns):
        raise ValueError("results_raw.csv has an incomplete primary schema.")
    raw_seeds = pd.to_numeric(frame["seed"], errors="raise").to_numpy(dtype=float)
    if not np.isfinite(raw_seeds).all() or np.any(raw_seeds < 0) or np.any(raw_seeds != np.floor(raw_seeds)):
        raise ValueError("Seed identifiers must be nonnegative integers.")
    frame["seed"] = raw_seeds.astype(np.int64)
    frame["censoring"] = frame["censoring"].map(censor_value)
    records = frame.to_dict("records")
    keys = [row_key(row) for row in records]
    if len(keys) != len(set(keys)) or set(keys) != expected:
        raise ValueError(f"Formal rows differ from protocol: duplicates={len(keys)-len(set(keys))}, missing={len(expected-set(keys))}, extra={len(set(keys)-expected)}.")
    record_map = dict(zip(keys, records))
    for metric in PRIMARY:
        frame[metric] = pd.to_numeric(frame[metric], errors="raise")
        if not np.isfinite(frame[metric]).all() or (frame[metric] < 0).any() or (metric == "cindex" and (frame[metric] > 1).any()):
            raise ValueError(f"Invalid primary numeric values: {metric}.")
    # Core decisions always use the CSV primary values, not a re-evaluation.
    audit = []
    fingerprint = run["fingerprint"]
    secondary = (oracle_field, entropy_field)
    for cell in plan:
        cell_dir = directory / "cells" / runner.key(cell)
        manifest = json.loads((cell_dir / "manifest.json").read_text(encoding="utf-8"))
        if manifest.get("status") != "completed" or manifest.get("fingerprint") != fingerprint:
            raise ValueError(f"Incomplete or mismatched cell manifest: {cell_dir}")
        if condition_key(manifest["cell"]) != condition_key(cell) or int(manifest["cell"]["seed"]) != int(cell["seed"]):
            raise ValueError(f"Cell identity mismatch: {cell_dir}")
        files = manifest.get("files", {})
        if not {"predictions.npz", "diagnostics.json", "metrics.json", "split_and_preprocessing.json"}.issubset(files):
            raise ValueError(f"Cell receipt lacks required artifacts: {cell_dir}")
        for filename, expected_hash in files.items():
            if Path(filename).name != filename or not (cell_dir / filename).is_file() or sha(cell_dir / filename) != expected_hash:
                raise ValueError(f"Missing/changed cell artifact: {cell_dir / filename}")
        cell_rows = json.loads((cell_dir / "metrics.json").read_text(encoding="utf-8"))
        if len(cell_rows) != len(cell["methods"]) or {row_key(row) for row in cell_rows} != {condition_key(cell) + (int(cell["seed"]), method) for method in cell["methods"]}:
            raise ValueError(f"metrics.json is missing methods: {cell_dir}")
        manifest_rows = {row_key(row): row for row in manifest["rows"]}
        if len(manifest_rows) != len(manifest["rows"]) or set(manifest_rows) != {row_key(row) for row in cell_rows}:
            raise ValueError(f"Duplicate/missing manifest metric rows: {cell_dir}")
        for row in cell_rows:
            identity = row_key(row)
            if identity not in manifest_rows:
                raise ValueError(f"metrics/manifest row mismatch: {cell_dir}")
            raw = record_map[identity]
            for metric in PRIMARY:
                if not math.isclose(float(raw[metric]), float(row[metric]), rel_tol=1e-12, abs_tol=1e-12) or not math.isclose(float(row[metric]), float(manifest_rows[identity][metric]), rel_tol=1e-12, abs_tol=1e-12):
                    raise ValueError(f"CSV/cell/manifest disagreement for {identity}, {metric}.")
            for metric in secondary:
                value = raw.get(metric)
                if value in (None, ""):
                    value = row.get(metric)
                if value is not None and value != "":
                    value = float(value)
                    if not math.isfinite(value):
                        raise ValueError(f"Non-finite secondary diagnostic: {identity}, {metric}.")
                    if row.get(metric) is not None and not math.isclose(value, float(row[metric]), rel_tol=1e-10, abs_tol=1e-12):
                        raise ValueError(f"CSV/cell diagnostic disagreement: {identity}, {metric}.")
                    raw[metric] = value
        diagnostics = json.loads((cell_dir / "diagnostics.json").read_text(encoding="utf-8"))
        if set(diagnostics) != set(cell["methods"]):
            raise ValueError(f"Missing method diagnostics: {cell_dir}")
        with np.load(cell_dir / "predictions.npz", allow_pickle=False) as predictions:
            grid = predictions["grid"]
            times, events = predictions["test_time"], predictions["test_event"]
            if grid.ndim != 1 or len(grid) < 2 or not np.isfinite(grid).all() or np.any(np.diff(grid) <= 0):
                raise ValueError(f"Invalid prediction grid: {cell_dir}")
            if times.ndim != 1 or len(times) != len(events) or not np.isfinite(times).all() or not np.isin(events, [0, 1]).all():
                raise ValueError(f"Invalid prediction outcomes: {cell_dir}")
            indices = []
            for method in cell["methods"]:
                index = int(diagnostics[method]["method_index"])
                indices.append(index)
                risks = predictions[f"method_{index}_risk"]
                survival = predictions[f"method_{index}_survival"]
                brier = predictions[f"method_{index}_brier_curve"]
                if risks.shape != times.shape or survival.shape != (len(times), len(grid)) or brier.shape != grid.shape:
                    raise ValueError(f"Prediction dimensions disagree: {cell_dir}, {method}.")
                if not np.isfinite(risks).all() or not np.isfinite(survival).all() or not np.isfinite(brier).all() or np.any((survival < 0) | (survival > 1)) or np.any(np.diff(survival, axis=1) > 2e-6):
                    raise ValueError(f"Invalid saved predictions: {cell_dir}, {method}.")
                curve_ibs = float(np.sum(.5 * (brier[1:] + brier[:-1]) * np.diff(grid)) / (grid[-1] - grid[0]))
                if not math.isclose(curve_ibs, float(record_map[condition_key(cell) + (int(cell["seed"]), method)]["ibs"]), abs_tol=1e-11, rel_tol=1e-9):
                    raise ValueError(f"Saved Brier curve disagrees with CSV IBS: {cell_dir}, {method}.")
            if len(indices) != len(set(indices)):
                raise ValueError(f"Duplicated prediction method indices: {cell_dir}")
        audit.append({"cell": runner.key(cell), "n_test": len(times), "grid_points": len(grid), "files_verified": len(files)})
    # Rebuild with secondary values supplied by a cell when absent in the CSV.
    frame = pd.DataFrame(records)
    frame["censoring"] = frame["censoring"].map(censor_value)
    for metric in PRIMARY + secondary:
        if metric not in frame:
            frame[metric] = np.nan
        frame[metric] = pd.to_numeric(frame[metric].replace("", np.nan), errors="raise")
    simulation = frame["suite"] == "simulation"
    if frame.loc[simulation, oracle_field].isna().any() or frame[entropy_field].isna().any():
        raise ValueError("All simulation methods/seeds require both oracle error and entropy secondary diagnostics; map their exact names with CLI options if needed.")
    if frame.loc[~simulation, oracle_field].notna().any():
        raise ValueError("Oracle ISE is restricted to the simulation cohorts with known truth.")
    if (frame[oracle_field].dropna() < 0).any() or ((frame[entropy_field].dropna() < -1e-8) | (frame[entropy_field].dropna() > 1 + 1e-8)).any():
        raise ValueError("Oracle ISE must be nonnegative and normalized entropy must lie in [0,1].")
    reports = json.loads((directory / "summary.json").read_text(encoding="utf-8"))
    report_map = {condition_key(report): report for report in reports}
    conditions = {condition_key(cell) for cell in plan}
    if len(report_map) != len(reports) or set(report_map) != conditions:
        raise ValueError("summary.json condition groups differ from protocol.")
    # This report is cross-checked again against freshly paired CSV estimates.
    return frame, run, report_map, audit


def summarize(frame, protocol, oracle_field, entropy_field):
    from scipy.stats import t
    directions = {"cindex": 1, "ibs": -1, oracle_field: -1, entropy_field: 1}
    summary, paired = [], []
    grouped = {}
    for row in frame.to_dict("records"):
        grouped.setdefault(condition_key(row), []).append(row)
    for condition, rows in sorted(grouped.items(), key=lambda item: str(item[0])):
        baseline = FULL if condition[0] == "ablation" else "Clean"
        expected_methods = protocol["ablation_methods"] if condition[0] == "ablation" else protocol["reliability_methods"] if condition[0] == "reliability" else protocol["methods"]
        by_method = {method: {int(row["seed"]): row for row in rows if row["method"] == method} for method in expected_methods}
        if any(set(by_method[method]) != set(by_method[baseline]) for method in expected_methods):
            raise ValueError(f"Unpaired seeds in condition {condition}.")
        seeds = sorted(by_method[baseline])
        for metric in PRIMARY + (oracle_field, entropy_field):
            available = [row.get(metric) for row in rows]
            finite = [value is not None and np.isfinite(float(value)) for value in available]
            if not any(finite):
                continue
            if not all(finite):
                raise ValueError(f"Partially missing diagnostic within condition: {condition}, {metric}.")
            for method in expected_methods:
                values = [by_method[method][seed][metric] for seed in seeds]
                summary.append({**condition_dict(condition), "method": method, "metric": metric, **metric_stats(values), "seeds": json.dumps(seeds)})
                if method == baseline:
                    continue
                differences = np.asarray([directions[metric] * (by_method[method][seed][metric] - by_method[baseline][seed][metric]) for seed in seeds], dtype=float)
                stats = metric_stats(differences)
                pvalue = float(2 * t.sf(abs(stats["mean"] / stats["se"]), len(seeds) - 1)) if stats["se"] > 0 else (1.0 if stats["mean"] == 0 else 0.0)
                paired.append({**condition_dict(condition), "method": method, "baseline": baseline, "metric": metric,
                               "direction": "method - baseline" if directions[metric] == 1 else "baseline - method",
                               "n_pairs": stats["n"], "mean_difference": stats["mean"], "difference_sd": stats["sd"], "se": stats["se"],
                               "ci_low": stats["ci_low"], "ci_high": stats["ci_high"], "p_two_sided_unadjusted": pvalue,
                               "positive_seed_count": int((differences > 0).sum()), "nonpositive_seed_count": int((differences <= 0).sum()),
                               "seeds": json.dumps(seeds), "paired_differences": json.dumps(differences.tolist())})
    return pd.DataFrame(summary), pd.DataFrame(paired)


def holm_adjust(pvalues):
    """Holm step-down adjusted p-values, retaining original row order.

    For sorted p_(i), p_adj_(i) = max_{j<=i} ((m-j+1) p_(j)),
    capped at one. Ties are stable; no condition is removed before adjustment.
    """
    pvalues = np.asarray(pvalues, dtype=float)
    if pvalues.ndim != 1 or not len(pvalues) or not np.isfinite(pvalues).all() or np.any((pvalues < 0) | (pvalues > 1)):
        raise ValueError("Holm adjustment requires a nonempty vector of finite p-values in [0,1].")
    order = np.argsort(pvalues, kind="stable")
    adjusted_sorted = np.minimum(1.0, np.maximum.accumulate(pvalues[order] * np.arange(len(pvalues), 0, -1)))
    adjusted = np.empty_like(adjusted_sorted)
    adjusted[order] = adjusted_sorted
    return adjusted


def compare_full_methods(frame, protocol=None):
    """Full vs each named comparator, paired per seed, for primary endpoints.

    The entire non-ablation plan is included. Holm families comprise all
    conditions for one endpoint and one comparator (34 in the locked run).
    This conservative supplementary analysis never feeds back into training,
    selection, plotted conditions, or the unadjusted pointwise 95% intervals.
    """
    from scipy.stats import t
    grouped = {}
    for row in frame.to_dict("records"):
        if row["suite"] != "ablation":
            grouped.setdefault(condition_key(row), []).append(row)
    if not grouped:
        raise ValueError("No non-ablation conditions are available for Full method comparisons.")
    if protocol is not None:
        planned = {condition_key(cell) for cell in runner.jobs(protocol) if cell["suite"] != "ablation"}
        if set(grouped) != planned:
            raise ValueError("Full method comparisons must include every non-ablation planned condition.")
    records = []
    for condition, rows in sorted(grouped.items(), key=lambda item: str(item[0])):
        by_method = {}
        for method in (FULL,) + FULL_COMPARATORS:
            values = [row for row in rows if row["method"] == method]
            by_method[method] = {int(row["seed"]): row for row in values}
            if len(values) != len(by_method[method]) or not values:
                raise ValueError(f"Missing/duplicate comparator rows: {condition}, {method}.")
        seeds = sorted(by_method[FULL])
        if any(sorted(by_method[method]) != seeds for method in FULL_COMPARATORS):
            raise ValueError(f"Missing seed pairs in Full method comparisons: {condition}.")
        for comparator in FULL_COMPARATORS:
            for metric in PRIMARY:
                direction = 1 if metric == "cindex" else -1
                differences = np.asarray([direction * (float(by_method[FULL][seed][metric]) - float(by_method[comparator][seed][metric])) for seed in seeds])
                stats = metric_stats(differences)
                pvalue = float(2 * t.sf(abs(stats["mean"] / stats["se"]), len(seeds) - 1)) if stats["se"] > 0 else (1.0 if stats["mean"] == 0 else 0.0)
                records.append({**condition_dict(condition), "method": FULL, "comparator": comparator, "baseline": comparator, "metric": metric,
                                "direction": "Full - comparator" if metric == "cindex" else "comparator - Full", "positive_direction": "Full has a better primary endpoint",
                                "n_pairs": stats["n"], "mean_difference": stats["mean"], "difference_sd": stats["sd"], "se": stats["se"],
                                "ci_low": stats["ci_low"], "ci_high": stats["ci_high"], "ci_level": .95, "ci_multiplicity_adjusted": False,
                                "p_two_sided_unadjusted": pvalue, "seeds": json.dumps(seeds), "paired_differences": json.dumps(differences.tolist()),
                                "positive_seed_count": int((differences > 0).sum()), "nonpositive_seed_count": int((differences <= 0).sum())})
    result = pd.DataFrame(records)
    result["p_holm"] = np.nan
    result["holm_family_size"] = 0
    result["holm_family"] = ""
    for metric in PRIMARY:
        for comparator in FULL_COMPARATORS:
            mask = (result["metric"] == metric) & (result["comparator"] == comparator)
            if int(mask.sum()) != len(grouped):
                raise ValueError(f"Incomplete Holm family: {metric}, {comparator}.")
            result.loc[mask, "p_holm"] = holm_adjust(result.loc[mask, "p_two_sided_unadjusted"].to_numpy())
            result.loc[mask, "holm_family_size"] = len(grouped)
            result.loc[mask, "holm_family"] = f"{metric} | Full vs {comparator} | all non-ablation conditions"
    result["holm_reject_0_05"] = result["p_holm"] <= .05
    return result


def crosscheck_summary(summary, paired, reports):
    for condition, report in reports.items():
        selected = select_condition(summary, condition)
        entries = report["summary"]
        expected_methods = set(selected["method"])
        if len(entries) != len(expected_methods) or {entry["method"] for entry in entries} != expected_methods:
            raise ValueError(f"Runner summary omits/duplicates a method: {condition}.")
        expected_seeds = json.loads(selected.iloc[0]["seeds"])
        if sorted(report["seeds"]) != expected_seeds:
            raise ValueError(f"Runner summary seed identities disagree with CSV: {condition}.")
        if report["baseline"] != (FULL if condition[0] == "ablation" else "Clean"):
            raise ValueError(f"Runner baseline mismatch: {condition}.")
        for entry in report["summary"]:
            for metric in PRIMARY:
                fresh = selected[(selected["method"] == entry["method"]) & (selected["metric"] == metric)]
                if len(fresh) != 1 or int(fresh.iloc[0]["n"]) != report["n_paired_seeds"]:
                    raise ValueError(f"Runner summary method/seed mismatch: {condition}.")
                for suffix, column in (("mean", "mean"), ("sd", "sd")):
                    if not math.isclose(float(entry[f"{metric}_{suffix}"]), float(fresh.iloc[0][column]), abs_tol=1e-11, rel_tol=1e-9):
                        raise ValueError(f"Runner descriptive summary disagrees with CSV: {condition}, {entry['method']}, {metric}.")
        comparisons = select_condition(paired, condition)
        expected_pairs = {(row["method"], "C-index gain" if row["metric"] == "cindex" else "IBS reduction")
                          for row in comparisons[comparisons["metric"].isin(PRIMARY)].to_dict("records")}
        if len(report["paired_ci"]) != len(expected_pairs) or {(row["method"], row["metric"]) for row in report["paired_ci"]} != expected_pairs:
            raise ValueError(f"Runner summary omits/duplicates a primary paired comparison: {condition}.")
        for entry in report["paired_ci"]:
            metric = {"C-index gain": "cindex", "IBS reduction": "ibs"}[entry["metric"]]
            fresh = comparisons[(comparisons["method"] == entry["method"]) & (comparisons["metric"] == metric)]
            if len(fresh) != 1 or any(not math.isclose(float(fresh.iloc[0][key]), float(entry[key]), abs_tol=1e-11, rel_tol=1e-9) for key in ("mean_difference", "difference_sd", "ci_low", "ci_high")):
                raise ValueError(f"Runner paired summary disagrees with CSV: {condition}, {entry['method']}, {metric}.")


def select_condition(frame, key):
    mask = (frame["suite"] == key[0]) & (frame["dataset"] == key[1]) & (frame["backbone"] == key[3])
    mask &= frame["censoring"].isna() if key[2] is None else np.isclose(pd.to_numeric(frame["censoring"], errors="coerce"), key[2])
    return frame[mask]


def count_results(frame):
    return {"comparisons": len(frame), "positive_point_estimate": int((frame["mean_difference"] > 0).sum()),
            "ci_entirely_above_zero": int((frame["ci_low"] > 0).sum()), "nonbeneficial_point_estimate": int((frame["mean_difference"] <= 0).sum()),
            "ci_contains_zero": int(((frame["ci_low"] <= 0) & (frame["ci_high"] >= 0)).sum()),
            "ci_entirely_below_zero": int((frame["ci_high"] < 0).sum())}


def build_findings(summary, paired, full_comparisons, run, audit, inputs, oracle_field, entropy_field):
    full = paired[(paired["method"] == FULL) & (paired["baseline"] == "Clean") & paired["metric"].isin(PRIMARY)]
    counts = {metric: count_results(full[full["metric"] == metric]) for metric in PRIMARY}
    by_suite = {suite: {metric: count_results(full[(full["suite"] == suite) & (full["metric"] == metric)]) for metric in PRIMARY}
                for suite in ("simulation", "clinical", "reliability")}
    conditions = []
    for key in sorted({condition_key(row) for row in summary.to_dict("records")}, key=str):
        descriptives, comparisons = select_condition(summary, key), select_condition(paired, key)
        conditions.append({**condition_dict(key), "methods": descriptives.to_dict("records"), "paired_comparisons": comparisons.to_dict("records"),
                           "full_method_comparisons": select_condition(full_comparisons, key).to_dict("records")})
    joint = []
    for key in sorted({condition_key(row) for row in full.to_dict("records")}, key=str):
        values = {row["metric"]: row for row in select_condition(full, key).to_dict("records")}
        joint.append({**condition_dict(key), "both_metrics_positive": all(values[m]["mean_difference"] > 0 for m in PRIMARY),
                      "both_metrics_ci_above_zero": all(values[m]["ci_low"] > 0 for m in PRIMARY),
                      "any_metric_nonbeneficial": any(values[m]["mean_difference"] <= 0 for m in PRIMARY)})
    comparator_counts = {}
    for comparator in FULL_COMPARATORS:
        comparator_counts[comparator] = {}
        for metric in PRIMARY:
            values = full_comparisons[(full_comparisons["comparator"] == comparator) & (full_comparisons["metric"] == metric)]
            comparator_counts[comparator][metric] = {**count_results(values), "holm_family_size": int(values.iloc[0]["holm_family_size"]),
                                                   "unadjusted_p_le_0_05": int((values["p_two_sided_unadjusted"] <= .05).sum()),
                                                   "holm_p_le_0_05_two_sided": int(values["holm_reject_0_05"].sum()),
                                                   "positive_estimate_holm_p_le_0_05": int(((values["mean_difference"] > 0) & values["holm_reject_0_05"]).sum()),
                                                   "negative_estimate_holm_p_le_0_05": int(((values["mean_difference"] < 0) & values["holm_reject_0_05"]).sum())}
    return {"generated_utc": datetime.now(timezone.utc).isoformat(), "fingerprint": run["fingerprint"], "input_files": inputs,
            "counts": {"cells": len(audit), "primary_metric_rows": int(run["metric_rows"]), "condition_groups": len(conditions)},
            "estimation": {"replication_unit": "matched random seed within a condition", "descriptive_sd": "sample SD, ddof=1",
                           "interval": "unadjusted two-sided Student t 95% CI of within-seed differences",
                           "multiplicity": "All pairwise intervals and original paired_comparisons.csv p-values are unadjusted. full_method_comparisons.csv separately applies Holm to each primary endpoint x comparator family across the entire non-ablation plan. Analyses remain exploratory; no confirmatory familywise or universal superiority claim is made.",
                           "dependence_limit": "Clinical seed intervals describe variation from repeated splits of one fixed dataset. Splits share patients; intervals are not patient-population confidence intervals and seeds are not independent clinical studies.",
                           "gain_sign": {"cindex": "method - baseline", "ibs": "baseline - method", oracle_field: "baseline - method", entropy_field: "method - baseline (descriptive, not beneficialness)"}},
            "full_vs_clean": {"overall_by_metric": counts, "by_suite_by_metric": by_suite, "joint_conditions": joint,
                              "joint_count_both_positive": sum(row["both_metrics_positive"] for row in joint),
                              "joint_count_both_ci_above_zero": sum(row["both_metrics_ci_above_zero"] for row in joint),
                              "joint_count_any_nonbeneficial": sum(row["any_metric_nonbeneficial"] for row in joint)},
            "full_method_comparisons": {"comparators": list(FULL_COMPARATORS), "primary_endpoints": list(PRIMARY),
                                        "holm_family_definition": "one endpoint x one comparator, across every non-ablation condition; no pooling of effect sizes",
                                        "by_comparator_by_endpoint": comparator_counts, "comparisons": full_comparisons.to_dict("records")},
            "conditions": conditions, "cell_artifact_audit": audit,
            "scope": ["Every planned condition and method is retained, including zero and unfavorable gains.",
                      "Ablation estimates compare each variant with Full within its dataset; no cross-dataset ablation average is used.",
                      "A positive Full-vs-Clean estimate does not establish an advantage over Fixed Gaussian or Joint generator; those comparisons are computed separately for every condition.",
                      "Oracle survival-probability error and normalized risk-set entropy are secondary diagnostics, never evidence of a causal mechanism or clinical calibration.",
                      "No figure format or style is claimed to establish journal compliance."]}


def tex_escape(value):
    table = {"&": r"\&", "%": r"\%", "$": r"\$", "#": r"\#", "_": r"\_", "{": r"\{", "}": r"\}"}
    return "".join(table.get(char, char) for char in str(value))


def condition_label(row, include_censor=False):
    label = DATASET_LABELS.get(row["dataset"], row["dataset"])
    censor = censor_value(row.get("censoring"))
    if include_censor and censor is not None:
        label += f" ({100*censor:.0f}%)"
    return label


def write_tables(summary, output, protocol):
    directory = output / "tables"
    directory.mkdir(parents=True, exist_ok=True)
    definitions = [("simulation_central", "simulation", True, "Central simulations at 40\\% target censoring"),
                   ("clinical", "clinical", False, "Clinical benchmark reruns"),
                   ("reliability", "reliability", False, "Reliability nominal and shift reruns"),
                   ("ablation", "ablation", False, "Ablation reruns, reported separately for each dataset")]
    primary = summary[summary["metric"].isin(PRIMARY)]
    for filename, suite, central, caption in definitions + [("all_results", None, False, "All predeclared conditions and methods")]:
        selected = primary if suite is None else primary[primary["suite"] == suite]
        if central:
            selected = selected[np.isclose(pd.to_numeric(selected["censoring"], errors="coerce"), .4)]
        values = {}
        for row in selected.to_dict("records"):
            identity = condition_key(row) + (row["method"],)
            values.setdefault(identity, {})[row["metric"]] = row
        lines = ["% Requires booktabs and longtable. Generated from the complete locked rerun.",
                 "% Values are mean +/- sample SD across matched seeds; no datasets are pooled.", r"\begingroup", r"\scriptsize", r"\setlength{\tabcolsep}{3pt}"]
        lines += [r"\begin{longtable}{lllcc}" if suite is not None else r"\begin{longtable}{llllcc}",
                  r"\caption{" + caption + r". C-index $\uparrow$ and IBS $\downarrow$ are mean $\pm$ sample SD.}" + r"\label{tab:rerun_" + filename + r"}\\", r"\toprule"]
        header = r"Condition ($n$ seeds) & Backbone & Method & C-index $\uparrow$ & IBS $\downarrow$ \\"
        if suite is None:
            header = "Suite & " + header
        lines += [header, r"\midrule", r"\endfirsthead", r"\toprule", header, r"\midrule", r"\endhead"]
        def row_order(item):
            identity = item[0]
            row_suite, dataset, censor, backbone, method = identity
            suites = ["simulation", "clinical", "reliability", "ablation"]
            datasets = (protocol["simulation_scenarios"] if row_suite == "simulation" else protocol["clinical_datasets"] if row_suite == "clinical"
                        else ["reliability_nominal", "reliability_shift"] if row_suite == "reliability" else protocol["ablation_datasets"])
            methods = protocol["ablation_methods"] if row_suite == "ablation" else protocol["reliability_methods"] if row_suite == "reliability" else protocol["methods"]
            return (suites.index(row_suite), datasets.index(dataset), -1 if censor is None else censor, protocol["backbones"].index(backbone), methods.index(method))
        previous = None
        for identity, metrics in sorted(values.items(), key=row_order):
            if set(metrics) != set(PRIMARY):
                raise ValueError(f"Missing primary table metric: {identity}")
            condition = identity[:4]
            if previous is not None and condition != previous:
                lines.append(r"\addlinespace")
            row = metrics["cindex"]
            cells = [tex_escape(condition_label(row, suite is None) + f" ({row['n']})"), tex_escape(row["backbone"]), tex_escape(row["method"])]
            if suite is None:
                cells.insert(0, tex_escape(row["suite"]))
            cells += [f"${metrics[m]['mean']:.4f} \\pm {metrics[m]['sd']:.4f}$" for m in PRIMARY]
            lines.append(" & ".join(cells) + r" \\")
            previous = condition
        lines += [r"\bottomrule", r"\end{longtable}", r"\endgroup", ""]
        (directory / f"{filename}.tex").write_text("\n".join(lines), encoding="utf-8")


def one_comparison(paired, key, method, metric):
    selection = select_condition(paired, key)
    selection = selection[(selection["method"] == method) & (selection["metric"] == metric)]
    if len(selection) != 1:
        raise ValueError(f"Missing/nonunique plotted comparison: {key}, {method}, {metric}.")
    return selection.iloc[0]


def forest(ax, paired, conditions, labels, methods, metric, xlabel):
    positions = np.arange(len(conditions), dtype=float)
    offsets = np.linspace(-.28, .28, len(methods)) if len(methods) > 1 else [0.0]
    for offset, method in zip(offsets, methods):
        rows = [one_comparison(paired, condition, method, metric) for condition in conditions]
        mean = np.array([row["mean_difference"] for row in rows])
        lower = np.array([row["ci_low"] for row in rows])
        upper = np.array([row["ci_high"] for row in rows])
        ax.errorbar(mean, positions + offset, xerr=np.vstack((mean - lower, upper - mean)), fmt=MARKERS[method], color=COLORS[method],
                    markersize=4.3, capsize=2, linewidth=1, label=method, linestyle="none")
    ax.axvline(0, color="#555555", linewidth=.8, linestyle="--", zorder=0)
    ax.set_yticks(positions, labels)
    ax.set_ylim(len(conditions) - .4, -.6)
    ax.set_xlabel(xlabel)
    ax.grid(axis="x", alpha=.2, linewidth=.5)


def equalize(axes, dimension="x"):
    values = [ax.get_xlim() if dimension == "x" else ax.get_ylim() for ax in axes]
    lo, hi = min(0, min(v[0] for v in values)), max(0, max(v[1] for v in values))
    span = max(hi - lo, 1e-6)
    limits = (lo - .03 * span, hi + .03 * span)
    for ax in axes:
        (ax.set_xlim if dimension == "x" else ax.set_ylim)(*limits)


def figure_legend(fig, axes, columns=4):
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="outside lower center", ncol=columns, frameon=False, fontsize=8)


def write_figures(paired, protocol, output, oracle_field, entropy_field, inputs):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    directory = output / "figures"
    directory.mkdir(parents=True, exist_ok=True)
    manifests = []
    style = {"font.family": "DejaVu Sans", "font.size": 8, "axes.titlesize": 9, "axes.labelsize": 8,
             "xtick.labelsize": 7, "ytick.labelsize": 8, "legend.fontsize": 8, "pdf.fonttype": 42,
             "ps.fonttype": 42, "savefig.facecolor": "white", "axes.spines.top": False, "axes.spines.right": False}

    def save(fig, name, caption, condition_scope):
        # Interval scope belongs in the manuscript caption and figure manifest.
        # A second bottom text artist collides with the constrained outside legend.
        files = []
        for extension in ("pdf", "png"):
            path = directory / f"{name}.{extension}"
            temporary = directory / f"{name}.tmp.{extension}"
            kwargs = {"dpi": 300, "facecolor": "white", "bbox_inches": None}
            if extension == "pdf":
                kwargs["metadata"] = {"Title": name, "Subject": caption, "Creator": "scripts/analyze_results.py"}
            fig.savefig(temporary, format=extension, **kwargs)
            temporary.replace(path)
            files.append({"path": str(path.resolve()), "sha256": sha(path)})
        caption += " Intervals are unadjusted exploratory paired t 95% intervals. Clinical seed intervals reflect resplitting of a fixed dataset, not patient-population uncertainty or independent clinical studies."
        manifests.append({"name": name, "caption": caption, "alt_text": caption, "condition_scope": condition_scope,
                          "dimensions_inches": fig.get_size_inches().tolist(), "png_dpi": 300, "pdf_vector": True,
                          "interval": "unadjusted exploratory two-sided Student t 95% interval of within-seed differences", "files": files})
        plt.close(fig)

    methods = [method for method in protocol["methods"] if method != "Clean"]
    with plt.rc_context(style):
        for suite, datasets, filename, title in (("simulation", protocol["simulation_scenarios"], "simulation", "Central simulations: 40% target censoring"),
                                                  ("clinical", protocol["clinical_datasets"], "clinical", "Clinical benchmarks")):
            fig, axes = plt.subplots(2, 2, figsize=(8.0, 6.2), layout="constrained")
            for col, backbone in enumerate(protocol["backbones"]):
                keys = [(suite, dataset, .4 if suite == "simulation" else None, backbone) for dataset in datasets]
                labels = [DATASET_LABELS.get(dataset, dataset) for dataset in datasets]
                for row, metric in enumerate(PRIMARY):
                    forest(axes[row, col], paired, keys, labels, methods, metric, "C-index gain over Clean" if metric == "cindex" else "IBS reduction from Clean")
                    axes[row, col].set_title(f"{chr(65+row*2+col)}  {backbone}")
            for row in range(2):
                equalize(axes[row, :])
            figure_legend(fig, axes.flat, 3)
            fig.suptitle(title + (" (20 paired seeds)" if suite == "simulation" else " (10 paired seeds)"))
            save(fig, filename, title + "; all three non-Clean methods and both backbones, including unfavorable effects. Positive values indicate improvement relative to Clean.", {"suite": suite, "datasets": datasets, "censoring": .4 if suite == "simulation" else "observed"})

        # Every scenario, censoring target, method and backbone is represented.
        fig, axes = plt.subplots(4, 2, figsize=(8.1, 10.5), layout="constrained")
        for row, scenario in enumerate(protocol["simulation_scenarios"]):
            for col, metric in enumerate(PRIMARY):
                ax = axes[row, col]
                for b_index, backbone in enumerate(protocol["backbones"]):
                    for m_index, method in enumerate(methods):
                        values = [one_comparison(paired, ("simulation", scenario, censor, backbone), method, metric) for censor in protocol["censoring_levels"]]
                        x = np.asarray(protocol["censoring_levels"]) * 100 + (m_index - 1) * .65 + (b_index - .5) * 2.1
                        means = np.array([value["mean_difference"] for value in values])
                        ax.errorbar(x, means, yerr=np.vstack((means - np.array([value["ci_low"] for value in values]), np.array([value["ci_high"] for value in values]) - means)),
                                    color=COLORS[method], marker=MARKERS[method], linestyle="-" if b_index == 0 else "--", capsize=1.8,
                                    linewidth=.9, markersize=3.5, label=f"{method}, {backbone}")
                ax.axhline(0, color="#555555", linewidth=.8, linestyle="--")
                ax.set_xticks(np.asarray(protocol["censoring_levels"]) * 100)
                ax.set_xlabel("Target censoring (%)")
                ax.set_ylabel("C-index gain over Clean" if metric == "cindex" else "IBS reduction from Clean")
                ax.set_title(f"{chr(65+row*2+col)}  {scenario}")
                ax.grid(axis="y", alpha=.2, linewidth=.5)
        for col in range(2):
            equalize(axes[:, col], "y")
        figure_legend(fig, axes.flat, 2)
        fig.suptitle("Censoring sensitivity: all simulation conditions")
        save(fig, "censoring", "All simulation scenarios and 20%, 40%, 60% censoring targets; both backbones and all three alternatives to Clean. Small horizontal offsets separate intervals without changing censoring values. Central conditions use 20 seeds, others 10.", {"suite": "simulation", "censoring": protocol["censoring_levels"]})

        for suite, datasets, filename in (("reliability", ["reliability_nominal", "reliability_shift"], "reliability"), ("ablation", protocol["ablation_datasets"], "ablation")):
            baseline = FULL if suite == "ablation" else "Clean"
            selected_methods = [method for method in protocol["ablation_methods" if suite == "ablation" else "reliability_methods"] if method != baseline]
            fig, axes = plt.subplots(1, 2, figsize=(9.0, 4.6), layout="constrained")
            keys = [(suite, dataset, .38 if dataset.startswith("reliability") else None, "DeepSurv") for dataset in datasets]
            for col, metric in enumerate(PRIMARY):
                reference = "Full" if suite == "ablation" else "Clean"
                forest(axes[col], paired, keys, [DATASET_LABELS.get(dataset, dataset) for dataset in datasets], selected_methods, metric,
                       f"C-index gain over {reference}" if metric == "cindex" else f"IBS reduction from {reference}")
                axes[col].set_title(f"{chr(65+col)}  DeepSurv")
            figure_legend(fig, axes.flat, 3 if suite == "ablation" else 2)
            fig.suptitle(("Ablations relative to Full" if suite == "ablation" else "Reliability: nominal and shift") + " (10 paired seeds)")
            save(fig, filename, ("Each ablation variant minus Full for C-index, Full minus variant for IBS; positive values favor the variant. Datasets remain separate." if suite == "ablation" else "All four alternatives to Clean under both nominal and shift reliability conditions; positive values indicate improvement over Clean."), {"suite": suite, "datasets": datasets, "backbone": "DeepSurv"})

        fig, axes = plt.subplots(2, 2, figsize=(8.8, 10.0), layout="constrained")
        labels = [f"{scenario}, {100*censor:.0f}%" for scenario in protocol["simulation_scenarios"] for censor in protocol["censoring_levels"]]
        for col, backbone in enumerate(protocol["backbones"]):
            keys = [("simulation", scenario, censor, backbone) for scenario in protocol["simulation_scenarios"] for censor in protocol["censoring_levels"]]
            for row, metric in enumerate((oracle_field, entropy_field)):
                forest(axes[row, col], paired, keys, labels, methods, metric, "Oracle survival ISE reduction from Clean" if row == 0 else "Normalized entropy difference from Clean")
                axes[row, col].set_title(f"{chr(65+row*2+col)}  {backbone}")
        for row in range(2):
            equalize(axes[row, :])
        figure_legend(fig, axes.flat, 3)
        fig.suptitle("Secondary diagnostics: 40% censoring n=20; 20%/60% n=10")
        save(fig, "diagnostics", "Paired changes in integrated squared survival-probability error against known simulation truth, and normalized risk-set predictive entropy, across every simulation condition. Central 40% conditions have 20 paired seeds; 20% and 60% have 10. Entropy changes are descriptive and neither sign establishes a causal mechanism or clinical calibration.", {"suite": "simulation", "scenarios": protocol["simulation_scenarios"], "censoring": protocol["censoring_levels"]})
    write_json(directory / "figure_manifest.json", {"input_files": inputs, "matplotlib": matplotlib.__version__, "figures": manifests,
                                                    "note": "Provisional scientific figure design; journal requirements and final-size visual inspection are separate checks."})


def self_test():
    """Synthetic arithmetic checks only; never writes analysis or figures."""
    assert censor_value("") is None and censor_value("None") is None and censor_value("0.4") == .4
    rows = []
    for seed, delta in enumerate((.01, .02, .03), start=100):
        for method, effect in (("Clean", 0), ("Fixed Gaussian", -delta), ("Joint generator", 2 * delta), (FULL, delta)):
            rows.append({"suite": "clinical", "dataset": "fixture", "censoring": None, "backbone": "Cox", "seed": seed,
                         "method": method, "cindex": .6 + effect, "ibs": .2 - effect, "oracle_ise": np.nan, "riskset_entropy": np.nan})
    summary, paired = summarize(pd.DataFrame(rows), {"methods": ["Clean", "Fixed Gaussian", "Joint generator", FULL]}, "oracle_ise", "riskset_entropy")
    assert len(summary) == 8 and len(paired) == 6
    assert np.allclose(paired.loc[paired["method"] == FULL, "mean_difference"], .02)
    assert np.allclose(paired.loc[paired["method"] == "Fixed Gaussian", "mean_difference"], -.02)
    assert np.allclose(paired.loc[paired["method"] != "Joint generator", "difference_sd"], .01)
    assert all(row["n_pairs"] == 3 for row in paired.to_dict("records"))
    assert count_results(paired)["positive_point_estimate"] == 4
    assert count_results(paired)["nonbeneficial_point_estimate"] == 2 and count_results(paired)["ci_contains_zero"] == 6
    np.testing.assert_allclose(holm_adjust([.01, .04, .03]), [.03, .06, .06])
    np.testing.assert_allclose(holm_adjust([.04, .001, .04, .2]), [.12, .004, .12, .2])
    comparisons = compare_full_methods(pd.DataFrame(rows))
    assert len(comparisons) == 6 and set(comparisons["comparator"]) == set(FULL_COMPARATORS)
    assert np.allclose(comparisons.loc[comparisons["comparator"] == "Clean", "mean_difference"], .02)
    assert np.allclose(comparisons.loc[comparisons["comparator"] == "Fixed Gaussian", "mean_difference"], .04)
    assert np.allclose(comparisons.loc[comparisons["comparator"] == "Joint generator", "mean_difference"], -.02)
    assert (comparisons["p_holm"] + 1e-15 >= comparisons["p_two_sided_unadjusted"]).all()
    assert (comparisons["holm_family_size"] == 1).all() and not comparisons["ci_multiplicity_adjusted"].any()
    # Explicitly test six separate endpoint x comparator families of 34
    # conditions. These are arithmetic fixtures, not experimental outcomes.
    family_fixture = pd.DataFrame([{**row, "dataset": f"fixture_{condition}"} for condition in range(34) for row in rows])
    family_comparisons = compare_full_methods(family_fixture)
    assert len(family_comparisons) == 204 and (family_comparisons["holm_family_size"] == 34).all()
    assert (family_comparisons.groupby(["metric", "comparator"]).size() == 34).all()
    broken = pd.DataFrame(rows[:-1])
    try:
        summarize(broken, {"methods": ["Clean", "Fixed Gaussian", "Joint generator", FULL]}, "oracle_ise", "riskset_entropy")
    except ValueError:
        pass
    else:
        raise AssertionError("Unpaired missing seeds were not rejected.")
    try:
        compare_full_methods(broken)
    except ValueError:
        pass
    else:
        raise AssertionError("Missing Full/comparator seed pairs were not rejected.")
    print("Synthetic arithmetic checks passed; no result artifacts or figures were written.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=ROOT / "results" / "corrected_v1")
    parser.add_argument("--output", type=Path, help="Default: same directory as --input")
    parser.add_argument("--oracle-field", default="oracle_ise")
    parser.add_argument("--entropy-field", default="riskset_entropy")
    parser.add_argument("--check-only", action="store_true", help="Validate the complete run and recompute summaries; write nothing and do not import plotting tools")
    parser.add_argument("--tables-only", action="store_true", help="Write analysis and tables, without creating figures")
    parser.add_argument("--self-test", action="store_true", help="Run synthetic arithmetic checks, without reading or writing result artifacts")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return 0
    frame, run, reports, audit = load_complete_run(args.input, args.oracle_field, args.entropy_field)
    summary, paired = summarize(frame, run["protocol"], args.oracle_field, args.entropy_field)
    crosscheck_summary(summary, paired, reports)
    full_comparisons = compare_full_methods(frame, run["protocol"])
    if args.check_only:
        print(json.dumps({"status": "verified", "cells": len(audit), "metric_rows": len(frame), "condition_groups": len(reports), "written": []}))
        return 0
    output = (args.output or args.input).resolve()
    analysis = output / "analysis"
    analysis.mkdir(parents=True, exist_ok=True)
    inputs = {name: {"path": str((args.input / name).resolve()), "sha256": sha(args.input / name)} for name in ("run.json", "summary.json", "results_raw.csv")}
    inputs["analysis_script"] = {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))}
    summary.to_csv(analysis / "summary_metrics.csv", index=False)
    paired.to_csv(analysis / "paired_comparisons.csv", index=False)
    full_comparisons.to_csv(analysis / "full_method_comparisons.csv", index=False)
    findings = build_findings(summary, paired, full_comparisons, run, audit, inputs, args.oracle_field, args.entropy_field)
    write_json(analysis / "findings.json", findings)
    write_tables(summary, output, run["protocol"])
    if not args.tables_only:
        write_figures(paired, run["protocol"], output, args.oracle_field, args.entropy_field, inputs)
    print(json.dumps({"status": "complete", "output": str(output), "condition_groups": len(reports), "primary_metric_rows": len(frame),
                      "full_vs_clean": findings["full_vs_clean"]["overall_by_metric"], "figures": 0 if args.tables_only else 6}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
