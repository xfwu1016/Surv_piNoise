#!/usr/bin/env python3
"""Register independent-pilot censoring scales BEFORE the formal experiments.

Run from the repository root: python scripts/prepare_censoring.py
Defaults: fixed master seed 20261027, 20,000 independent pilot failures for
each mechanism. It never reads experiment outcomes, main cohorts or test
metrics, and never imports the training engine.
"""

from __future__ import annotations

import argparse
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from survpinoise.censoring_design import DEFAULT_CONFIG, MASTER_SEED, PILOT_SIZE, write_config


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--n-pilot", type=int, default=PILOT_SIZE)
    parser.add_argument("--seed", type=int, default=MASTER_SEED)
    args = parser.parse_args(argv)
    config = write_config(args.output, n_pilot=args.n_pilot, master_seed=args.seed)
    count = sum(len(values) for values in config["scales"].values())
    error = max(check["absolute_error"] for detail in config["pilot_details"].values()
                for check in detail["target_checks"].values())
    print(f"Wrote {count} independent-pilot scales to {args.output}")
    print(f"Master seed {args.seed}; pilot n={args.n_pilot} per mechanism; max target error {error:.3g}.")
    print("Main cohorts/test outcomes used: no. Cohort censoring rates remain random.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
