"""Fetch checksum-locked public data and calculate an auditable inventory."""
from pathlib import Path
import argparse
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from survpinoise.data import DEFAULT_DATA_DIR, SOURCE_SPECS, download_sources, write_provenance


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--datasets", nargs="+", choices=tuple(SOURCE_SPECS), default=list(SOURCE_SPECS))
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--provenance", type=Path, default=Path(__file__).resolve().parents[1] / "data" / "provenance.json")
    args = parser.parse_args()
    download_sources(args.datasets, args.data_dir)
    provenance = write_provenance(args.provenance, args.datasets, args.data_dir)
    print(json.dumps([{k: data[k] for k in ("name", "n", "baseline_features", "events", "censored", "zero_time_count")} for data in provenance["data_sources"]], indent=2))


if __name__ == "__main__":
    main()
