"""Known-mechanism diagnostics, independent of model fitting and selection."""

import math
import unittest

import numpy as np

from survpinoise.diagnostics import (normalized_riskset_entropy,
                                     oracle_survival_error, true_survival)


class OracleTests(unittest.TestCase):
    def test_ph_scenarios_match_paper_coefficients_at_baseline_unit_hazard(self):
        cases = {
            "S1": (np.array([[1., 0., 0., 0.]]), .7),
            "S2": (np.array([[1., .5, 2., 3., -4.]]), 3.4),
            "S4": (np.ones((1, 30)), .6),
        }
        for scenario, (x, score) in cases.items():
            with self.subTest(scenario=scenario):
                actual = true_survival(x, [0., 20.], scenario)
                self.assertEqual(actual[0, 0], 1.)
                self.assertAlmostEqual(actual[0, 1], math.exp(-math.exp(score)), places=12)

    def test_s3_piecewise_formula_has_manual_value_and_continuity_at_twenty(self):
        x = np.array([[0., 0., 2*math.log(2.)]])
        grid = np.array([0., 20.-1e-7, 20., 20.+1e-7, 40.])
        survival = true_survival(x, grid, "S3")[0]
        self.assertEqual(survival[0], 1.)
        self.assertAlmostEqual(survival[2], math.exp(-1.), places=12)
        expected_h40 = 1 + 2*(2**1.3-1)
        self.assertAlmostEqual(survival[-1], math.exp(-expected_h40), places=12)
        self.assertLess(abs(survival[1]-survival[2]), 1e-8)
        self.assertLess(abs(survival[3]-survival[2]), 1e-8)
        self.assertTrue(np.all(np.diff(survival) <= 0))

    def test_s3_with_no_time_effect_reduces_to_ph_and_has_correct_limits(self):
        x = np.array([[1., -.5, 0.]])
        grid = np.array([0., 5., 20., 100., 1e6])
        expected = np.exp(-np.exp(1.1)*(grid/20)**1.3)
        np.testing.assert_allclose(true_survival(x, grid, "S3")[0], expected, rtol=1e-12, atol=1e-12)
        self.assertEqual(true_survival(x, grid, "S3")[0, -1], 0.)

    def test_survival_remains_finite_under_large_risks(self):
        x = np.array([[1000., 0., 1000., 0.], [-1000., 0., -1000., 0.]])
        for scenario in ("S1", "S3"):
            actual = true_survival(x, [0., 1., 20., 100.], scenario)
            self.assertTrue(np.isfinite(actual).all())
            self.assertTrue(np.all((actual >= 0) & (actual <= 1)))
            np.testing.assert_array_equal(actual[:, 0], [1., 1.])

    def test_oracle_error_uses_normalized_trapezoid_and_sample_mean(self):
        prediction = np.array([[0., .5, 1.], [0., .5, 1.]])
        truth = np.zeros_like(prediction)
        # Per-time squared error is [0, .25, 1]; nonuniform interval areas
        # are .125*1 and .625*2, followed by division by span 3.
        self.assertAlmostEqual(oracle_survival_error(prediction, truth, [0., 1., 3.]), 1.375/3)
        self.assertEqual(oracle_survival_error(prediction, prediction, [0., 1., 3.]), 0.)
        self.assertEqual(oracle_survival_error(np.zeros((1, 2)), np.ones((1, 2)), [2., 8.]), 1.)

    def test_bad_scenario_feature_or_probability_inputs_are_rejected(self):
        with self.assertRaises(ValueError):
            true_survival(np.zeros((2, 4)), [1., 2.], "S4")
        with self.assertRaises(ValueError):
            true_survival(np.zeros((2, 4)), [1., 2.], "unknown")
        with self.assertRaises(ValueError):
            oracle_survival_error([[1., 1.]], [[1., 1.]], [1., 1.])
        with self.assertRaises(ValueError):
            oracle_survival_error([[1.1, 1.]], [[1., 1.]], [1., 2.])


def explicit_entropy(time, event, risk):
    values = []
    for y, observed in zip(time, event):
        if not observed:
            continue
        scores = np.asarray(risk)[np.asarray(time) >= y]
        if len(scores) == 1:
            values.append(0.)
        else:
            probability = np.exp(scores-scores.max())
            probability /= probability.sum()
            positive = probability > 0
            values.append(-np.sum(probability[positive]*np.log(probability[positive]))/np.log(len(scores)))
    return float(np.mean(values))


class EntropyTests(unittest.TestCase):
    def test_uniform_risk_set_entropy_is_one(self):
        self.assertAlmostEqual(normalized_riskset_entropy([1., 1., 1., 1.], [1, 1, 0, 1], [0., 0., 0., 0.]), 1.)

    def test_confident_risk_set_entropy_is_near_zero(self):
        value = normalized_riskset_entropy([1., 1., 1.], [1, 1, 1], [1000., 0., -1000.])
        self.assertLess(value, 1e-10)

    def test_singleton_convention_and_event_average(self):
        self.assertEqual(normalized_riskset_entropy([1.], [1], [8.]), 0.)
        # Three event risk sets have sizes 3, 2, 1; uniform risks give 1,1,0.
        self.assertAlmostEqual(normalized_riskset_entropy([1., 2., 3.], [1, 1, 1], [0., 0., 0.]), 2/3)

    def test_full_risk_sets_and_ties_match_explicit_definition(self):
        time = np.array([1., 1., 3., 2., 4., 2.])
        event = np.array([1, 0, 1, 1, 0, 1])
        risk = np.array([.4, -.7, 1.2, .1, -.3, .8])
        expected = explicit_entropy(time, event, risk)
        self.assertAlmostEqual(normalized_riskset_entropy(time, event, risk), expected, places=12)
        order = np.array([1, 5, 4, 0, 3, 2])
        self.assertAlmostEqual(normalized_riskset_entropy(time[order], event[order], risk[order]), expected, places=12)

    def test_prefix_stability_when_global_maximum_enters_late(self):
        time = np.array([4., 3., 2., 1.])
        event = np.ones(4)
        risk = np.array([-1000., -1000., 1000., 1000.])
        self.assertAlmostEqual(normalized_riskset_entropy(time, event, risk), explicit_entropy(time, event, risk), places=12)
        # Equal huge scores should still yield log(size), despite additive
        # precision loss in a naive logsumexp - weighted_mean formula.
        self.assertAlmostEqual(normalized_riskset_entropy([1., 1., 1.], [1, 1, 1], [1e300]*3), 1.)

    def test_no_events_is_undefined_not_a_spurious_zero(self):
        with self.assertRaises(ValueError):
            normalized_riskset_entropy([1., 2.], [0, 0], [.1, .2])


if __name__ == "__main__":
    unittest.main()
