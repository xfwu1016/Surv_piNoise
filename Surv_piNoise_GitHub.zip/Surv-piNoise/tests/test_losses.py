"""Cox/Brier correctness and virtual-update hypergradient tests (CPU)."""

import math
import unittest

import torch
from torch import nn
from torch.func import functional_call

from survpinoise.losses import CoxBreslowPlan, IPCWPlan, cox_breslow_nll


DTYPE = torch.float64


def explicit_cox(risk, time, event):
    terms = [torch.logsumexp(risk[time >= time[i]], dim=0) - risk[i]
             for i in range(time.numel()) if bool(event[i])]
    return torch.stack(terms).mean() if terms else risk.sum() * 0.0


class CoxLossTests(unittest.TestCase):
    def test_two_tied_events_have_shared_full_denominator(self):
        time = torch.tensor([1.0, 1.0], dtype=DTYPE)
        event = torch.ones(2, dtype=DTYPE)
        risk = torch.zeros(2, dtype=DTYPE, requires_grad=True)
        loss = cox_breslow_nll(risk, time, event)
        self.assertAlmostEqual(loss.item(), math.log(2.0), places=12)
        self.assertNotAlmostEqual(loss.item(), math.log(2.0) / 2, places=6)

    def test_mixed_event_and_censoring_ties_match_explicit_risk_sets(self):
        time = torch.tensor([3., 1., 3., 2., 1., 4.], dtype=DTYPE)
        event = torch.tensor([1., 1., 0., 1., 1., 0.], dtype=DTYPE)
        risk = torch.tensor([.4, -.8, .2, .7, -.1, 1.2], dtype=DTYPE, requires_grad=True)
        actual = cox_breslow_nll(risk, time, event)
        expected = explicit_cox(risk, time, event)
        torch.testing.assert_close(actual, expected, rtol=1e-12, atol=1e-12)
        actual_grad, = torch.autograd.grad(actual, risk, create_graph=True)
        expected_grad, = torch.autograd.grad(expected, risk, create_graph=True)
        torch.testing.assert_close(actual_grad, expected_grad, rtol=1e-12, atol=1e-12)
        actual_hessian = torch.autograd.functional.hessian(lambda r: cox_breslow_nll(r, time, event), risk)
        expected_hessian = torch.autograd.functional.hessian(lambda r: explicit_cox(r, time, event), risk)
        torch.testing.assert_close(actual_hessian, expected_hessian, rtol=1e-11, atol=1e-11)

    def test_tied_row_order_does_not_change_loss_or_gradients(self):
        time = torch.tensor([1., 1., 2., 2., 3.], dtype=DTYPE)
        event = torch.tensor([1., 0., 1., 1., 0.], dtype=DTYPE)
        risk = torch.tensor([.2, -.3, .7, -.8, .4], dtype=DTYPE, requires_grad=True)
        loss = cox_breslow_nll(risk, time, event)
        grad, = torch.autograd.grad(loss, risk)
        order = torch.tensor([1, 0, 3, 2, 4])
        permuted = risk.detach()[order].requires_grad_()
        other = cox_breslow_nll(permuted, time[order], event[order])
        other_grad, = torch.autograd.grad(other, permuted)
        torch.testing.assert_close(loss, other)
        torch.testing.assert_close(grad[order], other_grad)

    def test_extreme_common_shift_is_stable_and_invariant(self):
        time = torch.tensor([1., 2., 3.], dtype=DTYPE)
        event = torch.tensor([1., 0., 1.], dtype=DTYPE)
        risk = torch.tensor([.2, -.4, .8], dtype=DTYPE, requires_grad=True)
        torch.testing.assert_close(cox_breslow_nll(risk + 10000, time, event),
                                   cox_breslow_nll(risk, time, event), rtol=1e-11, atol=1e-11)

    def test_zero_events_produce_finite_differentiable_zero(self):
        time = torch.tensor([1., 2., 3.], dtype=DTYPE)
        risk = torch.tensor([.2, -.4, .8], dtype=DTYPE, requires_grad=True)
        loss = cox_breslow_nll(risk, time, torch.zeros_like(time))
        grad, = torch.autograd.grad(loss, risk)
        self.assertEqual(loss.item(), 0.0)
        torch.testing.assert_close(grad, torch.zeros_like(risk))

    def test_cached_risk_set_storage_is_linear(self):
        n = 1200
        plan = CoxBreslowPlan(torch.arange(n, dtype=DTYPE), torch.ones(n, dtype=DTYPE))
        tensors = [value for value in vars(plan).values() if isinstance(value, torch.Tensor)]
        self.assertTrue(all(tensor.ndim <= 1 for tensor in tensors))
        self.assertLessEqual(sum(t.numel() for t in tensors), 8 * n)


class BrierLossTests(unittest.TestCase):
    def test_baseline_and_brier_match_manual_uncensored_example(self):
        time = torch.tensor([1., 2., 3.], dtype=DTYPE)
        event = torch.ones(3, dtype=DTYPE)
        grid = torch.tensor([0., 1., 2.], dtype=DTYPE)
        plan = IPCWPlan(time, event, time, event, grid=grid)
        risk = torch.zeros(3, dtype=DTYPE, requires_grad=True)
        survival = plan.survival(risk, risk)
        expected_s = torch.tensor([1., math.exp(-1/3), math.exp(-(1/3 + 1/2))], dtype=DTYPE)
        torch.testing.assert_close(survival, expected_s.expand(3, 3))
        target = torch.tensor([[1., 0., 0.], [1., 1., 0.], [1., 1., 1.]], dtype=DTYPE)
        expected_bs = ((expected_s[None, :] - target) ** 2).mean(dim=0)
        torch.testing.assert_close(plan.brier_by_time(risk, risk), expected_bs)
        torch.testing.assert_close(plan.brier(risk, risk), expected_bs.mean())
        torch.testing.assert_close(plan.ibs(risk, risk), torch.trapezoid(expected_bs, grid) / 2)

    def test_baseline_groups_tied_events_and_includes_tied_censor(self):
        time = torch.tensor([1., 1., 1., 2.], dtype=DTYPE)
        event = torch.tensor([1., 1., 0., 1.], dtype=DTYPE)
        plan = IPCWPlan(time, event, time, event, grid=torch.tensor([1.], dtype=DTYPE))
        risk = torch.zeros(4, dtype=DTYPE, requires_grad=True)
        # At t=1 Breslow increment is two events / four people at risk.
        expected = torch.full((4, 1), math.exp(-0.5), dtype=DTYPE)
        torch.testing.assert_close(plan.survival(risk, risk), expected)

    def test_censoring_left_limit_and_weights_use_training_km(self):
        train_time = torch.tensor([1., 2., 3.], dtype=DTYPE)
        train_event = torch.tensor([0., 1., 1.], dtype=DTYPE)
        eval_time = torch.tensor([1., 1.5, 3.], dtype=DTYPE)
        eval_event = torch.tensor([1., 0., 1.], dtype=DTYPE)
        plan = IPCWPlan(train_time, train_event, eval_time, eval_event,
                        grid=torch.tensor([1., 2.], dtype=DTYPE))
        # Failure at t=1 uses G_train(1-)=1; survival after t=1 uses G_train(1)=2/3.
        expected_weights = torch.tensor([[1., 1.], [1.5, 0.], [1.5, 1.5]], dtype=DTYPE)
        torch.testing.assert_close(plan.weights, expected_weights)
        torch.testing.assert_close(plan.censoring_survival(torch.tensor([1.], dtype=DTYPE), left=True),
                                   torch.ones(1, dtype=DTYPE))

    def test_training_grid_is_unchanged_by_evaluation_outcomes(self):
        time = torch.tensor([1., 2., 3., 4., 5.], dtype=DTYPE)
        event = torch.tensor([1., 1., 0., 1., 1.], dtype=DTYPE)
        first = IPCWPlan(time, event, time[:2], event[:2])
        second = IPCWPlan(time, event, torch.tensor([100., 200.], dtype=DTYPE), torch.zeros(2, dtype=DTYPE))
        torch.testing.assert_close(first.grid, second.grid)
        torch.testing.assert_close(first.censor_survival, second.censor_survival)
        self.assertEqual(first.grid.numel(), 50)
        self.assertAlmostEqual(first.grid[0].item(), 1.3)
        self.assertAlmostEqual(first.grid[-1].item(), 4.4)

    def test_zero_training_events_and_extreme_scores_stay_finite(self):
        time = torch.tensor([1., 2., 3.], dtype=DTYPE)
        zero = torch.zeros(3, dtype=DTYPE)
        train_risk = torch.tensor([1000., -1000., 0.], dtype=DTYPE, requires_grad=True)
        eval_risk = torch.tensor([500., -500., 10.], dtype=DTYPE, requires_grad=True)
        plan = IPCWPlan(time, zero, time, zero)
        loss = plan.brier(train_risk, eval_risk)
        grads = torch.autograd.grad(loss, (train_risk, eval_risk))
        self.assertTrue(bool(torch.isfinite(loss)))
        self.assertTrue(all(bool(torch.isfinite(g).all()) for g in grads))
        torch.testing.assert_close(plan.survival(train_risk, eval_risk), torch.ones((3, 50), dtype=DTYPE))
        nonzero = IPCWPlan(time, torch.ones_like(time), time, torch.ones_like(time))
        extreme = nonzero.brier(train_risk, eval_risk)
        extreme_grads = torch.autograd.grad(extreme, (train_risk, eval_risk), create_graph=True)
        self.assertTrue(bool(torch.isfinite(extreme)))
        self.assertTrue(all(bool(torch.isfinite(g).all()) for g in extreme_grads))

    def test_event_first_reverse_km_at_mixed_tie(self):
        time = torch.tensor([1., 1., 2., 3.], dtype=DTYPE)
        event = torch.tensor([1., 0., 1., 1.], dtype=DTYPE)
        plan = IPCWPlan(time, event, time, event, grid=torch.tensor([1., 2.], dtype=DTYPE))
        # One event leaves before one censor among the remaining three at risk.
        torch.testing.assert_close(plan.censoring_survival(torch.tensor([1.], dtype=DTYPE)),
                                   torch.tensor([2/3], dtype=DTYPE))
        torch.testing.assert_close(plan.censoring_survival(torch.tensor([1.], dtype=DTYPE), left=True),
                                   torch.ones(1, dtype=DTYPE))

    def test_torch_survival_and_brier_match_numpy_metrics_on_same_protocol(self):
        import numpy as np
        from survpinoise.metrics import (fit_breslow_baseline, fit_censoring_km,
                                        ipcw_brier_score, integrated_brier_score)
        time = torch.tensor([1., 1., 2., 3., 4., 5.], dtype=DTYPE)
        event = torch.tensor([1., 0., 1., 0., 1., 1.], dtype=DTYPE)
        eval_time = torch.tensor([1., 2.5, 4.5], dtype=DTYPE)
        eval_event = torch.tensor([1., 0., 1.], dtype=DTYPE)
        grid = torch.tensor([.5, 1., 2., 3., 4.], dtype=DTYPE)
        risk = torch.tensor([.2, -.4, .7, .1, -.6, .9], dtype=DTYPE)
        eval_risk = torch.tensor([.3, -.2, .8], dtype=DTYPE)
        plan = IPCWPlan(time, event, eval_time, eval_event, grid=grid)
        baseline = fit_breslow_baseline(time.numpy(), event.numpy(), risk.numpy())
        censoring = fit_censoring_km(time.numpy(), event.numpy(), min_g=.05)
        numpy_survival = baseline.predict_survival(eval_risk.numpy(), grid.numpy())
        numpy_brier = ipcw_brier_score(eval_time.numpy(), eval_event.numpy(), numpy_survival,
                                      grid.numpy(), censoring)
        numpy_ibs = integrated_brier_score(eval_time.numpy(), eval_event.numpy(), numpy_survival,
                                          grid.numpy(), censoring)
        np.testing.assert_allclose(plan.survival(risk, eval_risk).numpy(), numpy_survival, rtol=1e-12, atol=1e-12)
        np.testing.assert_allclose(plan.brier_by_time(risk, eval_risk).numpy(), numpy_brier, rtol=1e-12, atol=1e-12)
        self.assertAlmostEqual(plan.brier(risk, eval_risk).item(), numpy_brier.mean(), places=12)
        self.assertAlmostEqual(plan.ibs(risk, eval_risk).item(), numpy_ibs, places=12)
        np.testing.assert_allclose(plan.censoring_survival(grid).numpy(),
                                   censoring.predict(grid.numpy(), clip=True), rtol=1e-12, atol=1e-12)

    def test_virtual_step_has_nonzero_second_order_generator_hypergradient(self):
        torch.manual_seed(7)
        x_train = torch.tensor([[-1., .3], [.2, 1.], [1., -.5], [.7, .8], [-.4, -.7]], dtype=DTYPE)
        x_eval = torch.tensor([[.8, .1], [-.7, .6], [.4, -1.]], dtype=DTYPE)
        time_train = torch.tensor([1., 2., 2., 3., 4.], dtype=DTYPE)
        event_train = torch.tensor([1., 1., 0., 1., 1.], dtype=DTYPE)
        time_eval = torch.tensor([1.5, 2.5, 3.5], dtype=DTYPE)
        event_eval = torch.tensor([1., 0., 1.], dtype=DTYPE)
        model = nn.Sequential(nn.Linear(2, 3), nn.Tanh(), nn.Linear(3, 1)).to(dtype=DTYPE)
        theta = torch.tensor(.2, dtype=DTYPE, requires_grad=True)
        direction = torch.tensor([[.4, -.3], [-.2, .5], [.3, .1], [-.4, .2], [.1, -.5]], dtype=DTYPE)
        cox_plan = CoxBreslowPlan(time_train, event_train)
        brier_plan = IPCWPlan(time_train, event_train, time_eval, event_eval)
        params = dict(model.named_parameters())
        noisy_x = x_train + theta.sigmoid() * direction
        inner = cox_plan.nll(functional_call(model, params, (noisy_x,)).squeeze(-1))
        gradients = torch.autograd.grad(inner, tuple(params.values()), create_graph=True)
        virtual = {name: parameter - .15 * gradient
                   for (name, parameter), gradient in zip(params.items(), gradients)}
        virtual_train = functional_call(model, virtual, (x_train,)).squeeze(-1)
        virtual_eval = functional_call(model, virtual, (x_eval,)).squeeze(-1)
        brier = brier_plan.brier(virtual_train, virtual_eval)
        brier_hypergradient, = torch.autograd.grad(brier, theta, retain_graph=True)
        outer = cox_breslow_nll(virtual_eval, time_eval, event_eval) + 2.0 * brier
        total_hypergradient, = torch.autograd.grad(outer, theta)
        self.assertTrue(bool(torch.isfinite(brier_hypergradient)))
        self.assertTrue(bool(torch.isfinite(total_hypergradient)))
        self.assertGreater(abs(brier_hypergradient.item()), 1e-10)
        self.assertGreater(abs(total_hypergradient.item()), 1e-10)

    def test_brier_baseline_has_nonzero_training_risk_gradient(self):
        train_time = torch.tensor([1., 2., 3., 4.], dtype=DTYPE)
        train_event = torch.ones(4, dtype=DTYPE)
        eval_time = torch.tensor([1.5, 3.5], dtype=DTYPE)
        eval_event = torch.ones(2, dtype=DTYPE)
        plan = IPCWPlan(train_time, train_event, eval_time, eval_event)
        train_risk = torch.tensor([.3, -.1, .8, -.6], dtype=DTYPE, requires_grad=True)
        eval_risk = torch.tensor([.2, -.4], dtype=DTYPE, requires_grad=True)
        gradient, = torch.autograd.grad(plan.brier(train_risk, eval_risk), train_risk, create_graph=True)
        self.assertGreater(gradient.abs().sum().item(), 1e-10)
        hessian = torch.autograd.functional.hessian(lambda r: plan.brier(r, eval_risk), train_risk)
        self.assertTrue(bool(torch.isfinite(hessian).all()))


if __name__ == "__main__":
    unittest.main()
