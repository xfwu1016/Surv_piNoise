"""Tests of training-only fitting, endpoint handling and source separation."""
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd

from survpinoise.data import (DEFAULT_DATA_DIR, FLCHAIN_FEATURES, SOURCE_SPECS, SurvivalDataset,
                             TrainPreprocessor, load_dataset, split_dataset, stratified_indices)


class DataProtocolTests(unittest.TestCase):
    def test_train_only_fitting_and_unknown_categories(self):
        train = pd.DataFrame({"n": [0.0, 2.0, np.nan], "cat": ["a", "b", None]})
        prep = TrainPreprocessor().fit(train, ("cat",))
        state = prep.state_dict()
        heldout = pd.DataFrame({"n": [1000.0, np.nan], "cat": ["new", None]})
        transformed = prep.transform(heldout)
        self.assertEqual(state, prep.state_dict())
        self.assertEqual(state["numeric"]["n"]["median"], 1.0)
        self.assertAlmostEqual(float(transformed[1, 0]), 0.0)
        self.assertTrue(np.all(transformed[0, 1:] == 0))
        self.assertEqual(float(transformed[1, 1:].sum()), 1.0)

    def test_all_missing_and_constant_numeric(self):
        prep = TrainPreprocessor().fit(pd.DataFrame({"a": [np.nan, np.nan], "b": [3, 3]}))
        np.testing.assert_array_equal(prep.transform(pd.DataFrame({"a": [np.nan], "b": [3]})), [[0, 0]])

    def test_stratified_split_reproducible_disjoint_and_complete(self):
        event = np.array([0] * 57 + [1] * 43)
        one = stratified_indices(event, 19)
        two = stratified_indices(event, 19)
        for a, b in zip(one, two):
            np.testing.assert_array_equal(a, b)
            self.assertLessEqual(abs(float(event[a].sum()) - len(a) * float(event.mean())), 1.0)
        self.assertEqual([len(x) for x in one], [60, 20, 20])
        np.testing.assert_array_equal(np.sort(np.concatenate(one)), np.arange(100))
        self.assertEqual(len(set(np.concatenate(one))), 100)
        self.assertFalse(np.array_equal(one[0], stratified_indices(event, 20)[0]))

    def test_invalid_labels_times_and_schema_rejected(self):
        for times, events in (([1, 2], [1, 2]), ([1, np.nan], [1, 0]), ([-1, 2], [1, 0])):
            with self.assertRaises(ValueError):
                SurvivalDataset("bad", pd.DataFrame({"x": [1, 2]}), times, events)
        prep = TrainPreprocessor().fit(pd.DataFrame({"x": [1, 2]}))
        with self.assertRaises(ValueError):
            prep.transform(pd.DataFrame({"y": [1]}))

    def test_zero_time_is_retained(self):
        data = SurvivalDataset("tiny", pd.DataFrame({"x": [1] * 10}), [0] + [1] * 9, [0] * 5 + [1] * 5)
        result = split_dataset(data, 4)
        self.assertEqual(sum(int((p.time == 0).sum()) for p in (result.train, result.val, result.test)), 1)
        self.assertTrue(all(p.x.dtype == np.float32 for p in (result.train, result.val, result.test)))

    def test_flchain_excludes_outcome_derived_column_and_retains_missing(self):
        source = pd.DataFrame({"age": [60, 70], "sex": ["F", "M"], "sample.yr": [1995, 1996], "kappa": [1, 2],
                               "lambda": [1, 2], "flc.grp": [1, 2], "creatinine": [np.nan, 1], "mgus": [0, 1],
                               "futime": [0, 4], "death": [1, 0], "chapter": ["cancer", None], "rownames": [1, 2]})
        with tempfile.TemporaryDirectory() as directory:
            source.to_csv(Path(directory) / "flchain.csv", index=False)
            result = load_dataset("flchain", directory, verify=False)
        self.assertEqual(tuple(result.x.columns), FLCHAIN_FEATURES)
        self.assertEqual(len(result.x), 2)
        self.assertEqual(int(result.x["creatinine"].isna().sum()), 1)
        self.assertNotIn("chapter", result.x)

    def test_checksum_mismatch_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            (Path(directory) / "flchain.csv").write_text("not the official file")
            with self.assertRaisesRegex(ValueError, "Checksum mismatch"):
                load_dataset("flchain", directory)

    @unittest.skipUnless(all((DEFAULT_DATA_DIR / spec["filename"]).exists() for spec in SOURCE_SPECS.values()), "Downloaded public files not available")
    def test_downloaded_sources_have_finite_splits_and_distinct_cohorts(self):
        data = {name: load_dataset(name) for name in SOURCE_SPECS}
        self.assertEqual(tuple(data["flchain"].x.columns), FLCHAIN_FEATURES)
        self.assertEqual(data["support"].categorical_columns, ("x2", "x3", "x6"))
        self.assertNotEqual(len(data["gbsg"].time), len(data["gbsg2"].time))
        self.assertEqual(data["gbsg"].x.shape[1], 7)
        self.assertEqual(data["gbsg2"].x.shape[1], 8)
        for dataset in data.values():
            result = split_dataset(dataset, 10)
            self.assertTrue(all(np.isfinite(part.x).all() for part in (result.train, result.val, result.test)))
            self.assertEqual(sum(len(part.time) for part in (result.train, result.val, result.test)), len(dataset.time))


if __name__ == "__main__":
    unittest.main()
