"""Independent censoring calibration; no training or outcome tuning."""

import json
import math
from pathlib import Path
import tempfile
import unittest

import numpy as np

from survpinoise.censoring_design import (LAW_VERSION, MASTER_SEED, TARGETS,
                                         calibrate_scale, expected_censoring,
                                         get_scale, prepare_config,
                                         sample_pilot_failure_times)


class CensoringDesignTests(unittest.TestCase):
    def test_constant_failure_time_has_analytic_scale(self):
        # For T=10, P(C<T)=1-exp(-10/scale), hence scale=-10/log(1-target).
        for target in (.2, .4, .6):
            actual = calibrate_scale(np.full(100, 10.), target)
            expected = -10/math.log1p(-target)
            self.assertAlmostEqual(actual/expected, 1., places=8)

    def test_target_probability_is_monotone_and_targets_reached(self):
        failure = np.array([1., 3., 8., 20., 100.])
        self.assertGreater(expected_censoring(failure, 5.), expected_censoring(failure, 50.))
        scales = [calibrate_scale(failure, target) for target in (.2, .4, .6)]
        self.assertGreater(scales[0], scales[1])
        self.assertGreater(scales[1], scales[2])
        for target, scale in zip((.2, .4, .6), scales):
            self.assertLess(abs(expected_censoring(failure, scale)-target), 1e-10)

    def test_pilot_streams_are_reproducible_and_positive(self):
        for key in TARGETS:
            with self.subTest(mechanism=key):
                first = sample_pilot_failure_times(key, n_pilot=300)
                second = sample_pilot_failure_times(key, n_pilot=300)
                np.testing.assert_array_equal(first, second)
                self.assertTrue(np.isfinite(first).all())
                self.assertTrue(np.all(first > 0))
                if key == "reliability":
                    self.assertTrue(np.all((first >= 15) & (first <= 500)))

    def test_s3_pilot_inverts_registered_piecewise_hazard(self):
        # Reconstruct the separate pilot's AR1 covariates and exponential
        # event-clock draws, then check H(T|X)=-log(U) pointwise.
        n = 300
        rng = np.random.default_rng(np.random.SeedSequence([MASTER_SEED, 3]))
        x = rng.normal(size=(n, 20))
        for j in range(1, 20):
            x[:, j] = .35*x[:, j-1]+np.sqrt(1-.35**2)*x[:, j]
        w = -np.log(rng.uniform(1e-12, 1, size=n))
        failure = sample_pilot_failure_times("S3", n_pilot=n)
        a = .8*x[:, 0]-.6*x[:, 1]
        cumulative = (np.exp(a)*(np.minimum(failure, 20)/20)**1.3
                      +np.exp(a+.5*x[:, 2])*np.maximum((failure/20)**1.3-1, 0))
        np.testing.assert_allclose(cumulative, w, rtol=1e-12, atol=1e-12)

    def test_config_has_all_thirteen_scales_and_auditable_separate_pilots(self):
        config = prepare_config(n_pilot=300)
        self.assertEqual(sum(len(values) for values in config["scales"].values()), 13)
        self.assertFalse(config["calibration"]["main_cohort_used"])
        self.assertFalse(config["calibration"]["test_outcomes_used"])
        self.assertEqual(config["calibration"]["master_seed"], MASTER_SEED)
        self.assertEqual(config["law_version"], LAW_VERSION)
        for key, detail in config["pilot_details"].items():
            self.assertEqual(detail["n_pilot"], 300)
            for check in detail["target_checks"].values():
                self.assertLessEqual(check["absolute_error"], 1e-10)
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory)/"scales.json"
            path.write_text(json.dumps(config))
            self.assertEqual(get_scale("S2", .4, path), config["scales"]["S2"]["0.4"])
            self.assertEqual(get_scale("reliability_shift", .38, path),
                             get_scale("reliability_nominal", .38, path))
            with self.assertRaisesRegex(ValueError, "no pre-calibrated"):
                get_scale("S1", .3, path)

    def test_missing_config_never_falls_back_to_cohort_calibration(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(FileNotFoundError):
                get_scale("S1", .4, Path(directory)/"missing.json")

    def test_invalid_failure_times_and_targets_are_rejected(self):
        for times in ([], [0., 1.], [-1., 1.], [float("nan")]):
            with self.assertRaises(ValueError):
                calibrate_scale(times, .4)
        for target in (0., 1., -.1, float("nan")):
            with self.assertRaises(ValueError):
                calibrate_scale([1., 2.], target)


if __name__ == "__main__":
    unittest.main()
