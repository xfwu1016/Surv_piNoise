import json
from pathlib import Path
import unittest
import numpy as np
import torch
from survpinoise.data import split_dataset
from survpinoise.simulation import make_simulation,make_reliability
from survpinoise.training import Generator,run_methods

class TrainingTests(unittest.TestCase):
    def test_zero_budget_has_identical_final_predictors(self):
        torch.set_num_threads(1)
        protocol=json.loads((Path(__file__).resolve().parents[1]/'configs/protocol.json').read_text())
        cfg=protocol['training'];cfg.update(warm_epochs=2,adapt_epochs=2,refit_epochs=3,rho=0.,fixed_radii=[0.])
        split=split_dataset(make_simulation('S1',987,smoke=True),987)
        rows,artifacts,_=run_methods(split,'DeepSurv',987,cfg,protocol['methods'])
        ref=artifacts['Clean']['test_risk']
        for item in artifacts.values():np.testing.assert_array_equal(ref,item['test_risk'])
    def test_symmetric_generator_is_bounded_and_binary_mask_is_immutable(self):
        torch.manual_seed(1);x=torch.randn(100,6);mask=torch.tensor([1,1,1,0,0,0.])
        g=Generator(6,mask,1.8);e=g(x,torch.randn(100),torch.ones(100),torch.Generator().manual_seed(1))
        self.assertTrue(torch.all(torch.linalg.vector_norm(e,dim=1)<=1.8+1e-6))
        self.assertEqual(e[:,3:].abs().sum().item(),0.)
    def test_scenarios_finite_and_reliability_shift_repeatable(self):
        for name in ['S1','S2','S3','S4']:
            ds=make_simulation(name,234,smoke=True)
            self.assertTrue(np.isfinite(ds.time).all());self.assertTrue(np.all(ds.time>0))
        a=make_reliability(234,smoke=True);b=make_reliability(234,smoke=True)
        np.testing.assert_array_equal(a.x.to_numpy(),b.x.to_numpy())

if __name__=='__main__':unittest.main()
