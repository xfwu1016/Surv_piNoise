"""Hand-calculated checks for corrected train-reference survival evaluation."""
from pathlib import Path
import json
import math
import sys
import unittest

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from survpinoise.metrics import (fit_censoring_km, fit_breslow_baseline,
                                make_evaluation_protocol, uno_cindex,
                                ipcw_brier_score, integrated_brier_score,
                                evaluate_predictions, paired_summary)


class CensoringAndBaselineTests(unittest.TestCase):
    def test_reverse_km_event_first_mixed_tie_and_left_limits(self):
        km = fit_censoring_km([1, 1, 2, 3], [1, 0, 1, 0])
        np.testing.assert_allclose(km.survival_after, [2/3, 2/3, 0])
        self.assertEqual(km.predict(1, left=True), 1)
        self.assertAlmostEqual(km.predict(1), 2/3)
        self.assertAlmostEqual(km.predict(3, left=True), 2/3)
        self.assertEqual(km.predict(3), 0)
        self.assertLess(km.positive_support_upper, 3)
        with self.assertRaises(ValueError):
            km.predict(4)

    def test_no_censoring_stays_one_including_last_all_event_tie(self):
        km = fit_censoring_km([1, 2, 2], [1, 1, 1])
        np.testing.assert_array_equal(km.survival_after, [1, 1])

    def test_breslow_events_at_same_time_share_complete_denominator(self):
        base = fit_breslow_baseline([1, 1, 2], [1, 1, 1], [0, 0, 0])
        np.testing.assert_allclose(base.cumulative_hazard([0, 1, 2]), [0, 2/3, 5/3])
        with_censor = fit_breslow_baseline([1, 1, 2], [1, 0, 1], [0, 0, 0])
        np.testing.assert_allclose(with_censor.cumulative_hazard([1, 2]), [1/3, 4/3])

    def test_breslow_order_invariant_and_risk_shift_invariant(self):
        y, e, risk = np.array([1, 1, 3, 4]), np.array([1, 0, 1, 1]), np.array([2., -1., .3, -.8])
        base = fit_breslow_baseline(y, e, risk)
        order = [3, 1, 0, 2]
        permuted = fit_breslow_baseline(y[order], e[order], risk[order])
        shifted = fit_breslow_baseline(y, e, risk+1000)
        expected = base.predict_survival([.5, -.2], [0, 1, 2, 4])
        np.testing.assert_allclose(permuted.predict_survival([.5, -.2], [0, 1, 2, 4]), expected)
        np.testing.assert_allclose(shifted.predict_survival([1000.5, 999.8], [0, 1, 2, 4]), expected, atol=1e-12)


class MetricTests(unittest.TestCase):
    def test_perfect_reverse_and_tied_risk_concordance(self):
        y, e = np.arange(1., 5.), np.ones(4)
        km = fit_censoring_km(y, e)
        self.assertEqual(uno_cindex(y, e, -y, km, 3.5), 1)
        self.assertEqual(uno_cindex(y, e, y, km, 3.5), 0)
        self.assertEqual(uno_cindex(y, e, np.zeros(4), km, 3.5), .5)

    def test_uno_training_g_weights_hand_calculation_and_chunking(self):
        km = fit_censoring_km([1, 2, 3, 4], [1, 0, 1, 1])
        # Anchor 1: two concordant pairs, weight 1. Anchor 2.5: one
        # discordant pair, weight 1/(2/3)^2. Result=2/(2+2.25)=8/17.
        value = uno_cindex([1, 2.5, 3], [1, 1, 1], [3, 1, 2], km, 2.7, max_pairs_per_chunk=1)
        self.assertAlmostEqual(value, 8/17)

    def test_event_censor_time_tie_is_comparable_but_event_event_is_not(self):
        km = fit_censoring_km([1, 2, 3], [1, 1, 1])
        value, details = uno_cindex([1, 1, 2], [1, 0, 1], [3, 1, 2], km, 1.5, return_diagnostics=True)
        self.assertEqual(value, 1)
        self.assertEqual(details['comparable_pairs'], 2)
        self.assertEqual(details['event_censor_same_time_pairs'], 1)
        with self.assertRaises(ValueError):
            uno_cindex([1, 1], [1, 1], [3, 1], km, 1.5)

    def test_ipcw_brier_uses_event_left_limit_and_zeros_censored_contribution(self):
        km = fit_censoring_km([1, 1, 2, 3], [1, 0, 1, 0])
        # t=1 or 2: .25/G(1-)=.25 from failure, zero from censor,
        # and two survivors each .25/G(t)=.375. Mean=.25.
        probability = np.full((4, 2), .5)
        curve, details = ipcw_brier_score([1, 1, 2.5, 3], [1, 0, 1, 1], probability, [1, 2], km, return_diagnostics=True)
        np.testing.assert_allclose(curve, [.25, .25])
        self.assertEqual(details['censored_before_or_at_time'], [1, 1])
        self.assertAlmostEqual(integrated_brier_score([1, 1, 2.5, 3], [1, 0, 1, 1], probability, [1, 2], km), .25)

    def test_brier_without_censoring_equals_direct_squared_error(self):
        km = fit_censoring_km([1, 2, 3, 4], [1, 1, 1, 1])
        p = np.array([[.1, 0], [.8, .2], [.9, .7]])
        y, e, grid = np.array([1, 2, 4]), np.ones(3), np.array([1.5, 3])
        truth = (y[:, None] > grid).astype(float)
        np.testing.assert_allclose(ipcw_brier_score(y, e, p, grid, km), ((truth-p)**2).mean(0))

    def test_clip_diagnostics_exposed_and_no_zero_g_rescue(self):
        km = fit_censoring_km([1, 1, 2, 3], [1, 0, 1, 0], min_g=.8)
        _, details = ipcw_brier_score([1, 1, 2.5, 3], [1, 0, 1, 1], np.full((4, 2), .5), [1, 2], km, return_diagnostics=True)
        self.assertEqual(details['grid_g_clipped_count'], 2)
        self.assertAlmostEqual(details['grid_raw_g_min'], 2/3)
        self.assertEqual(details['grid_effective_g_min'], .8)
        with self.assertRaises(ValueError):
            ipcw_brier_score([1, 2], [1, 1], np.ones((2, 2)), [2, 3], km)

    def test_protocol_uses_only_inner_training_quantiles_and_positive_g_support(self):
        protocol = make_evaluation_protocol([1, 2, 3, 4, 5], [1, 1, 1, 1, 1])
        self.assertEqual(len(protocol.grid), 50)
        np.testing.assert_allclose(protocol.grid[[0, -1]], [1.4, 4.2])
        self.assertAlmostEqual(protocol.tau, 4.2)
        self.assertEqual(protocol.censoring.min_g, .05)
        self.assertFalse(protocol.metadata['test_followup_used_for_support'])
        self.assertEqual(protocol.metadata['protocol_fit_source'], 'inner_training_only')
        with self.assertRaises(ValueError):
            protocol.grid[0] = 0
        with self.assertRaises(TypeError):
            make_evaluation_protocol([1, 2, 3, 4, 5], [1]*5, test_time=[.1, 3])

    def test_complete_evaluation_is_json_serializable_and_no_test_km_fit(self):
        y, e = [1, 2, 3, 4, 5], [1]*5
        protocol = make_evaluation_protocol(y, e)
        base = fit_breslow_baseline(y, e, [2, 1, 0, -1, -2])
        result = evaluate_predictions([1.5, 2.5, 4.5], [1, 0, 1], [2, 0, -2], base, protocol)
        self.assertEqual(result['diagnostics']['ibs']['censoring_fit_source'], 'training_reference')
        self.assertEqual(result['diagnostics']['protocol']['censoring']['n_training'], 5)
        self.assertEqual(np.shape(result['pred_survival']), (3, 50))
        self.assertEqual(len(result['brier_curve']), 50)
        json.dumps(result, allow_nan=False)

    def test_test_followup_outside_training_range_is_not_dropped_or_fitted(self):
        y, e = [1, 2, 3, 4, 5], [1]*5
        protocol = make_evaluation_protocol(y, e)
        base = fit_breslow_baseline(y, e, [2, 1, 0, -1, -2])
        result = evaluate_predictions([.1, 1.5, 100], [0, 1, 0], [-1, 2, -2], base, protocol)
        self.assertEqual(result['diagnostics']['ibs']['n_test'], 3)
        self.assertEqual(result['diagnostics']['ibs']['censored_before_or_at_time'][0], 1)
        np.testing.assert_allclose(result['brier_times'], protocol.grid)
        np.testing.assert_allclose(protocol.censoring.survival_after, np.ones(5))
        self.assertEqual(result['cindex'], 1)

    def test_ipcw_brier_can_exceed_one_without_renormalizing_weights(self):
        km = fit_censoring_km([.1, .2, .3, .4], [0, 0, 0, 1])
        # Training G=.25 over this grid. One test subject survives beyond it
        # but is assigned survival probability zero: IPCW error=1/.25=4.
        score = integrated_brier_score([1], [0], np.zeros((1, 2)), [.31, .35], km)
        self.assertAlmostEqual(score, 4)

    def test_invalid_inputs_fail_explicitly(self):
        with self.assertRaises(ValueError):
            fit_censoring_km([1, 2], [1, .5])
        with self.assertRaises(ValueError):
            fit_breslow_baseline([1, 2], [0, 0], [1, 0])
        with self.assertRaises(ValueError):
            make_evaluation_protocol([1, 2], [0, 0])
        with self.assertRaises(ValueError):
            make_evaluation_protocol([1, 1], [1, 1])


class PairedSummaryTests(unittest.TestCase):
    def test_paired_not_independent_uncertainty(self):
        rows = []
        for seed, clean in enumerate([.4, .5, .6]):
            rows += [{'seed': seed, 'method': 'Clean', 'cindex': clean, 'ibs': .3},
                     {'seed': seed, 'method': 'Learned', 'cindex': clean+.1, 'ibs': .25}]
        report = paired_summary(rows)
        ci = report['paired_ci'][0]
        self.assertAlmostEqual(ci['mean_difference'], .1)
        self.assertAlmostEqual(ci['ci_low'], .1)
        self.assertAlmostEqual(ci['ci_high'], .1)
        self.assertAlmostEqual(report['summary'][1]['cindex_sd'], .1)
        self.assertAlmostEqual(report['paired_ci'][1]['mean_difference'], .05)

    def test_two_pairs_use_t_not_normal_and_accept_ibs_above_one(self):
        rows = [{'split': i, 'method': method, 'cindex': c, 'ibs': ib}
                for i in range(2) for method, c, ib in
                [('Clean', .5, 1.2), ('Learned', .6+i*.1, 1.0)]]
        result = paired_summary(rows)
        ci = result['paired_ci'][0]
        half = 12.706204736432095 * np.std([.1, .2], ddof=1) / math.sqrt(2)
        self.assertAlmostEqual(ci['ci_high']-ci['mean_difference'], half)

    def test_incomplete_duplicate_or_one_pair(self):
        rows = [{'seed': 1, 'method': 'Clean', 'cindex': .5, 'ibs': .3},
                {'seed': 1, 'method': 'Learned', 'cindex': .6, 'ibs': .2}]
        self.assertIsNone(paired_summary(rows)['paired_ci'][0]['ci_low'])
        with self.assertRaises(ValueError):
            paired_summary(rows + [rows[0]])
        with self.assertRaises(ValueError):
            paired_summary(rows + [{'seed': 2, 'method': 'Clean', 'cindex': .5, 'ibs': .3}])


if __name__ == '__main__':
    unittest.main()
