# Surv-piNoise experiments — version 0.2.2

This repository evaluates outcome-conditioned perturbations for right-censored survival prediction with matched predictor initialization, fixed refit budgets, and training-only censoring evaluation. It accompanies the manuscript **Bilevel Positive-Incentive Noise for Censored Time-to-Event Prediction** and covers simulations, four clinical datasets, synthetic reliability settings, ablations, and an exploratory parameter analysis.

**Authors:** Tu Jinwen, Kai Qi, Xiaofei Wu. Tu Jinwen and Kai Qi contributed equally and are co-first authors. Xiaofei Wu is the sole corresponding author: xfwu1016@ynu.edu.cn. See [CITATION.cff](CITATION.cff).

## What the completed run supports

The reference `corrected_v1` run completed **440 cells, 1,840 method rows, and 36 condition groups, with zero failed cells**. All planned settings and seeds are retained. A cell is one condition/seed evaluated across its specified methods.

Full Surv-piNoise improves IBS relative to Clean and Joint generator in the controlled synthetic shift setting. Benefits do not generalize across the benchmarks: the eight clinical conditions show no favorable Full-versus-Clean paired interval; several simulations show worse C-index; fixed Gaussian noise often has lower IBS. In the shift setting, Full has a C-index/IBS tradeoff against fixed noise. Ablations do not establish that outcome inputs or the Brier outer term are necessary. Intervals are exploratory; see [REPRODUCTION.md](REPRODUCTION.md#interpreting-the-results).

Version 0.2.1 adds a separate, complete exploratory parameter scan: **600 fits, 60 dataset/parameter groups, zero failures**. It crosses five perturbation budgets with four outer Brier weights on GBSG2 and nominal/shifted synthetic reliability, with ten matched seeds. The primary training modules and `corrected_v1` results are unchanged. The scan reuses the original data/test splits and retains the original default; it is not independent validation. Larger budgets help the constructed shift but can harm nominal discrimination.

## Joint parameter sensitivity

After installing the dependencies below, download GBSG2 and run from the repository root:

```bash
python scripts/download_data.py --datasets gbsg2
python scripts/run_sensitivity.py --workers 6 --reference-dir reported_results/corrected_v1 --output results/sensitivity_reproduced
python scripts/plot_sensitivity.py --input results/sensitivity_reproduced/results_raw.csv --output results/sensitivity_reproduced/figures --width-mm 137 --height-mm 160
```

The full 20/50/100-epoch budget is used for every fit. Repeating the runner command resumes only matching source/configuration/environment fingerprints. The reference CSV is included in `reported_results/corrected_v1/`; the runner's original default assumes a locally available `results/corrected_v1/`, so retain the explicit `--reference-dir` argument above for a fresh source download. The three-dimensional figure is accompanied by a complete annotated heatmap and mean/SD/pointwise-interval CSV. See `configs/sensitivity_protocol.json` and [the extended reproduction record](REPRODUCTION.md#joint-parameter-sensitivity-extension). The compact `reported_results/sensitivity_v1/` directory includes the raw seed-level metrics and summaries without clinical records, models, or individual predictions. Full experiment outputs can be generated locally using the commands below.

## Install and run

Use Python **3.12**. The reference run used Python 3.12.14, Windows x86-64, CPU PyTorch 2.6.0+cpu, and one PyTorch thread per worker. From the repository root:

```bash
python -m venv .venv
```

Activate the environment with `.venv\Scripts\Activate.ps1` in PowerShell or `source .venv/bin/activate` on Linux/macOS, then:

```bash
python -m pip install --upgrade pip
python -m pip install torch==2.6.0 --index-url https://download.pytorch.org/whl/cpu
python -m pip install -r requirements.txt
python scripts/download_data.py
python -m unittest discover -s tests -v
python scripts/analyze_results.py --self-test
```

Downloading without `--datasets` includes the additional `gbsg` source needed by the complete downloaded-data test; `gbsg` is not a formal clinical benchmark and is distinct from `gbsg2`. Data files are checksum-checked. Consult the upstream terms described below before obtaining or redistributing them.

The committed independent-pilot censoring configuration is already fixed. To regenerate it separately and compare it without overwriting the reference file:

```bash
python scripts/prepare_censoring.py --output results/pilot_check/censoring_scales.json --n-pilot 20000 --seed 20261027
```

The runner reads `configs/censoring_scales.json`; it does not read `results/pilot_check/`. Verify the regenerated configuration against that committed file before changing a protocol. See [the pilot procedure](REPRODUCTION.md#independent-censoring-calibration).

Run the short functional check in its own output directory, then the full study:

```bash
python scripts/run_experiments.py --smoke --workers 2 --output results/smoke_check
python scripts/run_experiments.py --suite all --workers 6 --output results/reproduced_v1
python scripts/analyze_results.py --input results/reproduced_v1 --check-only
python scripts/analyze_results.py --input results/reproduced_v1
```

Smoke produces 2 small cells/11 method rows and is not scientific evidence. The analysis script requires a complete, failure-free, non-smoke all-suite run. It rejects smoke and partial-suite outputs. Six PDF/PNG figure pairs, LaTeX tables, and complete comparison CSVs are generated after analysis. Use a new output directory for any changed protocol, code, or environment. Resume is automatic when repeating the same runner command and fingerprint; there is no `--resume` flag.

## Files and result distribution

| Path | Purpose |
|---|---|
| `survpinoise/` | Data handling, simulation, losses, evaluation, training, independent censoring pilot, diagnostics |
| `configs/protocol.json` | Frozen study plan and training settings; its internal protocol label is `0.2-corrected` |
| `configs/censoring_scales.json` | Frozen independent-pilot censoring scales |
| `scripts/` | Download, pilot generation, experiment runner, complete-run analysis |
| `tests/` | Hand-worked metrics, ties, preprocessing, gradient and training checks |
| `reported_results/` | Small reference summaries and a path-free run receipt; no models or patient-level data |
| `data/raw/`, `results/` | Generated local artifacts, excluded by `.gitignore` |

The normal GitHub source upload should include the code, configuration, documentation, tests, and `reported_results/`. **Keep the full reference result bundle separate**: it contains all cell manifests, models, test predictions, split/preprocessing records, diagnostics, raw metric rows, and analysis. Do not publish downloaded clinical files or model/prediction artifacts under this repository's name without checking their applicable upstream conditions. No public repository URL, release download URL, or DOI has been registered in this package.

Reference fingerprint:

```text
3e32972965be8f544eb1563bc0f1f9cf5a622c9a3772102cfe4d68128f48b41b
```

The fingerprint includes code/configuration hashes, the execution plan, and environment details, including platform and CPU count. A new machine normally produces a different fingerprint; cross-machine byte-identical floating-point results are not promised. [REPRODUCTION.md](REPRODUCTION.md) describes the complete output contract and comparison checks.

## Data and permissions

The download sources are DeepSurv's processed SUPPORT/METABRIC HDF5 files, `survival::flchain` via Rdatasets, and scikit-survival's GBSG2 ARFF file. These are processed public benchmark representations, not newly collected clinical data. The reliability experiment is synthetic and does not download or analyze NASA C-MAPSS trajectories. HDF5 upstream preprocessing scope has not been recovered; only this repository's additional preprocessing is fitted on its inner-training split.

Upstream repository/package licensing was checked on 2026-10-27, but a separate grant covering every underlying clinical data file has **not** been established. DeepSurv's software license, Rdatasets' data caveat, and scikit-survival's software license must not be treated as a license for this new repository or as blanket permission to redistribute clinical records. See [the source and permission record](REPRODUCTION.md#data-sources-and-permission-status).

No software license has been specified for this repository. Contact the corresponding author for reuse permission. Third-party software and datasets retain their own terms; see LICENSE_NOTICE.txt.
