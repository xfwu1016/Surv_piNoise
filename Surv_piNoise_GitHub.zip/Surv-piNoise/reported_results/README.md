# Small reference summaries

These files are copied from the completed `corrected_v1` analysis, without retraining or changing estimates:

- `summary_metrics.csv`: descriptive means/sample SDs for every condition and method.
- `paired_comparisons.csv`: all main methods against Clean, and ablation variants against Full; inspect the direction columns.
- `full_method_comparisons.csv`: Full against Clean/Fixed Gaussian/Joint, with seed-paired intervals and separate Holm p-values.
- `reference_run.json`: a path-free reference receipt with source/config hashes, environment, counts, CSV hashes and evidence limits.

These aggregates contain no model weights, downloaded clinical records, or patient-level predictions. They are not sufficient to run the complete artifact audit. Obtain or generate the separate full bundle described in `REPRODUCTION.md` for that purpose. No repository/download URL or software license is assigned here.
