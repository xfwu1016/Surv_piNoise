# Separate exploratory sensitivity reference

600 full-budget fits / 60 parameter groups / 10 matched seeds per group; zero failures. This directory contains only seed-level aggregate metrics, reference receipts, summaries and audit records. Individual records, split files, models and predictions are excluded from the GitHub source package.

The original training core and original default are unchanged. Data/test splits are reused; these are not independent new validation cohorts. The source plot script can regenerate both views directly from results_raw.csv and run.json in this directory. See the repository README and REPRODUCTION.md for commands and scope.
