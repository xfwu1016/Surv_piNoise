"""Matched-initialization, fixed-budget training and validation-only selection."""
from __future__ import annotations
import copy
import time
import numpy as np
import torch
from torch import nn
from torch.func import functional_call
from .losses import CoxBreslowPlan,IPCWPlan
from .metrics import make_evaluation_protocol,fit_breslow_baseline,evaluate_predictions


class Predictor(nn.Module):
    def __init__(self,p,deep,dropout=.2):
        super().__init__()
        self.net=(nn.Sequential(nn.Linear(p,64),nn.ReLU(),nn.Dropout(dropout),nn.Linear(64,32),nn.ReLU(),nn.Linear(32,1)) if deep else nn.Linear(p,1,bias=False))
    def forward(self,x):return self.net(x).reshape(-1)


class Generator(nn.Module):
    def __init__(self,p,mask,rho=1.8,mode='full'):
        super().__init__(); self.rho=rho; self.mode=mode
        self.register_buffer('mask',mask)
        if mode=='fixed_variance':
            self.logits=nn.Parameter(torch.full((p,),-2.))
        else:
            self.net=nn.Sequential(nn.Linear(p+(0 if mode=='no_outcome' else 2),64),nn.ReLU(),nn.Linear(64,64),nn.ReLU(),nn.Linear(64,p*(2 if mode=='nonzero_mean' else 1)))
            nn.init.normal_(self.net[-1].weight,0,.01); nn.init.constant_(self.net[-1].bias,-2.)
            if mode=='nonzero_mean':
                with torch.no_grad():self.net[-1].bias[:p].zero_(); self.net[-1].weight[:p].zero_()
    def scales(self,x,yn,e):
        if self.mode=='fixed_variance':return torch.sigmoid(self.logits)[None,:].expand_as(x)
        u=x if self.mode=='no_outcome' else torch.cat([x,yn[:,None],e[:,None]],1)
        h=self.net(u)
        return torch.sigmoid(h[:,x.shape[1]:] if self.mode=='nonzero_mean' else h)
    def forward(self,x,yn,e,rng):
        scales=self.scales(x,yn,e)*self.mask
        z=torch.randn(x.shape,generator=rng,dtype=x.dtype)*self.mask
        v=z/torch.linalg.vector_norm(z,dim=1,keepdim=True).clamp_min(1.)
        value=scales*v
        if self.mode=='nonzero_mean':
            h=self.net(torch.cat([x,yn[:,None],e[:,None]],1))[:,:x.shape[1]]
            value=value+.5*torch.tanh(h)*self.mask
            value=value/torch.linalg.vector_norm(value,dim=1,keepdim=True).clamp_min(1.)
        return self.rho*value


def _tensors(part,ym,ys):
    x=torch.as_tensor(part.x,dtype=torch.float32)
    y=torch.as_tensor(part.time,dtype=torch.float64)
    e=torch.as_tensor(part.event,dtype=torch.float64)
    yn=torch.as_tensor(np.clip((np.log1p(part.time)-ym)/(2.5*ys),-1,1),dtype=torch.float32)
    return x,y,e,yn


def _mmd(x,xp,max_samples):
    n=min(len(x),max_samples)
    idx=torch.linspace(0,len(x)-1,n).long(); a=x[idx]; b=xp[idx]
    # Squared distances avoid torch.cdist's unsupported second derivative.
    def d2(u,v):return (u.square().sum(1)[:,None]+v.square().sum(1)[None,:]-2*u@v.T).clamp_min(0)
    aa=d2(a,a); bb=d2(b,b); ab=d2(a,b)
    bandwidth=aa.detach().median().clamp_min(.1)
    return (torch.exp(-aa/(2*bandwidth)).mean()+torch.exp(-bb/(2*bandwidth)).mean()-2*torch.exp(-ab/(2*bandwidth)).mean()).clamp_min(0)


def run_methods(split,backbone,seed,config,methods):
    deep=backbone=='DeepSurv'; torch.manual_seed(30000+seed)
    p=split.train.x.shape[1]
    base=Predictor(p,deep,config['dropout']); initial=copy.deepcopy(base.state_dict())
    mask=torch.tensor([len(np.unique(split.train.x[:,j]))>2 for j in range(p)],dtype=torch.float32)
    if mask.sum()==0:raise ValueError('No continuous input available for perturbations')
    ly=np.log1p(split.train.time); ym,ys=float(ly.mean()),float(ly.std()+1e-6)
    tr=_tensors(split.train,ym,ys); va=_tensors(split.validation,ym,ys); te=_tensors(split.test,ym,ys)
    dev=tuple(torch.cat([a,b])for a,b in zip(tr,va)); x,y,e,yn=tr; xv,yv,ev,ynv=va
    train_loss=CoxBreslowPlan(y,e); dev_loss=CoxBreslowPlan(dev[1],dev[2]); val_loss=CoxBreslowPlan(yv,ev)
    brier=IPCWPlan(y,e,yv,ev,n_grid=config['grid_points'],min_g=config['min_g'])
    protocol=make_evaluation_protocol(split.train.time,split.train.event,min_g=config['min_g'],n_grid=config['grid_points'])
    lr=config['deep_lr']if deep else config['cox_lr']
    def fresh():
        model=Predictor(p,deep,config['dropout']); model.load_state_dict(initial); return model
    # Identical clean warm-up state for every adaptive/candidate method.
    torch.manual_seed(31000+seed); warm=fresh(); opt=torch.optim.Adam(warm.parameters(),lr=lr,weight_decay=config['weight_decay'])
    for _ in range(config['warm_epochs']):
        warm.train();opt.zero_grad();loss=train_loss.nll(warm(x));loss.backward();opt.step()
    warm_state=copy.deepcopy(warm.state_dict())
    rows=[]; artifacts={}
    for name in methods:
        started=time.perf_counter(); torch.manual_seed(32000+seed)
        rng=torch.Generator().manual_seed(40000+seed)
        model=fresh();model.load_state_dict(warm_state)
        opt=torch.optim.Adam(model.parameters(),lr=lr,weight_decay=config['weight_decay'])
        generator=None; selected_radius=0.; val_candidates=[]
        def noise(xx,radius,sphere):
            z=torch.randn(xx.shape,generator=rng)*mask
            if sphere:z=z/torch.linalg.vector_norm(z,dim=1,keepdim=True).clamp_min(1e-8)
            else:z=z/mask.sum().sqrt()
            return z*radius
        def clean_score(m):
            m.eval()
            with torch.no_grad():return float(val_loss.nll(m(xv))+config['gamma_brier']*brier.brier(m(x),m(xv)))
        if name in ('Fixed Gaussian','Fixed sphere'):
            best_score=float('inf')
            for radius in config['fixed_radii']:
                torch.manual_seed(32000+seed);rng.manual_seed(40000+seed)
                m=fresh();m.load_state_dict(warm_state);o=torch.optim.Adam(m.parameters(),lr=lr,weight_decay=config['weight_decay'])
                for _ in range(config['adapt_epochs']):
                    m.train();o.zero_grad();l=train_loss.nll(m(x+noise(x,radius,name=='Fixed sphere')));l.backward();o.step()
                score=clean_score(m);val_candidates.append({'radius':radius,'validation_objective':score})
                if score<best_score:best_score=score;selected_radius=radius
        else:
            mode={'No outcome':'no_outcome','Fixed variance':'fixed_variance','Nonzero mean':'nonzero_mean'}.get(name,'full')
            if name!='Clean':
                with torch.random.fork_rng():
                    torch.manual_seed(33000+seed);generator=Generator(p,mask,config['rho'],mode)
                opt_g=torch.optim.Adam(generator.parameters(),lr=config['generator_lr'],weight_decay=1e-5)
            for _ in range(config['adapt_epochs']):
                model.train();opt.zero_grad()
                if name=='Clean':
                    loss=train_loss.nll(model(x));loss.backward();opt.step();continue
                if name=='Joint generator':
                    opt_g.zero_grad();eps=generator(x,yn,e.float(),rng);rp=model(x+eps)
                    loss=train_loss.nll(rp)+config['lambda_magnitude']*eps.square().sum(1).mean()+config['lambda_mmd']*_mmd(x,x+eps,config['mmd_max_samples'])
                    model.eval()
                    loss=loss+config['lambda_stability']*(model(x+eps)-model(x)).square().mean()
                    loss.backward();torch.nn.utils.clip_grad_norm_(list(model.parameters())+list(generator.parameters()),5.);opt.step();opt_g.step();continue
                opt_g.zero_grad();eps=generator(x,yn,e.float(),rng)
                params=dict(model.named_parameters())
                inner=train_loss.nll(functional_call(model,params,(x+eps,)))
                grad=torch.autograd.grad(inner,tuple(params.values()),create_graph=True)
                upd={k:v-config['virtual_step']*g for (k,v),g in zip(params.items(),grad)}
                model.eval()
                rv=functional_call(model,upd,(xv,));rt=functional_call(model,upd,(x,))
                gamma=0. if name=='Cox-only outer' else config['gamma_brier']
                outer=val_loss.nll(rv)+gamma*brier.brier(rt,rv)
                r0=functional_call(model,params,(x,));rpert=functional_call(model,params,(x+eps,))
                regularizer=config['lambda_magnitude']*eps.square().sum(1).mean()
                if name!='No MMD':regularizer=regularizer+config['lambda_mmd']*_mmd(x,x+eps,config['mmd_max_samples'])
                if name!='No stability':regularizer=regularizer+config['lambda_stability']*(rpert-r0).square().mean()
                (outer+regularizer).backward();torch.nn.utils.clip_grad_norm_(generator.parameters(),5.);opt_g.step()
                opt.zero_grad();model.train()
                with torch.no_grad():eps=generator(x,yn,e.float(),rng)
                ml=train_loss.nll(model(x+eps));ml.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),5.);opt.step()
        # All methods refit the final predictor from IDENTICAL parameters.
        torch.manual_seed(34000+seed);rng.manual_seed(45000+seed)
        final=fresh();o=torch.optim.Adam(final.parameters(),lr=lr,weight_decay=config['weight_decay'])
        xa,ya,ea,yna=dev
        for _ in range(config['refit_epochs']):
            final.train();o.zero_grad()
            if name=='Clean':eps=torch.zeros_like(xa)
            elif generator is not None:
                with torch.no_grad():eps=generator(xa,yna,ea.float(),rng)
            else:eps=noise(xa,selected_radius,name=='Fixed sphere')
            loss=dev_loss.nll(final(xa+eps));loss.backward();torch.nn.utils.clip_grad_norm_(final.parameters(),5.);o.step()
        final.eval()
        with torch.no_grad():
            rd=final(xa).numpy();rtest=final(te[0]).numpy()
        baseline=fit_breslow_baseline(ya.numpy(),ea.numpy(),rd)
        result=evaluate_predictions(te[1].numpy(),te[2].numpy(),rtest,baseline,protocol)
        if not np.isfinite([result['cindex'],result['ibs']]).all():raise ValueError('nonfinite evaluation')
        diagnostic={'selected_radius':selected_radius,'fixed_validation_candidates':val_candidates,'elapsed_seconds':time.perf_counter()-started,'continuous_feature_count':int(mask.sum()),'initialization_seed':30000+seed,'final_training_rng_seed':34000+seed}
        if generator is not None:
            with torch.no_grad():
                sig=generator.scales(x,yn,e.float())*mask
                perm=torch.randperm(len(x),generator=rng)
                ps=generator.scales(x,yn[perm],e.float()[perm])*mask
                diagnostic.update(mean_attenuation=float(sig[:,mask.bool()].mean()),feature_attenuation=sig.mean(0).tolist(),outcome_permutation_scale_change=float((sig-ps).square().mean().sqrt()))
        rows.append({'seed':seed,'method':name,'cindex':result['cindex'],'ibs':result['ibs']})
        artifacts[name]={'diagnostics':diagnostic,'evaluation_diagnostics':result['diagnostics'],'test_risk':rtest.tolist(),'pred_survival':result['pred_survival'],'brier_times':result['brier_times'],'brier_curve':result['brier_curve'],'predictor_state':final.state_dict(),'generator_state':None if generator is None else generator.state_dict()}
    return rows,artifacts,{'feature_names':split.feature_names,'preprocessing':split.preprocessing,'train_indices':split.train.indices.tolist(),'validation_indices':split.validation.indices.tolist(),'test_indices':split.test.indices.tolist(),'time_grid':protocol.grid.tolist(),'tau':float(protocol.tau),'test_time':split.test.time.tolist(),'test_event':split.test.event.tolist()}
