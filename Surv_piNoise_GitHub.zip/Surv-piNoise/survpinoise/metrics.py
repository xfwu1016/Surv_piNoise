"""Training-reference IPCW evaluation for the corrected survival experiments.

The censoring KM, Uno horizon, and IBS grid are fixed before comparing models.
Test outcomes never fit a censoring estimator. Reverse KM resolves mixed ties
with events first; event contributions use G(Y-), survival contributions G(t).
IBS measures probabilistic prediction error, not calibration alone.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import statistics
from typing import Iterable, Mapping

import numpy as np


def _vector(value, name):
    result = np.asarray(value, dtype=float)
    if result.ndim != 1 or not len(result) or not np.isfinite(result).all():
        raise ValueError(f"{name} must be a nonempty finite one-dimensional array")
    return result


def _time_event(time, event):
    time = _vector(time, "time")
    event = np.asarray(event)
    if event.ndim != 1 or event.shape != time.shape:
        raise ValueError("event must have the same one-dimensional shape as time")
    if np.any(time < 0) or not np.isin(event, [0, 1]).all():
        raise ValueError("times must be nonnegative and events must be binary")
    return time, event.astype(bool)


def _risk(risk, n):
    risk = _vector(risk, "risk")
    if risk.shape != (n,):
        raise ValueError("risk and outcomes must have the same length")
    return risk


def _frozen_array(value, dtype=float):
    result = np.array(value, dtype=dtype, copy=True)
    result.setflags(write=False)
    return result


def _step(times, values, query, *, left=False, initial=1.0):
    query = np.asarray(query, dtype=float)
    if not np.isfinite(query).all():
        raise ValueError("query times must be finite")
    index = np.searchsorted(times, query, side="left" if left else "right") - 1
    result = np.where(index >= 0, values[np.maximum(index, 0)], initial)
    return float(result) if query.ndim == 0 else result


@dataclass(frozen=True)
class CensoringKM:
    """Reverse Kaplan-Meier G(t)=P(C>t), fitted to reference training labels."""

    times: np.ndarray
    survival_after: np.ndarray
    at_risk: np.ndarray
    event_counts: np.ndarray
    censor_counts: np.ndarray
    min_g: float
    n_training: int

    def predict(self, time, *, left=False, clip=False):
        query = np.asarray(time, dtype=float)
        if np.any(query < 0) or np.any(query > self.times[-1]):
            raise ValueError("censoring queries must lie in observed training support")
        raw = _step(self.times, self.survival_after, query, left=left)
        return np.maximum(raw, self.min_g) if clip else raw

    survival = predict

    @property
    def positive_support_upper(self):
        zero = np.flatnonzero(self.survival_after <= 0)
        return float(np.nextafter(self.times[zero[0]], -np.inf)) if len(zero) else float(self.times[-1])

    def to_dict(self):
        return {"times": self.times.tolist(), "survival_after": self.survival_after.tolist(),
                "at_risk": self.at_risk.tolist(), "event_counts": self.event_counts.tolist(),
                "censor_counts": self.censor_counts.tolist(), "min_g": self.min_g,
                "n_training": self.n_training, "fit_source": "training_reference",
                "tie_convention": "events removed before censoring hazard at a mixed tie"}


def fit_censoring_km(train_time, train_event, *, min_g=0.05):
    """Estimate censoring survival with event-first reverse-KM mixed ties.

    At a tied time, censor count is divided by (at risk - event count).
    For example, one event and one censor among four at risk give G(t)/G(t-)
    equal to 1-1/3, rather than 1-1/4.
    """
    time, event = _time_event(train_time, train_event)
    if not np.isfinite(min_g) or not 0 < min_g <= 1:
        raise ValueError("min_g must be finite and in (0,1]")
    times, inverse, counts = np.unique(time, return_inverse=True, return_counts=True)
    events = np.bincount(inverse, weights=event.astype(int), minlength=len(times)).astype(int)
    censors = counts - events
    at_risk = len(time) - np.r_[0, np.cumsum(counts[:-1])]
    censor_risk = at_risk - events
    hazard = np.divide(censors, censor_risk, out=np.zeros(len(times), dtype=float), where=censor_risk > 0)
    survival = np.cumprod(1.0 - hazard)
    return CensoringKM(*[_frozen_array(a, int if k in (2, 3, 4) else float)
                         for k, a in enumerate((times, survival, at_risk, events, censors))],
                       min_g=float(min_g), n_training=len(time))


@dataclass(frozen=True)
class BreslowBaseline:
    """Log cumulative baseline hazard; no clipping of predictor risk scores."""

    event_times: np.ndarray
    log_cumulative_hazard: np.ndarray
    n_development: int

    def cumulative_hazard(self, time):
        log_h = _step(self.event_times, self.log_cumulative_hazard, time, initial=-np.inf)
        with np.errstate(over="ignore"):
            return np.exp(log_h)

    def predict_survival(self, risk, grid):
        risk, grid = _vector(risk, "risk"), _vector(grid, "grid")
        if np.any(grid < 0):
            raise ValueError("grid times must be nonnegative")
        log_h0 = _step(self.event_times, self.log_cumulative_hazard, grid, initial=-np.inf)
        log_hazard = risk[:, None] + log_h0[None, :]
        # Clipping only the exponent argument at machine capacity avoids
        # arithmetic overflow; it is not clipping model risks or IPCW weights.
        hazard = np.exp(np.minimum(log_hazard, math.log(np.finfo(float).max)))
        return np.exp(-hazard)

    def to_dict(self):
        return {"event_times": self.event_times.tolist(),
                "log_cumulative_hazard": self.log_cumulative_hazard.tolist(),
                "n_development": self.n_development, "fit_source": "development_training"}


def fit_breslow_baseline(development_time, development_event, development_risk):
    """Fit baseline on development-training outcomes and clean fitted risks.

    All events sharing a time use the same complete risk-set denominator,
    including observations censored at that time. Log-sum-exp remains stable
    when adding an arbitrary constant to all risk scores.
    """
    time, event = _time_event(development_time, development_event)
    risk = _risk(development_risk, len(time))
    if not event.any():
        raise ValueError("a Breslow baseline requires at least one development event")
    order = np.argsort(time, kind="stable")
    sorted_time, sorted_risk = time[order], risk[order]
    unique, first, inverse = np.unique(sorted_time, return_index=True, return_inverse=True)
    events = np.bincount(inverse, weights=event[order].astype(int), minlength=len(unique))
    log_denominator = np.logaddexp.accumulate(sorted_risk[::-1])[::-1][first]
    observed = events > 0
    log_increments = np.log(events[observed]) - log_denominator[observed]
    log_cumulative = np.logaddexp.accumulate(log_increments)
    return BreslowBaseline(_frozen_array(unique[observed]), _frozen_array(log_cumulative), len(time))


@dataclass(frozen=True)
class EvaluationProtocol:
    censoring: CensoringKM
    grid: np.ndarray
    tau: float
    metadata: dict

    def to_dict(self):
        return {"grid": self.grid.tolist(), "tau": self.tau,
                "censoring": self.censoring.to_dict(), **self.metadata}


def make_evaluation_protocol(train_time, train_event, *,
                             ibs_quantiles=(0.1, 0.8), uno_quantile=0.8,
                             n_grid=50, min_g=0.05):
    """Build once per split, before evaluating any model.

    G, requested horizons and grid quantiles use INNER-TRAINING labels only.
    No test follow-up, event indicator, prediction, or metric can change this
    protocol. The grid/tau must be shared across all methods on the split.
    Only positive-G support in inner training may shorten an endpoint.
    """
    time, event = _time_event(train_time, train_event)
    if not event.any():
        raise ValueError("evaluation horizons require observed training events")
    if len(ibs_quantiles) != 2 or not 0 <= ibs_quantiles[0] < ibs_quantiles[1] <= 1:
        raise ValueError("IBS quantiles must satisfy 0<=low<high<=1")
    if not np.isfinite(uno_quantile) or not 0 < uno_quantile <= 1:
        raise ValueError("uno_quantile must lie in (0,1]")
    if type(n_grid) is not int or n_grid < 2:
        raise ValueError("n_grid must be an integer >=2")
    censoring = fit_censoring_km(time, event, min_g=min_g)
    requested_low, requested_high = np.quantile(time[event], ibs_quantiles)
    requested_tau = float(np.quantile(time[event], uno_quantile))
    lower, upper = float(requested_low), censoring.positive_support_upper
    high = min(float(requested_high), upper)
    tau = min(requested_tau, upper)
    if not np.isfinite(lower) or not np.isfinite(high) or high <= lower or tau <= 0:
        raise ValueError("no nondegenerate common evaluation interval with positive training G")
    grid = np.linspace(lower, high, n_grid)
    raw_g = np.asarray(censoring.predict(grid))
    if np.any(raw_g <= 0):
        raise ValueError("training censoring survival must be positive on the evaluation grid")
    metadata = {"ibs_quantiles": list(map(float, ibs_quantiles)), "uno_quantile": float(uno_quantile),
                "requested_grid_bounds": [float(requested_low), float(requested_high)],
                "effective_grid_bounds": [lower, high], "requested_tau": requested_tau,
                "support_upper": upper, "support_adjusted": bool(lower != requested_low or high != requested_high or tau != requested_tau),
                "test_followup_used_for_support": False,
                "protocol_fit_source": "inner_training_only",
                "grid_raw_g_min": float(raw_g.min()), "grid_effective_g_min": float(np.maximum(raw_g, min_g).min()),
                "grid_g_clipped_count": int(np.sum(raw_g < min_g)),
                "g_estimator": "training-reference reverse Kaplan-Meier; event-first mixed ties",
                "ibs_interpretation": "probabilistic prediction error, not calibration alone"}
    return EvaluationProtocol(censoring, _frozen_array(grid), float(tau), metadata)


def uno_cindex(test_time, test_event, test_risk, censoring, tau, *, tied_tol=1e-8,
               max_pairs_per_chunk=1_000_000, return_diagnostics=False):
    """Training-G Uno concordance, truncated to event anchors Y_i<=tau.

    Higher risk denotes earlier failure. Event/event time ties are excluded;
    an event at the time another subject is censored is comparable (events
    first). Risk-score ties receive half credit. Work is vectorized in bounded
    chunks, avoiding an n-by-n allocation for large cohorts.
    """
    time, event = _time_event(test_time, test_event)
    risk = _risk(test_risk, len(time))
    if not np.isfinite(tau) or not 0 < tau <= censoring.positive_support_upper:
        raise ValueError("tau must be positive and within positive training censoring support")
    if not np.isfinite(tied_tol) or tied_tol < 0:
        raise ValueError("tied_tol must be finite and nonnegative")
    if type(max_pairs_per_chunk) is not int or max_pairs_per_chunk < 1:
        raise ValueError("max_pairs_per_chunk must be a positive integer")
    anchors = np.flatnonzero(event & (time <= tau))
    if not len(anchors):
        raise ValueError("no observed test event at or before tau")
    raw_g = np.asarray(censoring.predict(time[anchors], left=True))
    if np.any(raw_g <= 0):
        raise ValueError("event anchor has zero training censoring survival")
    effective_g = np.maximum(raw_g, censoring.min_g)
    weights = 1.0 / effective_g**2
    chunk_rows = max(1, max_pairs_per_chunk // len(time))
    numerator = denominator = 0.0
    pairs = concordant = discordant = risk_ties = event_censor_time_ties = 0
    for begin in range(0, len(anchors), chunk_rows):
        idx = anchors[begin:begin+chunk_rows]
        same_censored_time = (time[idx, None] == time[None, :]) & ~event[None, :]
        comparable = (time[idx, None] < time[None, :]) | same_censored_time
        difference = risk[idx, None] - risk[None, :]
        tied = np.abs(difference) <= tied_tol
        good = difference > tied_tol
        bad = difference < -tied_tol
        pair_count = comparable.sum(axis=1)
        credit = ((good & comparable).sum(axis=1) + 0.5*(tied & comparable).sum(axis=1))
        weight = weights[begin:begin+len(idx)]
        numerator += float(np.dot(weight, credit))
        denominator += float(np.dot(weight, pair_count))
        pairs += int(pair_count.sum())
        concordant += int((good & comparable).sum())
        discordant += int((bad & comparable).sum())
        risk_ties += int((tied & comparable).sum())
        event_censor_time_ties += int(same_censored_time.sum())
    if denominator <= 0:
        raise ValueError("no comparable test pairs at the fixed horizon")
    value = numerator / denominator
    diagnostics = {"tau": float(tau), "event_anchors": len(anchors), "comparable_pairs": pairs,
                   "concordant_pairs": concordant, "discordant_pairs": discordant, "risk_tied_pairs": risk_ties,
                   "event_censor_same_time_pairs": event_censor_time_ties,
                   "weighted_pair_denominator": denominator, "raw_g_min": float(raw_g.min()),
                   "effective_g_min": float(effective_g.min()), "g_clipped_event_count": int(np.sum(raw_g < censoring.min_g)),
                   "censoring_fit_source": "training_reference"}
    return (value, diagnostics) if return_diagnostics else value


def ipcw_brier_score(test_time, test_event, survival_probabilities, grid, censoring,
                     *, return_diagnostics=False):
    """Vectorized IPCW Brier curve using fixed training G.

    Contributions are I(Y<=t,event)*S(t)^2/G(Y-) and
    I(Y>t)*(1-S(t))^2/G(t). Censoring at/before t contributes zero.
    The normalization is n, not the sum of IPCW weights. Finite-sample IPCW
    scores can exceed one; no artificial [0,1] clipping is performed.
    """
    time, event = _time_event(test_time, test_event)
    grid = _vector(grid, "grid")
    if np.any(grid < 0) or np.any(np.diff(grid) <= 0):
        raise ValueError("grid must be nonnegative and strictly increasing")
    probability = np.asarray(survival_probabilities, dtype=float)
    if probability.shape != (len(time), len(grid)) or not np.isfinite(probability).all() or np.any((probability < 0) | (probability > 1)):
        raise ValueError("survival probabilities must be finite in [0,1] with shape (n_test,n_times)")
    raw_grid_g = np.asarray(censoring.predict(grid))
    if np.any(raw_grid_g <= 0):
        raise ValueError("evaluation grid includes zero training censoring survival")
    effective_grid_g = np.maximum(raw_grid_g, censoring.min_g)
    relevant = event & (time <= grid[-1])
    event_weight = np.zeros(len(time))
    raw_event_g = np.asarray(censoring.predict(time[relevant], left=True))
    if np.any(raw_event_g <= 0):
        raise ValueError("observed event has zero training censoring survival")
    event_weight[relevant] = 1.0 / np.maximum(raw_event_g, censoring.min_g)
    failed = event[:, None] & (time[:, None] <= grid[None, :])
    surviving = time[:, None] > grid[None, :]
    terms = failed * probability**2 * event_weight[:, None]
    terms += surviving * (1.0-probability)**2 / effective_grid_g[None, :]
    curve = terms.mean(axis=0)
    diagnostics = {"n_test": len(time), "grid_raw_g_min": float(raw_grid_g.min()),
                   "grid_effective_g_min": float(effective_grid_g.min()),
                   "grid_g_clipped_count": int(np.sum(raw_grid_g < censoring.min_g)),
                   "event_raw_g_min": float(raw_event_g.min()) if len(raw_event_g) else None,
                   "event_g_clipped_count": int(np.sum(raw_event_g < censoring.min_g)),
                   "failure_contributions_by_time": failed.sum(axis=0).tolist(),
                   "survival_contributions_by_time": surviving.sum(axis=0).tolist(),
                   "censored_before_or_at_time": ((~event[:, None]) & (time[:, None] <= grid[None, :])).sum(axis=0).tolist(),
                   "censoring_fit_source": "training_reference"}
    return (curve, diagnostics) if return_diagnostics else curve


def integrated_brier_score(test_time, test_event, survival_probabilities, grid, censoring,
                            *, return_diagnostics=False):
    grid = _vector(grid, "grid")
    if len(grid) < 2:
        raise ValueError("IBS requires at least two grid times")
    curve, diagnostics = ipcw_brier_score(test_time, test_event, survival_probabilities, grid,
                                          censoring, return_diagnostics=True)
    value = float(np.sum(0.5*(curve[1:]+curve[:-1])*np.diff(grid)) / (grid[-1]-grid[0]))
    diagnostics.update(grid=grid.tolist(), brier_curve=curve.tolist(),
                       interpretation="integrated probabilistic prediction error; not calibration alone")
    return (value, diagnostics) if return_diagnostics else value


def evaluate_predictions(test_time, test_event, test_risk, baseline, protocol):
    """Evaluate one predictor with an already fixed, model-independent protocol."""
    survival = baseline.predict_survival(test_risk, protocol.grid)
    concordance, c_diagnostics = uno_cindex(test_time, test_event, test_risk, protocol.censoring,
                                          protocol.tau, return_diagnostics=True)
    ibs, b_diagnostics = integrated_brier_score(test_time, test_event, survival, protocol.grid,
                                               protocol.censoring, return_diagnostics=True)
    return {"cindex": concordance, "ibs": ibs,
            "brier_times": protocol.grid.tolist(), "brier_curve": b_diagnostics["brier_curve"],
            "pred_survival": survival.tolist(),
            "diagnostics": {"protocol": protocol.to_dict(), "uno": c_diagnostics, "ibs": b_diagnostics,
                            "baseline_n_development": baseline.n_development}}


# t_(.975, df), df=1..30. Exact plan uses ten or twenty paired seeds.
T_975 = (None, 12.706204736432095, 4.302652729696142, 3.182446305284263,
         2.7764451051977987, 2.570581835636314, 2.4469118487916806,
         2.3646242515927844, 2.306004135204166, 2.2621571628540993,
         2.2281388519649385, 2.200985160082949, 2.1788128296634177,
         2.1603686564610127, 2.1447866879169273, 2.131449545559323,
         2.1199052992210112, 2.1098155778331806, 2.10092204024096,
         2.093024054408263, 2.0859634472658364, 2.079613844727662,
         2.0738730679040147, 2.0686576104190406, 2.0638985616280205,
         2.059538552753294, 2.055529438642871, 2.0518305164802833,
         2.048407141795244, 2.045229642132703, 2.0422724563012373)


def _t_critical(n):
    if n <= 31:
        return T_975[n-1]
    try:
        from scipy.stats import t
    except ImportError as exc:
        raise ValueError("more than 31 pairs require scipy for the exact t critical value") from exc
    return float(t.ppf(0.975, n-1))


def paired_summary(rows: Iterable[Mapping], *, baseline="Clean", pair_key=None):
    """Summarize paired cindex/IBS rows for ONE dataset/scenario/backbone.

    Each seed must contain exactly one row per method. Pair differences, not
    independent method SDs, determine CIs. One pair has undefined SD/CI (None).
    Caller must group different experimental conditions before calling.
    """
    rows = list(rows)
    if not rows:
        raise ValueError("no result rows")
    if pair_key is None:
        pair_key = "seed" if "seed" in rows[0] else "split"
    grouped, method_order = {}, []
    for row in rows:
        seed = row[pair_key]
        if not isinstance(seed, (int, np.integer)) or isinstance(seed, (bool, np.bool_)) or seed < 0:
            raise ValueError("paired seed identifiers must be nonnegative integers")
        method = row["method"]
        if not isinstance(method, str) or not method:
            raise ValueError("method names must be nonempty strings")
        if method not in method_order:
            method_order.append(method)
        cell = grouped.setdefault(int(seed), {})
        if method in cell:
            raise ValueError("duplicate method within paired seed")
        values = {key: float(row[key]) for key in ("cindex", "ibs")}
        if not all(math.isfinite(value) for value in values.values()) or not 0 <= values["cindex"] <= 1 or values["ibs"] < 0:
            raise ValueError("C-index must be finite in [0,1] and IBS finite and nonnegative")
        cell[method] = values
    if baseline not in method_order:
        raise ValueError("baseline method is absent")
    required = set(method_order)
    if any(set(cell) != required for cell in grouped.values()):
        raise ValueError("every seed must contain the same complete set of methods")
    seeds, n = sorted(grouped), len(grouped)
    methods = [baseline] + [method for method in method_order if method != baseline]
    summary, paired = [], []
    critical = _t_critical(n) if n >= 2 else None
    for method in methods:
        entry = {"method": method}
        for metric in ("cindex", "ibs"):
            values = [grouped[seed][method][metric] for seed in seeds]
            entry[metric+"_mean"] = statistics.mean(values)
            entry[metric+"_sd"] = statistics.stdev(values) if n >= 2 else None
            if method != baseline:
                direction = 1 if metric == "cindex" else -1
                differences = [direction*(grouped[seed][method][metric]-grouped[seed][baseline][metric]) for seed in seeds]
                difference = statistics.mean(differences)
                sd = statistics.stdev(differences) if n >= 2 else None
                halfwidth = critical*sd/math.sqrt(n) if n >= 2 else None
                paired.append({"method": method, "metric": "C-index gain" if metric == "cindex" else "IBS reduction",
                               "mean_difference": difference, "difference_sd": sd,
                               "ci_low": difference-halfwidth if n >= 2 else None,
                               "ci_high": difference+halfwidth if n >= 2 else None})
        summary.append(entry)
    return {"n_paired_seeds": n, "seeds": seeds, "baseline": baseline, "summary": summary, "paired_ci": paired,
            "sd_definition": "sample SD across seeds (ddof=1); None for one seed",
            "ci_definition": "two-sided paired Student t 95% CI across seeds, relative to baseline",
            "ci_status": "computed" if n >= 2 else "not_computable_n_lt_2",
            "positive_direction": {"C-index gain": "method - baseline", "IBS reduction": "baseline - method"}}
