"""Full-risk-set Breslow loss and differentiable IPCW Brier outer loss.

Cox plans cache only O(n) sorting/grouping indices. No dense risk-set matrix
is built. Brier plans fix censoring KM, event-time grid, and weights from the
designated inner-training data; their baseline hazard is recomputed from the
passed train_risk on every call, including virtual-parameter evaluations.

The Brier outer loss is an arithmetic mean over grid points. ``ibs`` instead
uses a normalized trapezoidal integral over that same, fixed training grid.
Neither operation changes the grid or censoring estimates using test data.
"""

from __future__ import annotations

import torch
from torch import Tensor


def _data(time: Tensor, event: Tensor) -> tuple[Tensor, Tensor]:
    time = torch.as_tensor(time).detach().reshape(-1).clone()
    if not torch.is_floating_point(time):
        time = time.to(torch.get_default_dtype())
    event = torch.as_tensor(event, device=time.device).detach().reshape(-1).clone()
    if time.numel() == 0 or event.numel() != time.numel():
        raise ValueError("time and event must be nonempty and have equal lengths")
    if not bool(torch.isfinite(time).all()) or bool((time < 0).any()):
        raise ValueError("observed times must be finite and nonnegative")
    if not bool(((event == 0) | (event == 1)).all()):
        raise ValueError("event indicators must be 0 or 1")
    return time, event.to(dtype=time.dtype)


def _risk(risk: Tensor, n: int, device: torch.device) -> Tensor:
    if not isinstance(risk, Tensor) or not torch.is_floating_point(risk):
        raise TypeError("risk must be a floating-point torch Tensor")
    risk = risk.reshape(-1)
    if risk.numel() != n:
        raise ValueError(f"expected {n} risk scores, got {risk.numel()}")
    if risk.device != device:
        raise ValueError("risk scores and cached survival data must be on the same device")
    return risk


class CoxBreslowPlan:
    """Cache full risk sets as sorted prefix endpoints, with correct ties.

    At a tied event time every event shares the denominator at the END of
    that time's group, including censored observations tied at that time.
    nll is normalized by the number of events. With zero events it returns
    a differentiable zero rather than dividing by zero.
    """

    def __init__(self, time: Tensor, event: Tensor):
        self.time, self.event = _data(time, event)
        self.n = self.time.numel()
        self.order = torch.argsort(self.time, descending=True, stable=True)
        sorted_time = self.time[self.order]
        unique_desc, group_index, counts = torch.unique_consecutive(
            sorted_time, return_inverse=True, return_counts=True)
        group_ends = torch.cumsum(counts, dim=0) - 1
        event_counts = torch.zeros(unique_desc.numel(), dtype=self.time.dtype,
                                   device=self.time.device)
        event_counts.scatter_add_(0, group_index, self.event[self.order])
        event_group = event_counts > 0
        self.event_group_ends = group_ends[event_group]
        self.event_counts_desc = event_counts[event_group]
        self.event_times = unique_desc[event_group].flip(0)  # ascending
        self.event_mask = self.event.bool()
        self.n_events = int(self.event.sum().item())

    def _centered_log_denominators(self, risk: Tensor) -> tuple[Tensor, Tensor, Tensor]:
        center = risk.max()
        centered = risk - center
        prefix = torch.logcumsumexp(centered[self.order], dim=0)
        return prefix[self.event_group_ends], center, centered

    def nll(self, risk: Tensor) -> Tensor:
        risk = _risk(risk, self.n, self.time.device)
        if self.n_events == 0:
            return risk.sum() * 0.0
        log_den, _, centered = self._centered_log_denominators(risk)
        event_counts = self.event_counts_desc.to(dtype=risk.dtype)
        return ((event_counts * log_den).sum() - centered[self.event_mask].sum()) / self.n_events

    def log_cumulative_baseline(self, risk: Tensor) -> tuple[Tensor, Tensor]:
        """Return ascending log H0 and the numerical score-centering constant.

        H0 is in the centered-score coordinate system. To obtain a person's
        cumulative hazard combine log H0 with eval_risk - center. This keeps
        even large shifted scores stable without detaching baseline gradients.
        """
        risk = _risk(risk, self.n, self.time.device)
        if self.n_events == 0:
            return risk.new_empty((0,)), risk.max()
        log_den, center, _ = self._centered_log_denominators(risk)
        log_increments_desc = self.event_counts_desc.to(dtype=risk.dtype).log() - log_den
        return torch.logcumsumexp(log_increments_desc.flip(0), dim=0), center


def cox_breslow_nll(risk: Tensor, time: Tensor, event: Tensor) -> Tensor:
    """Convenience entry point; reuse a CoxBreslowPlan in repeated training."""
    return CoxBreslowPlan(time, event).nll(risk)


class IPCWPlan:
    """Fixed training-only IPCW design with a differentiable Breslow baseline.

    The default grid spans the 10th to 80th percentiles of observed TRAINING
    event times, with 50 points. If there are no training events, training
    observed times supply the fallback grid and survival remains one. A
    degenerate grid is valid for Brier mean but not an integrated Brier score.

    Evaluation outcomes construct IPCW targets only: they never choose grid,
    censoring KM, or tau. G(t) uses training censoring KM, with left limits for
    failures. At mixed event/censoring ties, events leave the risk set before
    the censoring KM hazard is calculated (event-first reverse KM). min_g
    bounds inverse weights; clipped-weight counts are exposed.
    Predictions are computed from current/virtual train and evaluation risks.
    """

    def __init__(self, train_time: Tensor, train_event: Tensor,
                 eval_time: Tensor, eval_event: Tensor, grid: Tensor | None = None,
                 n_grid: int = 50, lower_quantile: float = 0.1,
                 upper_quantile: float = 0.8, min_g: float = 0.05):
        if not 0 < min_g <= 1:
            raise ValueError("min_g must be in (0, 1]")
        if not 0 <= lower_quantile < upper_quantile <= 1:
            raise ValueError("require 0 <= lower_quantile < upper_quantile <= 1")
        if not isinstance(n_grid, int) or n_grid < 1:
            raise ValueError("n_grid must be a positive integer")
        self.train_plan = CoxBreslowPlan(train_time, train_event)
        self.eval_time, self.eval_event = _data(eval_time, eval_event)
        if self.eval_time.device != self.train_plan.time.device:
            raise ValueError("training and evaluation data must be on the same device")
        self.min_g = float(min_g)
        self.n_eval = self.eval_time.numel()
        train_time = self.train_plan.time
        train_event = self.train_plan.event
        if grid is None:
            source = train_time[train_event.bool()]
            if source.numel() == 0:
                source = train_time
            quantiles = source.new_tensor([lower_quantile, upper_quantile])
            low, high = torch.quantile(source, quantiles).unbind()
            self.grid = torch.linspace(low, high, n_grid, dtype=train_time.dtype,
                                       device=train_time.device)
        else:
            self.grid = torch.as_tensor(grid, dtype=train_time.dtype,
                                        device=train_time.device).detach().reshape(-1).clone()
        if self.grid.numel() == 0 or not bool(torch.isfinite(self.grid).all()):
            raise ValueError("grid must contain finite time points")
        if bool((self.grid < 0).any()) or bool((self.grid[1:] < self.grid[:-1]).any()):
            raise ValueError("grid must be nonnegative and sorted in ascending order")
        self.tau = self.grid[-1]

        # Censoring KM from training data only, grouping simultaneous records.
        order = torch.argsort(train_time, stable=True)
        self.censor_times, inverse, counts = torch.unique_consecutive(
            train_time[order], return_inverse=True, return_counts=True)
        censor_counts = torch.zeros(self.censor_times.numel(), dtype=train_time.dtype,
                                    device=train_time.device)
        censor_counts.scatter_add_(0, inverse, 1.0 - train_event[order])
        at_risk = train_time.numel() - (torch.cumsum(counts, dim=0) - counts)
        event_counts = counts.to(dtype=train_time.dtype) - censor_counts
        censor_risk = at_risk.to(dtype=train_time.dtype) - event_counts
        factors = 1.0 - censor_counts / censor_risk.clamp_min(1.0)
        self.censor_survival = torch.cumprod(factors.clamp_min(0.0), dim=0)

        g_grid_raw = self._censoring_raw(self.grid, left=False)
        g_event_raw = self._censoring_raw(self.eval_time, left=True)
        self.clipped_grid_weights = int((g_grid_raw < min_g).sum().item())
        self.clipped_event_weights = int((g_event_raw < min_g).sum().item())
        g_grid = g_grid_raw.clamp_min(min_g)
        g_event = g_event_raw.clamp_min(min_g)
        alive = self.eval_time[:, None] > self.grid[None, :]
        failed = self.eval_event.bool()[:, None] & (self.eval_time[:, None] <= self.grid[None, :])
        self.target = alive.to(dtype=train_time.dtype)
        self.weights = (alive.to(dtype=train_time.dtype) / g_grid[None, :]
                        + failed.to(dtype=train_time.dtype) / g_event[:, None])
        self.baseline_grid_indices = torch.searchsorted(
            self.train_plan.event_times.contiguous(), self.grid.contiguous(), right=True) - 1

    def _censoring_raw(self, query: Tensor, left: bool = False) -> Tensor:
        query = torch.as_tensor(query, dtype=self.censor_times.dtype,
                                device=self.censor_times.device)
        index = torch.searchsorted(self.censor_times.contiguous(), query.contiguous(), right=not left) - 1
        values = self.censor_survival[index.clamp_min(0)]
        return torch.where(index >= 0, values, torch.ones_like(values))

    def censoring_survival(self, query: Tensor, left: bool = False) -> Tensor:
        """Training censoring KM at queries, lower-clipped at min_g."""
        return self._censoring_raw(query, left=left).clamp_min(self.min_g)

    def survival(self, train_risk: Tensor, eval_risk: Tensor) -> Tensor:
        """N_eval by N_grid survival probabilities with baseline autograd intact."""
        train_risk = _risk(train_risk, self.train_plan.n, self.train_plan.time.device)
        eval_risk = _risk(eval_risk, self.n_eval, self.eval_time.device)
        if self.train_plan.n_events == 0:
            zero = train_risk.sum() * 0.0 + eval_risk.sum() * 0.0
            return eval_risk.new_ones((self.n_eval, self.grid.numel())) + zero
        log_h0, center = self.train_plan.log_cumulative_baseline(train_risk)
        valid = self.baseline_grid_indices >= 0
        log_h_grid = log_h0[self.baseline_grid_indices.clamp_min(0)]
        log_hazard = log_h_grid[None, :] + eval_risk[:, None] - center
        # Saturated probabilities should remain finite through second backward.
        survival = torch.exp(-torch.exp(log_hazard.clamp(min=-80.0, max=60.0)))
        return torch.where(valid[None, :], survival, torch.ones_like(survival))

    def brier_by_time(self, train_risk: Tensor, eval_risk: Tensor) -> Tensor:
        survival = self.survival(train_risk, eval_risk)
        return (((survival - self.target.to(survival)) ** 2)
                * self.weights.to(survival)).mean(dim=0)

    def brier(self, train_risk: Tensor, eval_risk: Tensor) -> Tensor:
        return self.brier_by_time(train_risk, eval_risk).mean()

    def ibs(self, train_risk: Tensor, eval_risk: Tensor) -> Tensor:
        if self.grid.numel() < 2 or not bool(self.grid[-1] > self.grid[0]):
            raise ValueError("IBS requires a grid with a positive time span")
        scores = self.brier_by_time(train_risk, eval_risk)
        grid = self.grid.to(scores)
        return torch.trapezoid(scores, grid) / (grid[-1] - grid[0])
