"""Pre-calibrate independent exponential censoring on separate synthetic pilots.

Main experimental cohorts never choose their own censoring scale. A fixed
pilot supplies a scale satisfying E_T[1-exp(-T/scale)] = target, after which
independent exponential censoring is sampled in each experimental cohort.
Realized censoring proportions will fluctuate around the requested target.
"""

from __future__ import annotations

from functools import lru_cache
import json
import math
from pathlib import Path

import numpy as np


MASTER_SEED = 20261027
PILOT_SIZE = 20000
LAW_VERSION = "2026-10-27-piecewise-S3"
MECHANISM_IDS = {"S1": 1, "S2": 2, "S3": 3, "S4": 4, "reliability": 5}
TARGETS = {"S1": (.2, .4, .6), "S2": (.2, .4, .6),
           "S3": (.2, .4, .6), "S4": (.2, .4, .6), "reliability": (.38,)}
DEFAULT_CONFIG = Path(__file__).resolve().parents[1] / "configs" / "censoring_scales.json"


def _key(key):
    aliases = {"reliability_nominal": "reliability", "reliability_shift": "reliability"}
    key = aliases.get(key, key)
    if key not in MECHANISM_IDS:
        raise ValueError(f"unknown failure mechanism {key!r}")
    return key


def _positive_times(failure_times):
    times = np.asarray(failure_times, dtype=float)
    if times.ndim != 1 or len(times) == 0 or not np.isfinite(times).all() or np.any(times <= 0):
        raise ValueError("failure_times must be a nonempty finite positive vector")
    return times


def expected_censoring(failure_times, scale):
    """Pilot expectation of P(C<T | T) for C~Exponential(scale)."""
    times = _positive_times(failure_times)
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError("censoring scale must be finite and positive")
    return float(np.mean(-np.expm1(-times/scale)))


def calibrate_scale(failure_times, target, *, tolerance=1e-10, max_iter=120):
    """Bisection on the independent-pilot expectation, not a cohort draw.

    The censoring probability is strictly decreasing in scale. Returns only
    the scale; ``expected_censoring`` can audit its achieved pilot expectation.
    """
    times = _positive_times(failure_times)
    if not math.isfinite(target) or not 0 < target < 1:
        raise ValueError("target must lie strictly between 0 and 1")
    if not math.isfinite(tolerance) or tolerance <= 0 or type(max_iter) is not int or max_iter < 1:
        raise ValueError("tolerance and max_iter must be positive")
    low, high = 0.0, float(times.max())
    while expected_censoring(times, high) > target:
        high *= 2.0
        if not math.isfinite(high):
            raise ValueError("could not bracket a finite censoring scale")
    for _ in range(max_iter):
        middle = low + (high-low)/2.0
        rate = expected_censoring(times, middle)
        if abs(rate-target) <= tolerance:
            return float(middle)
        if rate > target:
            low = middle
        else:
            high = middle
    raise RuntimeError("censoring-scale bisection failed to reach the requested tolerance")


def sample_pilot_failure_times(key, *, n_pilot=PILOT_SIZE, master_seed=MASTER_SEED):
    """Copy the frozen failure law, using a separate registered pilot stream.

    This function is independent of simulation.make_simulation and receives
    no main-cohort records or seeds. The stream is SeedSequence([master_seed,
    mechanism_id]). Reliability includes the documented clipping to [15,500].
    """
    key = _key(key)
    if type(n_pilot) is not int or n_pilot < 1:
        raise ValueError("n_pilot must be a positive integer")
    if type(master_seed) is not int or master_seed < 0:
        raise ValueError("master_seed must be a nonnegative integer")
    rng = np.random.default_rng(np.random.SeedSequence([master_seed, MECHANISM_IDS[key]]))
    if key == "reliability":
        ops = rng.uniform(-1, 1, size=(n_pilot, 3))
        sensors = rng.normal(size=(n_pilot, 42))
        for start in range(0, 42, 7):
            common = rng.normal(size=(n_pilot, 1))
            sensors[:, start:start+7] = (np.sqrt(.72)*common
                                        + np.sqrt(1-.72)*sensors[:, start:start+7])
        sensors += rng.normal(size=sensors.shape)*np.linspace(.05, .45, 42)
        score = (.70*sensors[:, 0]-.58*sensors[:, 1]+.42*sensors[:, 7]
                 +.38*sensors[:, 8]*ops[:, 0]+.32*np.maximum(sensors[:, 14], 0)**2
                 -.30*sensors[:, 15]+.22*ops[:, 1]-.18*ops[:, 2])
        w = -np.log(rng.uniform(1e-12, 1, size=n_pilot))
        return np.clip(180*(w/np.exp(score))**.5, 15, 500)
    p = 200 if key == "S4" else 20
    x = rng.normal(size=(n_pilot, p))
    innovation = np.sqrt(1-.35**2)
    for j in range(1, p):
        x[:, j] = .35*x[:, j-1]+innovation*x[:, j]
    w = -np.log(rng.uniform(1e-12, 1, size=n_pilot))
    if key == "S1":
        score = .7*x[:, 0]-.6*x[:, 1]+.5*x[:, 2]-.4*x[:, 3]
    elif key == "S2":
        score = .8*x[:, 0]**2+np.sin(np.pi*x[:, 1])+.6*x[:, 2]*x[:, 3]-.5*np.abs(x[:, 4])
    elif key == "S4":
        score = x[:, [0, 3, 8, 14, 29]]@np.array([.8, -.7, .6, -.5, .4])
    else:
        a = .8*x[:, 0]-.6*x[:, 1]
        first = np.exp(a)
        before = w <= first
        failure = np.empty(n_pilot, dtype=float)
        failure[before] = 20*(w[before]/first[before])**(1/1.3)
        failure[~before] = 20*(1+(w[~before]-first[~before])/np.exp(a[~before]+.5*x[~before, 2]))**(1/1.3)
        return failure
    return 20*(w/np.exp(score))**(1/1.3)


def prepare_config(*, n_pilot=PILOT_SIZE, master_seed=MASTER_SEED, tolerance=1e-10):
    """Build all 13 fixed scales using only independent synthetic pilot draws."""
    scales, details = {}, {}
    for key, targets in TARGETS.items():
        failure = sample_pilot_failure_times(key, n_pilot=n_pilot, master_seed=master_seed)
        scales[key], checks = {}, {}
        for target in targets:
            scale = calibrate_scale(failure, target, tolerance=tolerance)
            target_key = format(target, ".12g")
            rate = expected_censoring(failure, scale)
            scales[key][target_key] = scale
            checks[target_key] = {"expected_pilot_censoring": rate, "absolute_error": abs(rate-target)}
        details[key] = {
            "seed_sequence_entropy": [master_seed, MECHANISM_IDS[key]],
            "n_pilot": n_pilot,
            "failure_time_min": float(failure.min()), "failure_time_max": float(failure.max()),
            "failure_time_mean": float(failure.mean()), "target_checks": checks,
        }
    return {
        "schema_version": 1,
        "law_version": LAW_VERSION,
        "calibration": {
            "master_seed": master_seed, "n_pilot_per_mechanism": n_pilot,
            "method": "bisection of pilot mean[-expm1(-T/scale)] = target",
            "absolute_tolerance": tolerance, "main_cohort_used": False,
            "test_outcomes_used": False,
            "independence": "After fixing these scales, main-cohort C is exponential and independent of T and X.",
            "realized_rate": "Random per-cohort proportions are not forced to equal the requested population target.",
        },
        "mechanisms": {
            "S1": "AR1 Gaussian p20, Weibull PH shape1.3 scale20; linear .7,-.6,.5,-.4",
            "S2": "AR1 Gaussian p20, Weibull PH; .8*x1^2+sin(pi*x2)+.6*x3*x4-.5*abs(x5)",
            "S3": "AR1 Gaussian p20; a=.8*x1-.6*x2 before20, a+.5*x3 afterwards; piecewise cumulative hazard",
            "S4": "AR1 Gaussian p200, Weibull PH; x1,x4,x9,x15,x30 coefficients .8,-.7,.6,-.5,.4",
            "reliability": "Three operating covariates,42 block-correlated noisy sensors; Weibull shape2 scale180; failure times clipped15,500",
        },
        "scales": scales,
        "pilot_details": details,
    }


def write_config(path=DEFAULT_CONFIG, **kwargs):
    config = prepare_config(**kwargs)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(config, handle, indent=2, allow_nan=False)
        handle.write("\n")
    _load_config.cache_clear()
    return config


@lru_cache(maxsize=8)
def _load_config(path):
    with Path(path).open("r", encoding="utf-8") as handle:
        config = json.load(handle)
    if config.get("schema_version") != 1 or config.get("law_version") != LAW_VERSION:
        raise ValueError("censoring config schema/law version does not match the current failure law")
    if config.get("calibration", {}).get("main_cohort_used") is not False:
        raise ValueError("censoring config must explicitly exclude main-cohort calibration")
    return config


def get_scale(key, target, path=None):
    """Look up a frozen independent-pilot scale; never fit or interpolate.

    Missing files/keys raise, so a main cohort cannot silently calibrate its
    own scale. reliability_nominal/shift use the common reliability T law.
    """
    key = _key(key)
    if not math.isfinite(target) or not 0 < target < 1:
        raise ValueError("target must lie strictly between 0 and 1")
    config_path = Path(DEFAULT_CONFIG if path is None else path).resolve()
    config = _load_config(str(config_path))
    target_key = format(target, ".12g")
    try:
        scale = float(config["scales"][key][target_key])
    except (KeyError, TypeError, ValueError) as exc:
        raise ValueError(f"no pre-calibrated scale for {key}, censoring target {target_key}") from exc
    if not math.isfinite(scale) or scale <= 0:
        raise ValueError("pre-calibrated censoring scale must be finite and positive")
    return scale
