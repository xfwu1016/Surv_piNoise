"""Specified synthetic cohorts for a NEW, recorded numerical experiment."""
import numpy as np
import pandas as pd
from .data import SurvivalDataset, split_dataset


def _censor(rng, failure, target, key):
    from .censoring_design import get_scale
    # This scale was calibrated on an independent fixed pilot population.
    # Main-cohort failure times cannot change the censoring parameter.
    censor=rng.exponential(get_scale(key,target),size=len(failure))
    return np.minimum(failure,censor),(failure<=censor).astype(np.uint8)


def make_simulation(scenario,seed,target_censor=.4,smoke=False):
    rng=np.random.default_rng(10000+seed)
    n,p=(1200,200) if scenario=='S4' else (2000,20)
    if smoke:n=160
    # AR(1) recursion avoids platform-dependent covariance eigenvector signs.
    x=rng.normal(size=(n,p)); innovation=np.sqrt(1-.35**2)
    for j in range(1,p):x[:,j]=.35*x[:,j-1]+innovation*x[:,j]
    w=-np.log(rng.uniform(1e-12,1,size=n))
    if scenario=='S1':
        f=.7*x[:,0]-.6*x[:,1]+.5*x[:,2]-.4*x[:,3]
    elif scenario=='S2':
        f=.8*x[:,0]**2+np.sin(np.pi*x[:,1])+.6*x[:,2]*x[:,3]-.5*np.abs(x[:,4])
    elif scenario=='S3':
        a=.8*x[:,0]-.6*x[:,1]
        first=np.exp(a)
        latent=np.where(w<=first,20*(w/first)**(1/1.3),20*(1+(w-first)/np.exp(a+.5*x[:,2])) .clip(min=1e-12)**(1/1.3))
        y,e=_censor(rng,latent,target_censor,scenario)
        return SurvivalDataset(scenario,pd.DataFrame(x,columns=[f'x{j+1}'for j in range(p)]),y,e,[],{'synthetic':True,'scenario':'piecewise time-varying effect: f=a before t=20, a+0.5*x3 after t=20','target_censor':target_censor,'latent_seed':10000+seed})
    elif scenario=='S4':
        f=x[:,[0,3,8,14,29]]@np.array([.8,-.7,.6,-.5,.4])
    else:raise ValueError(scenario)
    latent=20*(w/np.exp(f))**(1/1.3)
    y,e=_censor(rng,latent,target_censor,scenario)
    return SurvivalDataset(scenario,pd.DataFrame(x,columns=[f'x{j+1}'for j in range(p)]),y,e,[],{'synthetic':True,'scenario':scenario,'target_censor':target_censor,'latent_seed':10000+seed})


def make_reliability(seed,shift=True,smoke=False):
    rng=np.random.default_rng(20000+seed); n=160 if smoke else 800
    ops=rng.uniform(-1,1,size=(n,3)); sensors=rng.normal(size=(n,42))
    for start in range(0,42,7):
        common=rng.normal(size=(n,1))
        sensors[:,start:start+7]=np.sqrt(.72)*common+np.sqrt(.28)*sensors[:,start:start+7]
    sensors+=rng.normal(size=sensors.shape)*np.linspace(.05,.45,42)
    x=np.c_[ops,sensors]
    f=(.70*sensors[:,0]-.58*sensors[:,1]+.42*sensors[:,7]+.38*sensors[:,8]*ops[:,0]+.32*np.maximum(sensors[:,14],0)**2-.30*sensors[:,15]+.22*ops[:,1]-.18*ops[:,2])
    latent=np.clip(180*(-np.log(rng.uniform(1e-12,1,size=n))/np.exp(f))**.5,15,500)
    y,e=_censor(rng,latent,.38,'reliability')
    name='reliability_shift' if shift else 'reliability_nominal'
    ds=SurvivalDataset(name,pd.DataFrame(x,columns=[f'x{j+1}'for j in range(45)]),y,e,[],{'synthetic':True,'shift':shift,'target_censor':.38,'seed':20000+seed,'censoring':'random exponential','operating_variables':3,'sensor_summaries':42})
    if shift:
        initial=split_dataset(ds,seed)
        train=initial.train.indices
        logy=np.log1p(y)
        rp=-(logy-logy[train].mean())/(logy[train].std()+1e-6)+.25*e
        # Only training observations use outcomes; held-out channels are noise.
        x[:, -6:]=rng.normal(size=(n,6))
        x[train,-6:]=rp[train,None]*np.linspace(.9,1.4,6)+rng.normal(0,.22,size=(len(train),6))
        ds.x=pd.DataFrame(x,columns=ds.x.columns)
        ds.metadata['artifact_statistics']='inner-training log observed time only'
    return ds
