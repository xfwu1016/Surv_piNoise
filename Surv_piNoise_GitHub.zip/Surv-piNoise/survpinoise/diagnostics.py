"""Predeclared, evaluation-only diagnostics for the corrected experiments.

``true_survival`` is an oracle for the specified synthetic S1--S4 generating
mechanisms, evaluated on ORIGINAL, unstandardized covariates. It fits nothing.
The oracle survival-function error compares predicted probabilities with that
known generating survival function. It is neither an IPCW Brier score nor a
clinical calibration metric: no observed event indicator or censoring estimate
enters its calculation.

Normalized risk-set entropy describes model confidence and can be small for
an incorrect model. These diagnostics must not choose training parameters,
early stopping, perturbation budgets, or which experimental runs to report.
"""

from __future__ import annotations

import math

import numpy as np


def _grid(grid, *, integration=False):
    grid = np.asarray(grid, dtype=float)
    if grid.ndim != 1 or len(grid) == 0 or not np.isfinite(grid).all() or np.any(grid < 0):
        raise ValueError("grid must be a nonempty finite nonnegative one-dimensional array")
    if np.any(np.diff(grid) < 0):
        raise ValueError("grid must be in ascending order")
    if integration and (len(grid) < 2 or np.any(np.diff(grid) <= 0)):
        raise ValueError("integration requires at least two strictly increasing grid points")
    return grid


def _survival_from_log_hazard(log_hazard):
    # Saturated survival probabilities are 0 or 1; overflow is unnecessary.
    with np.errstate(over="ignore", under="ignore"):
        hazard = np.exp(np.minimum(log_hazard, math.log(np.finfo(float).max)))
        return np.exp(-hazard)


def true_survival(raw_x, grid, scenario):
    """Known generating S(t|x) for synthetic S1--S4; output shape (n, n_times).

    S1/S2/S4 use H0(t)=(t/20)^1.3 with the documented scenario risk score.
    S3 has a=0.8*x1-0.6*x2 before t=20 and a+0.5*x3 afterwards:

      H(t|x) = exp(a)*(min(t,20)/20)^1.3
             + exp(a+0.5*x3)*max((t/20)^1.3-1, 0).

    This piecewise S3 is the NEW experiment's mechanism, not the earlier
    manuscript's log(1+t) mechanism. No data or predictions are used to fit it.
    Features use zero-based array indices below and one-based names above.
    """
    x = np.asarray(raw_x, dtype=float)
    grid = _grid(grid)
    required = {"S1": 4, "S2": 5, "S3": 3, "S4": 30}
    if scenario not in required:
        raise ValueError(f"unknown simulation scenario {scenario!r}")
    if x.ndim != 2 or x.shape[0] == 0 or x.shape[1] < required[scenario] or not np.isfinite(x).all():
        raise ValueError(f"raw_x must be a nonempty finite matrix with at least {required[scenario]} features")
    if scenario == "S1":
        risk = .7*x[:, 0] - .6*x[:, 1] + .5*x[:, 2] - .4*x[:, 3]
    elif scenario == "S2":
        risk = (.8*x[:, 0]**2 + np.sin(np.pi*x[:, 1])
                + .6*x[:, 2]*x[:, 3] - .5*np.abs(x[:, 4]))
    elif scenario == "S4":
        risk = x[:, [0, 3, 8, 14, 29]] @ np.array([.8, -.7, .6, -.5, .4])
    else:
        a = .8*x[:, 0] - .6*x[:, 1]
        after = a + .5*x[:, 2]
        if not np.isfinite(a).all() or not np.isfinite(after).all():
            raise ValueError("scenario risk scores must be finite")
        with np.errstate(divide="ignore", over="ignore", under="ignore"):
            log_first = 1.3*np.log(np.minimum(grid, 20.)/20.)
            # log(expm1(z)) is evaluated without overflow for large z.
            z = 1.3*np.log(np.maximum(grid, 20.)/20.)
            log_second = np.full_like(z, -np.inf)
            positive = z > 0
            log_second[positive] = z[positive] + np.log(-np.expm1(-z[positive]))
            log_hazard = np.logaddexp(a[:, None] + log_first[None, :],
                                      after[:, None] + log_second[None, :])
        return _survival_from_log_hazard(log_hazard)
    if not np.isfinite(risk).all():
        raise ValueError("scenario risk scores must be finite")
    with np.errstate(divide="ignore", over="ignore"):
        log_baseline = 1.3*np.log(grid/20.)
    return _survival_from_log_hazard(risk[:, None] + log_baseline[None, :])


def oracle_survival_error(pred_survival, true_survival, grid):
    """Time-normalized, sample-mean squared error against KNOWN synthetic S.

    Returns integral mean_i[(S_hat_i(t)-S_true_i(t))^2] dt / time_span,
    using the trapezoidal rule on the supplied, pre-fixed grid. No fitting,
    censoring correction, or clinical calibration claim is involved.
    """
    grid = _grid(grid, integration=True)
    prediction = np.asarray(pred_survival, dtype=float)
    truth = np.asarray(true_survival, dtype=float)
    if (prediction.ndim != 2 or prediction.shape[0] == 0
            or prediction.shape != truth.shape or prediction.shape[1] != len(grid)):
        raise ValueError("prediction and truth must share shape (n_samples, n_grid), with n_samples > 0")
    for name, array in (("prediction", prediction), ("truth", truth)):
        if not np.isfinite(array).all() or np.any((array < 0) | (array > 1)):
            raise ValueError(f"{name} must contain finite survival probabilities in [0, 1]")
    curve = np.mean((prediction-truth)**2, axis=0)
    integral = np.sum(.5*(curve[1:]+curve[:-1])*np.diff(grid))
    return float(integral/(grid[-1]-grid[0]))


def normalized_riskset_entropy(y, event, risk):
    """Mean normalized predictive entropy over observed-event full risk sets.

    At each event i the risk set contains EVERY j with y[j]>=y[i], including
    all mixed ties. H(q)/log(|R_i|) is defined as zero for a singleton set.
    A dataset with no observed events has no event-average diagnostic and
    raises ValueError. This is model-relative confidence, not task entropy
    or proof of accuracy. Sorting is O(n log n), storage O(n).
    """
    time = np.asarray(y, dtype=float)
    event = np.asarray(event)
    scores = np.asarray(risk, dtype=float)
    if (time.ndim != 1 or len(time) == 0 or event.shape != time.shape
            or scores.shape != time.shape or not np.isfinite(time).all()
            or np.any(time < 0) or not np.isfinite(scores).all()
            or not np.isin(event, [0, 1]).all()):
        raise ValueError("time, binary event, and finite risk must be matching nonempty vectors")
    if not np.any(event):
        raise ValueError("risk-set entropy requires at least one observed event")
    order = np.argsort(-time, kind="stable")
    sorted_time, sorted_scores = time[order], scores[order]
    observed = event[order].astype(bool)
    prefix_entropy = np.empty(len(time), dtype=float)
    # Maintain sum(exp(r-m)) and sum(exp(r-m)*(r-m)) relative to the current
    # prefix maximum m. This avoids overflow and prefix underflow when the
    # globally largest score has not yet entered a risk set.
    maximum, mass, weighted_offset = float(sorted_scores[0]), 1.0, 0.0
    prefix_entropy[0] = 0.0
    for index in range(1, len(time)):
        score = float(sorted_scores[index])
        if score <= maximum:
            delta = score - maximum
            weight = math.exp(delta)
            mass += weight
            if weight > 0:
                weighted_offset += weight*delta
        else:
            delta = maximum - score
            scale = math.exp(delta)
            weighted_offset = scale*(weighted_offset + delta*mass) if scale > 0 else 0.0
            mass = scale*mass + 1.0
            maximum = score
        prefix_entropy[index] = max(0.0, math.log(mass)-weighted_offset/mass)
    group_ends = np.flatnonzero(np.r_[sorted_time[:-1] != sorted_time[1:], True])
    lengths = np.diff(np.r_[0, group_ends+1])
    group_index = np.repeat(np.arange(len(group_ends)), lengths)
    event_ends = group_ends[group_index[observed]]
    size = event_ends+1
    normalized = np.zeros(len(event_ends), dtype=float)
    nontrivial = size > 1
    normalized[nontrivial] = prefix_entropy[event_ends[nontrivial]]/np.log(size[nontrivial])
    # Only roundoff can leave the theoretical [0,1] range.
    return float(np.clip(normalized, 0.0, 1.0).mean())
