"""Public clinical survival data, with split-local preprocessing.

``gbsg`` is the DeepSurv Rotterdam/GBSG combination; ``gbsg2`` is the
686-person GBSG2 cohort.  They are deliberately separate dataset names.
HDF5 covariates are the upstream processed benchmark representation, not
reconstructed raw clinical variables.  No claim is made about the fitting
scope of upstream preprocessing.  Our imputation, scaling and vocabularies
are fitted only on the newly assigned training partition.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass, field
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
from typing import Any
import urllib.request

import numpy as np
import pandas as pd

REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DATA_DIR = REPO_ROOT / "data" / "raw"
PRIMARY_DATASETS = ("support", "metabric", "flchain", "gbsg2")
DEEPSURV_ROOT = "https://raw.githubusercontent.com/jaredleekatzman/DeepSurv/master/experiments/data/"
SOURCE_SPECS = {
    "support": {"filename": "support.h5", "url": DEEPSURV_ROOT + "support/support_train_test.h5",
                "sha256": "e398f49930e4efc4ecd675a72ac547f0d1ae25ccf13f6a1024cded12ea88a83e", "features": 14},
    "metabric": {"filename": "metabric.h5", "url": DEEPSURV_ROOT + "metabric/metabric_IHC4_clinical_train_test.h5",
                 "sha256": "e959131973c906c7e8b1e662c81160914768156a6da145a9bfed9b9ee8bf3e72", "features": 9},
    "gbsg": {"filename": "gbsg.h5", "url": DEEPSURV_ROOT + "gbsg/gbsg_cancer_train_test.h5",
             "sha256": "bd455f4395322a8b23040c15cedbef00ad51a447d02c95f1f1d686a6b196484b", "features": 7},
    "flchain": {"filename": "flchain.csv", "url": "https://raw.githubusercontent.com/vincentarelbundock/Rdatasets/master/csv/survival/flchain.csv",
                "sha256": "a96bcc58addb4c127e5012c5974aec8c7daf66123ddb104f309a78f158daa563"},
    "gbsg2": {"filename": "gbsg2.arff", "url": "https://raw.githubusercontent.com/sebp/scikit-survival/main/sksurv/datasets/data/GBSG2.arff",
              "sha256": "8c1ba1df4d80216b58695d6bbc9f51284664ab37124e101d56df089851645b04"},
}
FLCHAIN_FEATURES = ("age", "sex", "sample.yr", "kappa", "lambda", "flc.grp", "creatinine", "mgus")
GBSG2_FEATURES = ("horTh", "age", "menostat", "tsize", "tgrade", "pnodes", "progrec", "estrec")


@dataclass
class SurvivalDataset:
    name: str
    x: pd.DataFrame
    time: np.ndarray
    event: np.ndarray
    categorical_columns: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        self.x = self.x.reset_index(drop=True).copy()
        self.time = np.asarray(self.time, dtype=np.float64).reshape(-1)
        raw_event = np.asarray(self.event).reshape(-1)
        if not (len(self.x) == len(self.time) == len(raw_event)) or not len(self.x):
            raise ValueError("Features, time and event must have the same nonzero row count.")
        if not np.all(np.isfinite(self.time)) or np.any(self.time < 0):
            raise ValueError("Survival times must be finite and nonnegative; zero times are preserved.")
        if not np.all(np.isin(raw_event, [0, 1])):
            raise ValueError("Event labels must be exactly 0 (censored) or 1 (event).")
        self.event = raw_event.astype(np.uint8)
        if len(set(self.x.columns)) != len(self.x.columns):
            raise ValueError("Feature names must be unique.")
        if not set(self.categorical_columns).issubset(self.x.columns):
            raise ValueError("Categorical columns must be feature columns.")
        for col in self.x.columns.difference(self.categorical_columns):
            values = pd.to_numeric(self.x[col], errors="raise").to_numpy(dtype=float)
            if np.isinf(values).any():
                raise ValueError(f"Infinite numeric feature in {col}.")

    @property
    def X(self):
        return self.x


@dataclass
class DataPartition:
    x: np.ndarray
    time: np.ndarray
    event: np.ndarray
    indices: np.ndarray

    @property
    def X(self):
        return self.x


@dataclass
class DataSplit:
    train: DataPartition
    validation: DataPartition
    test: DataPartition
    feature_names: tuple[str, ...]
    preprocessing: dict[str, Any]
    metadata: dict[str, Any]

    @property
    def val(self):
        return self.validation


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_sources(names=None, data_dir=None) -> dict[str, str]:
    """Download exact public snapshots; reject changed or corrupted content.

    Existing files are checked and reused.  An unexpected checksum never
    overwrites an accepted snapshot.  No network access occurs in loaders.
    """
    names = list(SOURCE_SPECS if names is None else names)
    directory = Path(data_dir) if data_dir is not None else DEFAULT_DATA_DIR
    directory.mkdir(parents=True, exist_ok=True)
    results = {}
    for name in names:
        if name not in SOURCE_SPECS:
            raise ValueError(f"Unknown dataset {name!r}; choose {tuple(SOURCE_SPECS)}.")
        spec = SOURCE_SPECS[name]
        path = directory / spec["filename"]
        if path.exists():
            if file_sha256(path) != spec["sha256"]:
                raise ValueError(f"Checksum mismatch for {path}; preserve and investigate the file.")
        else:
            request = urllib.request.Request(spec["url"], headers={"User-Agent": "Surv-piNoise-data-rerun/1.0"})
            with urllib.request.urlopen(request, timeout=90) as response:
                content = response.read()
            if hashlib.sha256(content).hexdigest() != spec["sha256"]:
                raise ValueError(f"Upstream content changed for {name}; no file was accepted.")
            temporary = path.with_suffix(path.suffix + ".part")
            temporary.write_bytes(content)
            temporary.replace(path)
        results[name] = str(path.resolve())
    return results


def _read_gbsg2(path: Path) -> pd.DataFrame:
    text = path.read_text(encoding="utf-8")
    lines = text.splitlines()
    start = next((i + 1 for i, line in enumerate(lines) if line.strip().lower() == "@data"), None)
    if start is None:
        raise ValueError("GBSG2 ARFF is missing @data.")
    rows = csv.reader(io.StringIO("\n".join(line for line in lines[start:] if line.strip() and not line.lstrip().startswith("%"))), quotechar="'", skipinitialspace=True)
    frame = pd.DataFrame(list(rows), columns=list(GBSG2_FEATURES) + ["time", "cens"])
    for col in set(frame.columns) - {"horTh", "menostat", "tgrade"}:
        frame[col] = pd.to_numeric(frame[col].replace("?", np.nan), errors="raise")
    return frame.replace("?", np.nan)


def load_dataset(name: str, data_dir=None, verify: bool = True) -> SurvivalDataset:
    """Load an already downloaded source, retaining source row order.

    ``data_dir`` is the directory containing raw files, not the repository
    root. HDF5 groups are concatenated as train then test, exactly as pycox.
    They are subsequently reassigned to our declared 60/20/20 partitions.
    """
    name = name.lower()
    if name not in SOURCE_SPECS:
        raise ValueError(f"Unknown dataset {name!r}; choose {tuple(SOURCE_SPECS)}.")
    spec = SOURCE_SPECS[name]
    path = (Path(data_dir) if data_dir is not None else DEFAULT_DATA_DIR) / spec["filename"]
    if not path.is_file():
        raise FileNotFoundError(f"Missing {path}. Run python scripts/download_data.py first.")
    if verify and file_sha256(path) != spec["sha256"]:
        raise ValueError(f"Checksum mismatch for {path}.")
    metadata = {"source_url": spec["url"], "source_sha256": file_sha256(path), "source_filename": spec["filename"],
                "source_file_bytes": path.stat().st_size,
                "snapshot_file_timestamp_utc": datetime.fromtimestamp(path.stat().st_mtime, timezone.utc).isoformat(),
                "row_order": "source order", "event_encoding": "1=event, 0=right censored"}
    if name in {"support", "metabric", "gbsg"}:
        try:
            import h5py
        except ImportError as exc:
            raise ImportError("Reading DeepSurv benchmark files requires h5py.") from exc
        with h5py.File(path, "r") as source:
            x = np.concatenate([source[group]["x"][:] for group in ("train", "test")])
            time = np.concatenate([source[group]["t"][:] for group in ("train", "test")])
            event = np.concatenate([source[group]["e"][:] for group in ("train", "test")])
            source_counts = {group: len(source[group]["t"]) for group in ("train", "test")}
        if x.ndim != 2 or x.shape[1] != spec["features"]:
            raise ValueError(f"Unexpected {name} covariate schema: {x.shape}.")
        frame = pd.DataFrame(x, columns=[f"x{i}" for i in range(x.shape[1])])
        metadata.update({"representation": "DeepSurv processed numerical benchmark, as loaded by pycox",
                         "row_order": "upstream train followed by upstream test", "upstream_group_counts": source_counts,
                         "upstream_preprocessing_scope": "not recovered; upstream numerical transformations may precede our split",
                         "time_unit": "source duration units; not converted", "endpoint": "source right-censored survival endpoint"})
        if name == "gbsg":
            metadata["cohort"] = "Rotterdam and German Breast Cancer Study Group combination; NOT GBSG2"
        categorical = ("x2", "x3", "x6") if name == "support" else ()
        if name == "support":
            metadata["categorical_schema_source"] = "pycox official examples/02_introduction.ipynb: x2, x3, x6 categorical; our encoder uses full one-hot instead of entity embeddings"
        return SurvivalDataset(name, frame, time, event, categorical, metadata)
    if name == "flchain":
        frame = pd.read_csv(path)
        metadata.update({"representation": "survival::flchain public Rdatasets CSV; all rows retained",
                         "time_unit": "days", "endpoint": "all-cause death", "excluded_columns": ["rownames", "chapter"],
                         "exclusion_reason": "rownames is an identifier; chapter records cause of death after outcome",
                         "difference_from_pycox_default": "pycox drops creatinine-missing rows; this rerun retains them and fits median imputation on training only"})
        return SurvivalDataset(name, frame.loc[:, FLCHAIN_FEATURES], frame["futime"], frame["death"],
                               ("sex", "sample.yr", "flc.grp"), metadata)
    frame = _read_gbsg2(path)
    metadata.update({"representation": "scikit-survival GBSG2 ARFF", "time_unit": "days", "endpoint": "recurrence-free survival event",
                     "event_source_column": "cens", "event_source_note": "despite its name, cens=1 denotes an observed event",
                     "cohort": "German Breast Cancer Study Group 2; NOT the pycox Rotterdam/GBSG combination"})
    return SurvivalDataset(name, frame.loc[:, GBSG2_FEATURES], frame["time"], frame["cens"],
                           ("horTh", "menostat", "tgrade"), metadata)


class TrainPreprocessor:
    """Median imputation + population standardization + full one-hot encoding.

    All parameters and categories come from fit rows only. Unknown held-out
    categories are all zero in that categorical block. Numeric all-missing
    training columns use zero imputation and unit scale. Missing categories
    have a distinct token that cannot collide with an observed string.
    """
    def fit(self, frame: pd.DataFrame, categorical_columns=()):
        if frame.empty:
            raise ValueError("Cannot fit preprocessing to zero training rows.")
        self.columns = tuple(frame.columns)
        self.categorical_columns = tuple(categorical_columns)
        if not set(self.categorical_columns).issubset(self.columns):
            raise ValueError("Unknown categorical feature.")
        self.numeric_columns = tuple(c for c in self.columns if c not in self.categorical_columns)
        self.numeric = {}
        self.categories = {}
        names = []
        for col in self.numeric_columns:
            array = pd.to_numeric(frame[col], errors="raise").to_numpy(dtype=np.float64)
            if np.isinf(array).any():
                raise ValueError(f"Infinite feature in {col}.")
            median = float(np.nanmedian(array)) if np.isfinite(array).any() else 0.0
            filled = np.where(np.isnan(array), median, array)
            scale = float(filled.std(ddof=0))
            self.numeric[col] = {"median": median, "mean": float(filled.mean()), "scale": scale if scale > 0 else 1.0}
            names.append(str(col))
        for col in self.categorical_columns:
            values = self._categorical_values(frame[col])
            self.categories[col] = sorted(set(values))
            names.extend(f"{col}={value}" for value in self.categories[col])
        self.feature_names = tuple(names)
        return self

    @staticmethod
    def _categorical_values(series):
        return np.array(["missing:" if pd.isna(value) else "value:" + str(value) for value in series], dtype=object)

    def transform(self, frame: pd.DataFrame) -> np.ndarray:
        if tuple(frame.columns) != self.columns:
            raise ValueError("Feature columns/order differ from the fitted training schema.")
        arrays = []
        for col in self.numeric_columns:
            values = pd.to_numeric(frame[col], errors="raise").to_numpy(dtype=np.float64)
            if np.isinf(values).any():
                raise ValueError(f"Infinite feature in {col}.")
            state = self.numeric[col]
            values = np.where(np.isnan(values), state["median"], values)
            arrays.append(((values - state["mean"]) / state["scale"])[:, None])
        for col in self.categorical_columns:
            values = self._categorical_values(frame[col])
            arrays.append(np.column_stack([values == category for category in self.categories[col]]))
        result = np.concatenate(arrays, axis=1).astype(np.float32)
        if not np.isfinite(result).all():
            raise ValueError("Preprocessing produced a non-finite feature value.")
        return result

    def state_dict(self):
        return {"columns": list(self.columns), "categorical_columns": list(self.categorical_columns),
                "numeric": self.numeric, "categories": self.categories, "feature_names": list(self.feature_names),
                "unknown_category_policy": "all-zero block", "numeric_std_ddof": 0, "fitted_on": "training partition only"}


def stratified_indices(event, seed: int, fractions=(0.6, 0.2, 0.2)):
    """Disjoint event-stratified split with exact apportioned partition totals.

    Total partition sizes use largest-remainder rounding. Event counts are
    apportioned proportionally within those totals, retaining both outcome
    strata in every partition. Each stratum needs at least three subjects.
    """
    event = np.asarray(event).reshape(-1)
    if not np.isin(event, [0, 1]).all():
        raise ValueError("Stratification needs binary event labels.")
    fractions = np.asarray(fractions, dtype=float)
    if fractions.shape != (3,) or (fractions <= 0).any() or not np.isclose(fractions.sum(), 1):
        raise ValueError("Three positive split fractions must sum to one.")
    rng = np.random.default_rng(seed)
    ideal_totals = len(event) * fractions
    totals = np.floor(ideal_totals).astype(int)
    total_order = np.argsort(-(ideal_totals - totals), kind="stable")
    totals[total_order[:len(event) - totals.sum()]] += 1
    if (totals < 2).any() or min(int((event == label).sum()) for label in (0, 1)) < 3:
        raise ValueError("Each partition needs both strata and each event stratum needs at least three subjects.")
    event_n = int(event.sum())
    ideal_events = event_n * totals / len(event)
    event_counts = np.clip(np.floor(ideal_events).astype(int), 1, totals - 1)
    while event_counts.sum() < event_n:
        scores = np.where(event_counts < totals - 1, ideal_events - event_counts, -np.inf)
        event_counts[int(np.argmax(scores))] += 1
    while event_counts.sum() > event_n:
        scores = np.where(event_counts > 1, event_counts - ideal_events, -np.inf)
        event_counts[int(np.argmax(scores))] -= 1
    partitions = [[], [], []]
    for label in (0, 1):
        indices = np.flatnonzero(event == label)
        if len(indices) < 3:
            raise ValueError("Each event stratum needs at least three subjects.")
        rng.shuffle(indices)
        counts = event_counts if label == 1 else totals - event_counts
        cuts = np.cumsum(counts)[:-1]
        for partition, part in zip(partitions, np.split(indices, cuts)):
            partition.extend(part.tolist())
    result = []
    for partition in partitions:
        array = np.asarray(partition, dtype=np.int64)
        rng.shuffle(array)
        result.append(array)
    return tuple(result)


def split_dataset(dataset: SurvivalDataset, seed: int, fractions=(0.6, 0.2, 0.2)) -> DataSplit:
    indices = stratified_indices(dataset.event, seed, fractions)
    processor = TrainPreprocessor().fit(dataset.x.iloc[indices[0]], dataset.categorical_columns)
    parts = [DataPartition(processor.transform(dataset.x.iloc[index]), dataset.time[index].copy(),
                           dataset.event[index].copy(), index.copy()) for index in indices]
    metadata = {"dataset": dataset.name, "seed": int(seed), "requested_fractions": list(fractions),
                "stratification": "event indicator", "source": dataset.metadata,
                "partition_counts": {key: {"n": len(part.time), "events": int(part.event.sum())}
                                     for key, part in zip(("train", "validation", "test"), parts)}}
    return DataSplit(*parts, processor.feature_names, processor.state_dict(), metadata)


def dataset_summary(dataset: SurvivalDataset) -> dict[str, Any]:
    return {"name": dataset.name, "n": len(dataset.time), "baseline_features": dataset.x.shape[1],
            "feature_columns": list(dataset.x.columns), "categorical_columns": list(dataset.categorical_columns),
            "events": int(dataset.event.sum()), "censored": int(len(dataset.event) - dataset.event.sum()),
            "censoring_fraction": float(1 - dataset.event.mean()), "missing_features": {str(c): int(n) for c, n in dataset.x.isna().sum().items()},
            "time_min": float(dataset.time.min()), "time_max": float(dataset.time.max()), "zero_time_count": int((dataset.time == 0).sum()),
            "source": dataset.metadata}


def write_provenance(path=None, names=None, data_dir=None):
    names = list(SOURCE_SPECS if names is None else names)
    datasets = [load_dataset(n, data_dir) for n in names]
    provenance = {"generated_utc": datetime.now(timezone.utc).isoformat(), "status": "VERIFIED from checksum-locked downloaded files",
                  "primary_rerun_datasets": list(PRIMARY_DATASETS), "data_sources": [dataset_summary(dataset) for dataset in datasets],
                  "documentation_checked_on": "2026-10-27",
                  "documentation_sources": {
                      "pycox_hdf5_loader_and_source_mapping": "https://raw.githubusercontent.com/havakv/pycox/master/pycox/datasets/from_deepsurv.py",
                      "support_categorical_schema": "https://raw.githubusercontent.com/havakv/pycox/master/examples/02_introduction.ipynb",
                      "pycox_flchain_loader_and_complete_case_default": "https://raw.githubusercontent.com/havakv/pycox/master/pycox/datasets/from_rdatasets.py",
                      "flchain_variable_definitions": "https://stat.ethz.ch/R-manual/R-devel/library/survival/html/flchain.html",
                      "gbsg2_cohort_and_endpoint": "https://scikit-survival.readthedocs.io/en/stable/api/generated/sksurv.datasets.load_gbsg2.html",
                      "gbsg2_units_and_event_coding": "https://search.r-project.org/CRAN/refmans/TH.data/html/GBSG2.html"},
                  "seed10_preprocessing_check": [{"dataset": dataset.name, "feature_names": list(result.feature_names),
                                                   "partition_counts": result.metadata["partition_counts"]}
                                                  for dataset in datasets for result in [split_dataset(dataset, 10)]],
                  "split_protocol": "event-stratified 60/20/20; total sizes by largest remainder and proportional bounded event counts; split indices saved by runner",
                  "preprocessing": "training-only numeric median imputation/population standardization and categorical vocabulary; full one-hot; unknown heldout categories all zero",
                  "limitations": ["SUPPORT/METABRIC/GBSG are upstream processed numerical benchmark representations. The scope and parameters of upstream preprocessing have not been recovered, so the entire pipeline cannot be certified free of upstream preprocessing leakage.",
                                  "The upstream train/test grouping is merged and repartitioned, following pycox's concatenation. New rerun results are not a reproduction of DeepSurv's original split.",
                                  "FLCHAIN has eight baseline covariates, with chapter explicitly excluded. All records including missing-creatinine records are retained, unlike pycox's default complete-case version.",
                                  "GBSG2 (8 features) and pycox GBSG (7 features, Rotterdam/GBSG combination) are different cohorts and must not be interchanged."]}
    destination = Path(path) if path is not None else REPO_ROOT / "data" / "provenance.json"
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(provenance, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    return provenance
