# Reproduction record for version 0.2.2

All commands below run from the repository root. This source distribution includes the primary study and the separately locked sensitivity runner and plotting script. Distribution 0.2.2 updates documentation and packaging; the numerical implementation and reference results are unchanged. The frozen primary-study configuration retains its internal label `0.2-corrected`.

## Reference study and environment

The formal reference run finished on 2026-10-27 with 440 completed cells, 1,840 method rows, 36 condition groups, and zero failures. A condition group fixes suite, dataset/scenario, censoring target, and backbone. One cell adds a matched seed; each method contributes one row.

| Suite | Condition groups | Cells | Method rows |
|---|---:|---:|---:|
| Simulation: S1–S4 × censoring 20/40/60% × Cox/DeepSurv | 24 | 320 | 1,280 |
| Clinical: SUPPORT/METABRIC/FLCHAIN/GBSG2 × Cox/DeepSurv | 8 | 80 | 320 |
| Synthetic reliability: nominal/shift, DeepSurv | 2 | 20 | 100 |
| Ablation: GBSG2/shift, DeepSurv | 2 | 20 | 140 |
| Total | 36 | 440 | 1,840 |

Seeds are 100–109 throughout, plus 110–119 for each 40% censoring simulation condition. Simulations use n=2,000 and p=20 for S1–S3, and n=1,200 and p=200 for S4. Synthetic reliability uses n=800, three operating covariates and 42 sensor summaries. Censoring targets are population design values, not forced realized sample proportions.

The reference environment recorded Python 3.12.14, Windows 10 x86-64, PyTorch 2.6.0+cpu, NumPy 2.3.5, pandas 3.0.1, 16 logical CPUs, six process workers, and one PyTorch thread per worker. HDF5 loading/analysis used h5py 3.13.0, SciPy 1.15.3 and Matplotlib 3.10.1. `requirements.txt` pins these direct dependencies; it is not a full transitive lockfile. Installation, hardware and other platforms may change numerical results. CUDA execution is not implemented in this runner.

The reference fingerprint is `3e32972965be8f544eb1563bc0f1f9cf5a622c9a3772102cfe4d68128f48b41b`. The raw metric CSV SHA-256 is `239e1b775e9d813c924e0355d1e26eff7f9ffcbb7dc34915578f33cacf705a42`. These identify the recorded artifacts; they are not requirements for a run on different hardware.

## Download and verify data

```bash
python scripts/download_data.py
python -m unittest discover -s tests -v
```

The downloader uses the URLs and SHA-256 digests in `survpinoise/data.py`. It writes downloaded files to `data/raw/` and a source inventory to `data/provenance.json`; a checksum mismatch is an error rather than a silent update. No raw clinical files are needed in the source distribution. Internet access is required for this step. All five supported downloads are the default because the downloaded-source integration test also checks the optional `gbsg` cohort. The formal clinical plan uses only four datasets:

| Dataset | Rows | Baseline features | Events / censored | Download representation |
|---|---:|---:|---:|---|
| SUPPORT | 8,873 | 14 | 6,036 / 2,837 | DeepSurv processed HDF5 |
| METABRIC | 1,904 | 9 | 1,103 / 801 | DeepSurv processed HDF5 |
| FLCHAIN | 7,874 | 8 | 2,169 / 5,705 | `survival::flchain` Rdatasets CSV |
| GBSG2 | 686 | 8 | 299 / 387 | scikit-survival ARFF |

Counts refer to the checksum-locked files and are before one-hot encoding. FLCHAIN retains rows with missing creatinine, excludes the post-outcome `chapter` column, and imputes within the inner-training split. Zero observed times are retained. GBSG2's `cens=1` denotes an event. `gbsg` is the 2,232-row Rotterdam/GBSG combined processed benchmark and is not GBSG2. The upstream HDF5 train/test blocks are concatenated and re-split; upstream numerical preprocessing may precede this new split and its fitting scope has not been recovered.

For a formal run without the optional integration download, the supported command is:

```bash
python scripts/download_data.py --datasets support metabric flchain gbsg2
```

With only those four files, the existing integration test that requires all five supported source files is skipped; this does not change the formal study plan. Do not replace the data with another benchmark representation while retaining the reference label.

## Independent censoring calibration

`configs/censoring_scales.json` was prepared before formal execution from independent pilot failure populations, with 20,000 latent failures per mechanism and master seed 20261027. Bisection solves the pilot expectation of `P(C<T | T)` for an exponential censoring scale. The pilot does not import the training engine, read main cohorts, inspect test outcomes, or fit a scale to an observed experimental censoring rate. Main-cohort censoring draws remain independent of the failure-generating covariates and latent failure times after the scale is fixed.

The file is already included. To verify regeneration without changing it:

```bash
python scripts/prepare_censoring.py --output results/pilot_check/censoring_scales.json --n-pilot 20000 --seed 20261027
python -c "import json; from pathlib import Path; a=json.loads(Path('configs/censoring_scales.json').read_text()); b=json.loads(Path('results/pilot_check/censoring_scales.json').read_text()); assert a==b; print('Independent pilot matches the committed configuration')"
```

The experiment runner always reads `configs/censoring_scales.json`; `--config` changes the study plan, not the censoring-file path. The runner checksum-locks the censoring configuration. Changing pilot settings or a failure law creates a different experiment and requires a new output directory and report. The command `python scripts/prepare_censoring.py` regenerates the committed path; preserve the reference version when conducting a new study.

## Full execution and recovery

First check the environment and short training path:

```bash
python -m unittest discover -s tests -v
python scripts/analyze_results.py --self-test
python scripts/run_experiments.py --smoke --workers 2 --output results/smoke_check
```

Smoke evaluates two n=160 cells with shortened epoch budgets, producing 11 rows. It is not included in the formal totals and cannot be passed to the complete-run analysis.

Execute the full locked plan in a fresh output directory:

```bash
python scripts/run_experiments.py --config configs/protocol.json --suite all --workers 6 --output results/reproduced_v1
```

The runner returns nonzero if any cell fails and records the failures. To recover after interruption, repeat exactly the same command with the same code, configuration, output directory, and environment. Completed cells with matching fingerprints and file checksums are reused automatically. There is no `--resume` argument. An environment/protocol/source mismatch is rejected; use a fresh output directory instead of editing receipts or mixing runs. Changing `--workers` changes scheduling but not the configured per-worker PyTorch thread count.

The implemented `--suite` choices are `all`, `simulation`, `clinical`, `reliability`, and `ablation`. Separate-suite runs are useful for debugging, with a distinct output directory for each suite. The supplied analysis validates the full all-suite plan and does not accept a subset; use the all-suite command for the reported study.

All methods share the same initial predictor parameters within a cell. The default warm/adaptation/refit budgets are 20/50/100 epochs. Final predictors are refitted from the shared initial parameters on development data (inner train plus validation). Fixed Gaussian/sphere radii are selected on validation from the prespecified `[0.0, 0.2, 0.8, 1.8]` grid. Joint and Full use the same generator architecture and three regularizers; Full additionally computes a differentiable virtual inner update. Equal epoch budgets are not equal wall-clock budgets. The generator uses observed outcomes during training; it is not needed to predict a new patient's risk.

## Evaluation protocol

Each replicate uses a disjoint event-stratified 60/20/20 inner-training/validation/test split. Numeric imputation/scaling and category vocabularies are fitted on inner training. Reverse censoring Kaplan–Meier, Uno's C-index horizon, and the shared IBS grid use inner-training labels only. Mixed failure/censoring ties follow the event-first reverse-KM convention, and IPCW event contributions use the appropriate left limit.

The IBS grid has 50 equally spaced points between the inner-training event-time 10th and 80th percentiles, restricted to positive censoring-survival support. Uno's horizon starts from the inner-training event-time 80th percentile and uses the same support restriction. IPCW uses a minimum censoring-survival value of 0.05, with clipping diagnostics recorded. Test times do not select the grid or horizon and test outcomes do not fit censoring KM. Subjects censored before a Brier time have zero contribution at that time; they are not removed from the test cohort. The Brier denominator is the total test cohort size.

The differentiable outer Brier term uses an inner-training Breslow baseline; the final evaluated survival probabilities use a Breslow baseline fitted to the final model's clean development-data risks and labels. Test outcomes are used only for final scoring. IBS measures survival-probability prediction error and is not by itself a calibration assessment. Oracle survival ISE is available for synthetic S1–S4 only. Normalized risk-set entropy is a secondary descriptive diagnostic. Neither diagnostic enters training or selection or establishes a causal mechanism.

## Analysis and output contract

```bash
python scripts/analyze_results.py --input results/reproduced_v1 --check-only
python scripts/analyze_results.py --input results/reproduced_v1
```

`--check-only` validates the complete, non-smoke, zero-failure study, recomputes summaries, and cross-checks cell receipts without writing analysis or importing plotting tools. The second command writes `analysis/`, `tables/`, and six PDF/PNG figure pairs under the input directory. Alternatives supported by the actual parser are:

```bash
python scripts/analyze_results.py --input results/reproduced_v1 --output results/reproduced_analysis --tables-only
python scripts/analyze_results.py --self-test
```

Analysis never trains or re-evaluates a model; primary estimates are calculated from `results_raw.csv`. The full experiment output contains:

```text
run.json
results_raw.csv
summary.json
failures.json
cells/<suite>__<dataset>__<censoring>__<backbone>__<seed>/
    manifest.json
    metrics.json
    diagnostics.json
    split_and_preprocessing.json
    predictions.npz
    models.pt
analysis/summary_metrics.csv
analysis/paired_comparisons.csv
analysis/full_method_comparisons.csv
analysis/findings.json
tables/*.tex
figures/*.pdf and *.png
```

Preserve every file listed in cell manifests, including `models.pt`, for the complete analysis to pass checksum validation. Loading untrusted model checkpoints is unnecessary for the provided analysis. The small files in `reported_results/` are reference summaries, not a replacement for this complete bundle. Place a separate supplied full bundle under `results/corrected_v1/` to run `python scripts/analyze_results.py --input results/corrected_v1 --check-only`; the bundle must contain the hierarchy above. There is no registered hosted download URL in this release.

## Interpreting the results

Summaries report means and sample SDs. Comparisons pair the same random seeds within a condition and use two-sided t95% intervals; they do not pool effect sizes across datasets/backbones. A positive reported gain means higher C-index or lower IBS. `paired_comparisons.csv` compares methods with Clean in main suites and variants with Full in ablations; `full_method_comparisons.csv` consistently compares Full with Clean, Fixed Gaussian, and Joint generator. Read its `direction` field before interpreting signs.

All pairwise intervals are unadjusted and exploratory. For the two primary endpoints, the Full-versus-three-comparator file also reports Holm p-values separately across all 34 non-ablation conditions in each comparator/endpoint family. The displayed intervals remain unadjusted. Repeated clinical splits share patients: their seed intervals describe resplitting variation in one fixed dataset, not patient-population uncertainty or independent clinical replications. A zero-crossing interval does not establish equivalence.

The recorded study does **not** support universal superiority. Among the eight clinical conditions, no Full-versus-Clean paired interval favors Full; FLCHAIN–DeepSurv has an unfavorable IBS interval. In 24 simulation conditions, Full-versus-Clean has no favorable C-index interval and seven unfavorable ones. Synthetic shift has favorable unadjusted C-index and IBS comparisons against Clean/Joint, but fixed Gaussian/sphere have lower IBS; nominal lacks a clear advantage against Clean. After the stated 34-condition Holm adjustment, favorable primary comparisons are limited to shift IBS against Clean and Joint. Ablations do not establish an outcome-conditioning or Brier-outer advantage; more localized contrasts include variable versus fixed variance in shift. These results motivate conditional claims, not test-driven parameter changes, seed removal, or selective reporting.

## Simulation and reliability scope

S3 uses a piecewise time-varying effect at time 20. The synthetic shift artifact uses inner-training outcomes only; validation/test artifact channels are noise. No real C-MAPSS evaluation is performed.

## Data sources and permission status

The upstream repository/package license statements and cohort documentation below were inspected on 2026-10-27. Source-file identities are checked against the downloaded-file hashes recorded by the loader; the GBSG2 GitHub file page returned HTTP 429 during the separate web check. Dataset descriptions and source-file checksums are distinct from redistribution permission.

| Source | Source record | Permission status |
|---|---|---|
| SUPPORT/METABRIC processed files (optional combined GBSG) | [DeepSurv benchmark files](https://github.com/jaredleekatzman/DeepSurv/tree/master/experiments/data), [software LICENSE.txt](https://github.com/jaredleekatzman/DeepSurv/blob/master/LICENSE.txt) | The software license is MIT; a dataset-specific grant covering these underlying clinical files has not been established here. |
| FLCHAIN | [Rdatasets source/license discussion](https://github.com/vincentarelbundock/Rdatasets/blob/master/README.md), [survival package](https://CRAN.R-project.org/package=survival), [dataset documentation](https://stat.ethz.ch/R-manual/R-devel/library/survival/html/flchain.html) | Rdatasets labels its code GPL-3 and explicitly notes uncertainty about actual data licensing. The survival package lists LGPL terms. Blanket data redistribution permission has not been established. |
| GBSG2 | [scikit-survival data file](https://github.com/sebp/scikit-survival/blob/main/sksurv/datasets/data/GBSG2.arff), [upstream copyright statement](https://github.com/sebp/scikit-survival/blob/main/doc/contributing.rst), [cohort documentation](https://scikit-survival.readthedocs.io/en/stable/api/generated/sksurv.datasets.load_gbsg2.html) | Upstream code is GPL-3; a separately checked underlying data-file grant has not been established here. |

Check the source providers' current data-use and redistribution conditions before sharing raw files, per-patient predictions, model artifacts, or a full result bundle. These upstream licenses do not assign a license to this repository. No software license is specified for this repository; contact the corresponding author for reuse permission. Obtain any required data permissions from the source providers.
## Joint parameter sensitivity extension

The 28 October 2026 follow-up was specified after the primary evaluation, with its grid fixed before this execution. It evaluates DeepSurv at rho = 0, 0.2, 0.8, 1.8, 3.6 and gamma_B = 0, 0.1, 1, 10, using seeds 100-109 on GBSG2, nominal synthetic reliability and shifted synthetic reliability. All 600 complete-budget fits finished with zero failures. The 60 dataset/parameter groups each have ten matched seeds; these are not 600 independent datasets. The old 440 cells and 1,840 method rows remain a separate primary run.

Use the commands in the README with `--reference-dir reported_results/corrected_v1`. This compact reference directory contains the original method-level metrics needed by the unchanged strict anchor check; it contains no individual clinical data. The formal sensitivity fingerprint is `9d6a6cc6eb9bcff57917cb203f98ca86770d5dc17686ab4c9ef4bbd9f1da454c`, and its raw CSV SHA-256 is `fbeb638c0e53825ce3c94156e8c4386b0f673eb436e54e8c5ac352768f10ae4b`. Its seven core module hashes match the primary run. The plot command used for the manuscript is:

```bash
python scripts/plot_sensitivity.py --input results/sensitivity_v1/results_raw.csv --output results/sensitivity_v1/figures --width-mm 137 --height-mm 160
```

To regenerate the figures directly from the included reference metrics, without retraining:

```bash
python scripts/plot_sensitivity.py --input reported_results/sensitivity_v1/results_raw.csv --output results/sensitivity_reference_figures --width-mm 137 --height-mm 160
```

The plotting program requires a complete, unique grid and completed receipt. Its output includes six-panel zero-baseline 3-D bars, an annotated 2-D equivalent, full-precision summaries, mean/sample-SD and unadjusted t intervals, paired differences from the original default, and a source manifest. The horizontal parameter locations are discrete categories with actual numeric tick labels; no interpolation or smoothing is used. The original default (rho=1.8, gamma_B=1) is marked with a black diamond or cell outline, not replaced by a test-selected optimum. Main-text Figure 6 uses all three conditions and both metrics; supplementary Figure S3 and Table S6 expose all numerical cells.

The formal audit verified 3,000 cell-file hashes, identical seed-specific splits across the grid, 30 original Full anchors, 120 zero-budget Clean predictions and 20 available Cox-only outer predictions. The metrics, risks, predicted-survival matrices and Brier curves matched exactly, with maximum absolute difference zero. The runner automatically checks Full metric anchors and zero-budget invariance; the broader file/prediction audit is recorded separately in `audit_consistency.json`. The strict reference-metric tolerance is 1e-12. A different numerical platform can fail this check even when results are close. For a same-platform consistency test, first rerun the full primary protocol and then pass its output directory as `--reference-dir`; preserve and report any differences from the distributed reference rather than changing receipts.

At gamma_B=1, increasing rho from zero to 3.6 changes shifted IBS from 0.2676 to 0.2314 and C-index from 0.5755 to 0.5930. Nominal IBS declines from 0.2074 to 0.2024, while nominal C-index declines from 0.6529 to 0.6342. GBSG2 changes are small and nonmonotonic. These are descriptive patterns on reused test splits. No comparator was retuned in this extension, and the scan does not establish a universally optimal weight, independent confirmation, or superiority over tuned fixed noise. Clinical repeated-split intervals describe benchmark variability, not independent patient populations. Full models, test predictions and split/preprocessing records remain in a separate local sensitivity-result bundle; downloaded clinical files are excluded from the source ZIP.

